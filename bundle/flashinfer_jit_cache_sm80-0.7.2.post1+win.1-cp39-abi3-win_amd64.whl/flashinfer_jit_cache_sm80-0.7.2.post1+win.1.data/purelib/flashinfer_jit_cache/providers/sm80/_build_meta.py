__version__ = "0.7.2.post1+win.1"
__git_version__ = "v0.7.2.post1+win.1"
