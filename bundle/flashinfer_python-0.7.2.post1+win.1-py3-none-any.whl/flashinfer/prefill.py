"""
Copyright (c) 2023 by FlashInfer team.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import functools
import logging
import math
import os
from types import SimpleNamespace
from typing import Any, Dict, List, Literal, Optional, Sequence, Tuple, Union, overload

import torch

from .api_logging import flashinfer_api, flashinfer_experimental_api
from .cudnn import cudnn_batch_prefill_with_kv_cache
from .cudnn.prefill import (
    CUDNN_AVAILABLE as _CUDNN_GRAPH_AVAILABLE,
    _cudnn_supports_direct_seqlens,
    CudnnPrefillGraph,
    _PrefillMetadata,
    _CudnnPrefillPlan,
    prepare_cudnn_batch_prefill,
)
from .jit.attention._lazy import _LazyPagedKVStrideModule
from .jit import (
    gen_batch_prefill_module,
    gen_customize_batch_prefill_module,
    gen_fmha_cutlass_sm100a_module,
    gen_fmha_v2_module,
    gen_single_prefill_module,
    gen_trtllm_fmha_v2_sm120_module,
    gen_trtllm_gen_fmha_module,
    get_batch_prefill_uri,
    get_single_prefill_uri,
    setup_cubin_loader,
)
from .jit.attention.modules import (
    BatchPrefillModuleSurface,
    BatchPrefillPagedKVStrideMode,
    _gen_batch_prefill_independent_paged_module,
    _gen_batch_prefill_primary_module,
)
from .jit.attention.utils import _is_nvfp4_kv_dtype
from .jit.core import logger
from .mla import (
    trtllm_prefill_with_kv_cache_mla as trtllm_prefill_with_kv_cache_mla,
)
from .page import get_seq_lens
from .quantization import packbits, segment_packbits
from .trace.templates.attention import (
    gqa_paged_prefill_trace,
    gqa_ragged_prefill_trace,
    single_prefill_with_kv_cache_trace,
    trtllm_batch_context_trace,
)
from .trace.templates.gemm import (
    fmha_v2_prefill_deepseek_trace,
    fmha_v2_prefill_sm120_trace,
    trtllm_ragged_attention_deepseek_trace,
)
from .trace.templates.page import trtllm_fmha_v2_prefill_trace
from .utils import (
    SINGLE_KERNEL_TMP_SIZE,
    FP4Tensor,
    MaskMode,
    PosEncodingMode,
    TensorLayout,
    _check_block_tables_shape,
    _check_cached_qkv_data_type,
    _check_kv_layout,
    _check_pos_encoding_mode,
    _check_workspace_buffer_alignment,
    _get_cache_alibi_slopes_buf,
    _get_cache_buf,
    _get_trtllm_gen_multi_ctas_kv_counter_buffer,
    _resolve_trtllm_gen_multi_ctas_kv_counter_buffer,
    _should_use_fmha_v2_sm120,
    _unpack_paged_kv_cache,
    canonicalize_torch_dtype,
    ceil_div,
    check_lse_base,
    check_lse_layout,
    check_shape_dtype_device,
    determine_attention_backend,
    device_support_pdl,
    get_alibi_slopes,
    get_compute_capability,
    get_device_sm_count,
    is_float8,
    is_sm12x_supported,
    is_sm100a_supported,
    is_sm110a_supported,
    ln2,
    log2e,
    prepare_jit_additional_args,
    register_custom_op,
    register_fake_op,
    round_up,
    check_trtllm_gen_sm107_only_feature,
)


def _stage_lse(
    lse: Optional[torch.Tensor], lse_layout: str, return_lse: bool, q: torch.Tensor
) -> Tuple[Optional[torch.Tensor], Optional[torch.Tensor]]:
    """Kernels write ``[tokens, heads]``. For ``"HN"`` a caller's buffer is the
    finisher's ``[heads, tokens]`` destination and the kernel gets a fresh NH
    buffer; returns ``(lse_for_kernel, lse_out)``."""
    if not return_lse or lse_layout != "HN":
        return lse, None
    if lse is not None:
        check_shape_dtype_device(
            lse, (q.size(1), q.size(0)), torch.float32, q.device, "lse"
        )
        if not lse.is_contiguous():
            raise ValueError('lse for lse_layout="HN" must be contiguous')
    return None, lse


def _finish_lse(
    lse: torch.Tensor,
    lse_base: str,
    lse_layout: str,
    lse_out: Optional[torch.Tensor],
) -> torch.Tensor:
    """Kernels write base-2 LSE as ``[tokens, heads]``; deliver the requested base and layout.

    ``lse_out`` is the caller's buffer in the requested layout, if any. ``"NH"`` is
    finished in place; ``"HN"`` is one fused transpose(+rescale) into a contiguous
    ``[heads, tokens]`` tensor.
    """
    if lse_layout == "NH":
        if lse_base == "ln":
            lse.mul_(ln2)
        return lse
    src = lse.t()
    if lse_out is None:
        lse_out = torch.empty(src.shape, dtype=lse.dtype, device=lse.device)
    if lse_base == "ln":
        torch.mul(src, ln2, out=lse_out)
    else:
        lse_out.copy_(src)
    return lse_out


def _split_scale_param(scale):
    """Split scale parameter into tensor and scalar components.

    Args:
        scale: Can be a torch.Tensor (per-head), a scalar float, or None.

    Returns:
        tuple: (tensor_ptr, scalar_val) where:
            - If scale is tensor: (scale, 1.0)
            - If scale is scalar: (None, scale)
            - If scale is None: (None, 1.0)
    """
    if scale is None:
        return None, 1.0
    elif isinstance(scale, torch.Tensor):
        return scale, 1.0
    else:
        return None, float(scale)


@functools.cache
def get_fmha_module(
    dtype_q: torch.dtype,
    dtype_kv: torch.dtype,
    dtype_o: torch.dtype,
    dtype_idx: torch.dtype,
    head_dim_qk: int,
    head_dim_vo: int,
    pos_encoding_mode: int,
    use_sliding_window: bool,
    use_logits_soft_cap: bool,
    device: torch.device,
    use_fp16_qk_reduction: bool = False,
):
    if is_sm100a_supported(device) or is_sm110a_supported(device):
        return gen_fmha_cutlass_sm100a_module(
            dtype_q,
            dtype_kv,
            dtype_o,
            dtype_idx,
            head_dim_qk,
            head_dim_vo,
            pos_encoding_mode,
            use_sliding_window,
            use_logits_soft_cap,
        ).build_and_load()
    else:
        raise ValueError(
            "CUTLASS FMHA requires SM100a (B200/GB200) or SM110a. "
            "SM12x (RTX 5090/DGX Spark) lacks tcgen05 MMA required by this kernel. "
            "Use backend='fa2' instead."
        )


def make_hashable_cache(func):
    """
    Decorator that converts unhashable arguments (like lists) to hashable ones (tuples)
    before applying functools.cache.
    """

    @functools.cache
    def cached_wrapper(*args, **kwargs):
        return func(*args, **kwargs)

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        # Convert unhashable arguments to hashable ones
        hashable_args = []
        for arg in args:
            if isinstance(arg, list):
                hashable_args.append(tuple(arg))
            else:
                hashable_args.append(arg)

        hashable_kwargs = {}
        for key, value in kwargs.items():
            if isinstance(value, list):
                hashable_kwargs[key] = tuple(value)
            else:
                hashable_kwargs[key] = value

        return cached_wrapper(*hashable_args, **hashable_kwargs)

    return wrapper


@make_hashable_cache
def get_customize_batch_prefill_module(
    backend: str,
    uri: str,
    dtype_q: torch.dtype,
    dtype_kv: torch.dtype,
    dtype_o: torch.dtype,
    idtype: torch.dtype,
    head_dim_qk: int,
    head_dim_vo: int,
    additional_tensor_names: List[str],
    additional_tensor_dtypes: List[str],
    additional_scalar_names: List[str],
    additional_scalar_dtypes: List[str],
    variant_name: str,
    variant_decl: str,
    pos_encoding_mode: int = 0,
    use_sliding_window: bool = False,
    use_logits_soft_cap: bool = False,
    use_fp16_qk_reduction: bool = False,
    fp8_enabled: bool = False,
    paged_kv_stride_mode: BatchPrefillPagedKVStrideMode = "runtime",
    module_surface: BatchPrefillModuleSurface = "full",
):
    return gen_customize_batch_prefill_module(
        backend,
        uri,
        dtype_q,
        dtype_kv,
        dtype_o,
        idtype,
        head_dim_qk,
        head_dim_vo,
        additional_tensor_names,
        additional_tensor_dtypes,
        additional_scalar_names,
        additional_scalar_dtypes,
        variant_name,
        variant_decl,
        pos_encoding_mode,
        use_sliding_window,
        use_logits_soft_cap,
        use_fp16_qk_reduction,
        fp8_enabled,
        paged_kv_stride_mode=paged_kv_stride_mode,
        module_surface=module_surface,
    ).build_and_load()


@functools.cache
def get_trtllm_gen_prefill_module():
    mod = gen_trtllm_gen_fmha_module()
    op = mod.build_and_load()
    for library_path in mod.get_library_paths():
        setup_cubin_loader(library_path)

    def _paged_run(
        query: torch.Tensor,
        k_cache: torch.Tensor,
        v_cache: torch.Tensor,
        workspace_buffer: torch.Tensor,
        block_tables: torch.Tensor,
        seq_lens: torch.Tensor,
        max_q_len: int,
        max_kv_len: int,
        bmm1_scale: Union[float, torch.Tensor],
        bmm2_scale: Union[float, torch.Tensor],
        batch_size: int,
        cum_seq_lens_q: torch.Tensor,
        cum_seq_lens_kv: torch.Tensor,
        enable_pdl: bool,
        workspace_size: int,
        window_left: int = -1,
        out: Optional[torch.Tensor] = None,
        sinks: Optional[torch.Tensor] = None,
        key_block_scales: Optional[torch.Tensor] = None,
        value_block_scales: Optional[torch.Tensor] = None,
        skip_softmax_threshold_scale_factor: Optional[float] = None,
        uses_shared_paged_kv_idx: bool = True,
        use_fp16_softmax: Optional[bool] = None,
        uses_spcompress: Optional[bool] = None,
        is_causal: bool = True,
        lse: Optional[torch.Tensor] = None,
        multi_ctas_kv_counter_buffer: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        sm_count = get_device_sm_count(query.device)
        if out is None:
            out = torch.empty_like(query)
        multi_ctas_kv_counter_buffer = _resolve_trtllm_gen_multi_ctas_kv_counter_buffer(
            multi_ctas_kv_counter_buffer,
            batch_size,
            query.size(1),
            sm_count,
            query.device,
        )
        if isinstance(bmm1_scale, torch.Tensor):
            assert bmm1_scale.dtype == torch.float32
            bmm1_scale = bmm1_scale * log2e
        if isinstance(bmm2_scale, torch.Tensor):
            assert bmm2_scale.dtype == torch.float32
        if lse is not None:
            check_shape_dtype_device(
                lse, (query.size(0), query.size(1)), torch.float32, query.device, "lse"
            )
            lse_stride_tokens = lse.stride(0)
            lse_stride_heads = lse.stride(1)
        else:
            lse_stride_tokens = 0
            lse_stride_heads = 0
        op.trtllm_paged_attention_context(
            out,
            None,  # fp4 output not supported in wrapper api yet.
            query,
            k_cache,
            v_cache,
            workspace_buffer,
            multi_ctas_kv_counter_buffer,
            block_tables,
            seq_lens,
            max_q_len,
            max_kv_len,
            bmm1_scale,
            bmm2_scale,
            -1,  # o_sf_scale
            -1,  # o_sf_vec_size
            0,  # o_sf_start_index
            batch_size,
            window_left,
            cum_seq_lens_q,
            cum_seq_lens_kv,
            sm_count,
            enable_pdl,
            workspace_size,
            sinks,
            key_block_scales,
            value_block_scales,
            skip_softmax_threshold_scale_factor,
            uses_shared_paged_kv_idx,
            use_fp16_softmax,
            uses_spcompress,
            is_causal,
            lse,
            1.0,  # lse_scale
            lse_stride_tokens,
            lse_stride_heads,
        )
        return out

    def _ragged_run(*args, **kwargs):
        # TODO(Zihao): trtllm-gen backend already supports variable length attention,
        # but not integrated into flashinfer yet.
        raise NotImplementedError(
            "Variable length is not implemented for trtllm-gen backend yet."
        )

    def _plan(*args, **kwargs):
        pass

    return SimpleNamespace(
        paged_run=_paged_run,
        ragged_run=_ragged_run,
        plan=_plan,
    )


@functools.cache
def get_single_prefill_module(backend, *args):
    uri = get_single_prefill_uri(backend, *args)
    module = gen_single_prefill_module(backend, *args).build_and_load()
    run_func = module.run

    # torch library for single_prefill_with_kv_cache

    @register_custom_op(
        f"flashinfer::{uri}_run", mutates_args=("tmp", "o", "maybe_lse")
    )
    def run_single_prefill(
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        tmp: torch.Tensor,
        o: torch.Tensor,
        maybe_lse: Optional[torch.Tensor],
        mask_mode: int,
        layout: int,
        window_left: int,
        maybe_packed_custom_mask: Optional[torch.Tensor],
        maybe_alibi_slopes: Optional[torch.Tensor],
        logits_soft_cap: float,
        sm_scale: float,
        scale_q: Optional[torch.Tensor],
        scale_k: Optional[torch.Tensor],
        scale_v: Optional[torch.Tensor],
        rope_scale: float,
        rope_theta: float,
        maybe_k_cache_sf: Optional[torch.Tensor] = None,
        maybe_v_cache_sf: Optional[torch.Tensor] = None,
    ) -> None:
        if backend == "fa3":
            scale_v_tensor, scale_v_scalar = _split_scale_param(scale_v)
            if not is_float8(q):
                run_func(
                    q,
                    k,
                    v,
                    tmp,
                    o,
                    maybe_lse,
                    mask_mode,
                    layout,
                    window_left,
                    scale_v_tensor,
                    logits_soft_cap,
                    sm_scale,
                    scale_v_scalar,
                )
            else:
                # FP8 enabled
                scale_q_tensor, scale_q_scalar = _split_scale_param(scale_q)
                scale_k_tensor, scale_k_scalar = _split_scale_param(scale_k)
                run_func(
                    q,
                    k,
                    v,
                    tmp,
                    o,
                    maybe_lse,
                    mask_mode,
                    layout,
                    window_left,
                    scale_q_tensor,
                    scale_k_tensor,
                    scale_v_tensor,
                    sm_scale,
                    scale_q_scalar,
                    scale_k_scalar,
                    scale_v_scalar,
                )
        else:
            run_func(
                q,
                k,
                v,
                tmp,
                o,
                maybe_lse,
                mask_mode,
                layout,
                window_left,
                maybe_packed_custom_mask,
                maybe_alibi_slopes,
                maybe_k_cache_sf,
                maybe_v_cache_sf,
                logits_soft_cap,
                sm_scale,
                1.0 / rope_scale,  # rope_rcp_scale
                1.0 / rope_theta,  # rope_rcp_theta
            )
        return o

    @register_fake_op(f"flashinfer::{uri}_run")
    def _fake_run_single_prefill(
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        tmp: torch.Tensor,
        o: torch.Tensor,
        maybe_lse: Optional[torch.Tensor],
        mask_mode: int,
        layout: int,
        window_left: int,
        maybe_packed_custom_mask: Optional[torch.Tensor],
        maybe_alibi_slopes: Optional[torch.Tensor],
        logits_soft_cap: float,
        sm_scale: float,
        rope_scale: float,
        rope_theta: float,
        maybe_k_cache_sf: Optional[torch.Tensor] = None,
        maybe_v_cache_sf: Optional[torch.Tensor] = None,
    ) -> None:
        pass

    # Register the module
    return SimpleNamespace(run=run_single_prefill)


class _LazyBatchPrefillIndependentModule(_LazyPagedKVStrideModule):
    _module_name = "paged"


@functools.cache
def get_batch_prefill_module(backend, *args):
    lazy_independent_module: Optional[_LazyBatchPrefillIndependentModule] = None
    if backend == "trtllm-gen":
        uri = "trtllm_gen_context"
        module = get_trtllm_gen_prefill_module()
        plan_func = module.plan
        workspace_size_func = None
        ragged_run_func = module.ragged_run
        paged_run_func = module.paged_run
    elif backend == "fa2":
        uri = get_batch_prefill_uri(backend, *args)
        module = _gen_batch_prefill_primary_module(backend, *args).build_and_load()
        lazy_independent_module = _LazyBatchPrefillIndependentModule(
            _gen_batch_prefill_independent_paged_module(backend, *args)
        )
        plan_func = module.plan
        workspace_size_func = getattr(module, "workspace_size", None)
        ragged_run_func = module.ragged_run
        paged_run_func = module.paged_run
    else:
        uri = get_batch_prefill_uri(backend, *args)
        module = gen_batch_prefill_module(backend, *args).build_and_load()
        plan_func = module.plan
        workspace_size_func = getattr(module, "workspace_size", None)
        ragged_run_func = module.ragged_run
        paged_run_func = module.paged_run

    # torch library for ragged_run

    @register_custom_op(
        f"flashinfer::{uri}_ragged_run",
        mutates_args=(
            "float_workspace_buffer",
            "int_workspace_buffer",
            "o",
            "maybe_lse",
        ),
    )
    def ragged_run(
        float_workspace_buffer: torch.Tensor,
        int_workspace_buffer: torch.Tensor,
        plan_info_vec: List[int],
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        qo_indptr: torch.Tensor,
        kv_indptr: torch.Tensor,
        o: torch.Tensor,
        maybe_lse: Optional[torch.Tensor],
        mask_mode: int,
        layout: int,
        window_left: int,
        enable_pdl: bool,
        maybe_custom_mask: Optional[torch.Tensor],
        maybe_mask_indptr: Optional[torch.Tensor],
        maybe_alibi_slopes: Optional[torch.Tensor],
        maybe_prefix_len_ptr: Optional[torch.Tensor],
        maybe_token_pos_in_items_ptr: Optional[torch.Tensor],
        maybe_max_item_len_ptr: Optional[torch.Tensor],
        logits_soft_cap: float,
        sm_scale: float,
        rope_scale: float,
        rope_theta: float,
        token_pos_in_items_len: int,
        maybe_k_cache_sf: Optional[torch.Tensor] = None,
        maybe_v_cache_sf: Optional[torch.Tensor] = None,
        scale_q: Optional[torch.Tensor] = None,
        scale_k: Optional[torch.Tensor] = None,
        scale_v: Optional[torch.Tensor] = None,
    ) -> None:
        # Check if FP8 by presence of scale tensors
        is_fp8 = scale_q is not None

        if backend == "fa2":
            ragged_run_func(
                float_workspace_buffer,
                int_workspace_buffer,
                plan_info_vec,
                q,
                k,
                v,
                qo_indptr,
                kv_indptr,
                o,
                maybe_lse,
                mask_mode,
                layout,
                window_left,
                enable_pdl,
                maybe_custom_mask,
                maybe_mask_indptr,
                maybe_alibi_slopes,
                maybe_prefix_len_ptr,
                maybe_token_pos_in_items_ptr,
                maybe_max_item_len_ptr,
                maybe_k_cache_sf,
                maybe_v_cache_sf,
                logits_soft_cap,
                sm_scale,
                1.0 / rope_scale,  # rope_rcp_scale
                1.0 / rope_theta,  # rope_rcp_theta,
                token_pos_in_items_len,
            )
        elif is_fp8:
            # FA3 FP8: scale_q, scale_k, scale_v, sm_scale, scale_q_scalar, scale_k_scalar, scale_v_scalar
            scale_q_tensor, scale_q_scalar = _split_scale_param(scale_q)
            scale_k_tensor, scale_k_scalar = _split_scale_param(scale_k)
            scale_v_tensor, scale_v_scalar = _split_scale_param(scale_v)
            ragged_run_func(
                float_workspace_buffer,
                int_workspace_buffer,
                plan_info_vec,
                q,
                k,
                v,
                qo_indptr,
                kv_indptr,
                o,
                maybe_lse,
                mask_mode,
                layout,
                window_left,
                enable_pdl,
                scale_q_tensor,
                scale_k_tensor,
                scale_v_tensor,
                sm_scale,
                scale_q_scalar,
                scale_k_scalar,
                scale_v_scalar,
            )
        else:
            # FA3 FP16: maybe_prefix_len_ptr, maybe_token_pos_in_items_ptr,
            # maybe_max_item_len_ptr, scale_v, logits_soft_cap, sm_scale, scale_v_scalar, token_pos_in_items_len
            scale_v_tensor, scale_v_scalar = _split_scale_param(scale_v)
            ragged_run_func(
                float_workspace_buffer,
                int_workspace_buffer,
                plan_info_vec,
                q,
                k,
                v,
                qo_indptr,
                kv_indptr,
                o,
                maybe_lse,
                mask_mode,
                layout,
                window_left,
                enable_pdl,
                maybe_prefix_len_ptr,
                maybe_token_pos_in_items_ptr,
                maybe_max_item_len_ptr,
                scale_v_tensor,
                logits_soft_cap,
                sm_scale,
                scale_v_scalar,
                token_pos_in_items_len,
            )

        return o

    @register_fake_op(f"flashinfer::{uri}_ragged_run")
    def _fake_ragged_run(
        float_workspace_buffer: torch.Tensor,
        int_workspace_buffer: torch.Tensor,
        plan_info_vec: List[int],
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        qo_indptr: torch.Tensor,
        kv_indptr: torch.Tensor,
        o: torch.Tensor,
        maybe_lse: Optional[torch.Tensor],
        mask_mode: int,
        layout: int,
        window_left: int,
        enable_pdl: bool,
        maybe_custom_mask: Optional[torch.Tensor],
        maybe_mask_indptr: Optional[torch.Tensor],
        maybe_alibi_slopes: Optional[torch.Tensor],
        maybe_prefix_len_ptr: Optional[torch.Tensor],
        maybe_token_pos_in_items_ptr: Optional[torch.Tensor],
        maybe_max_item_len_ptr: Optional[torch.Tensor],
        logits_soft_cap: float,
        sm_scale: float,
        rope_scale: float,
        rope_theta: float,
        token_pos_in_items_len: int,
        maybe_k_cache_sf: Optional[torch.Tensor] = None,
        maybe_v_cache_sf: Optional[torch.Tensor] = None,
    ) -> None:
        pass

    # torch library for paged_run

    @register_custom_op(
        f"flashinfer::{uri}_paged_run",
        mutates_args=(
            "float_workspace_buffer",
            "int_workspace_buffer",
            "multi_ctas_kv_counter_buffer",
            "paged_k_cache",
            "paged_v_cache",
            "o",
            "maybe_lse",
        ),
    )
    def paged_run(
        float_workspace_buffer: torch.Tensor,
        int_workspace_buffer: torch.Tensor,
        plan_info_vec: List[int],
        q: torch.Tensor,
        paged_k_cache: torch.Tensor,
        paged_v_cache: torch.Tensor,
        qo_indptr: torch.Tensor,
        paged_kv_indptr: torch.Tensor,
        paged_kv_indices: torch.Tensor,
        paged_kv_last_page_len: torch.Tensor,
        o: torch.Tensor,
        maybe_lse: Optional[torch.Tensor],
        mask_mode: int,
        layout: int,
        window_left: int,
        enable_pdl: bool,
        maybe_custom_mask: Optional[torch.Tensor],
        maybe_mask_indptr: Optional[torch.Tensor],
        maybe_alibi_slopes: Optional[torch.Tensor],
        maybe_prefix_len_ptr: Optional[torch.Tensor],
        maybe_token_pos_in_items_ptr: Optional[torch.Tensor],
        maybe_max_item_len_ptr: Optional[torch.Tensor],
        logits_soft_cap: float,
        sm_scale: float,
        scale_q: Optional[torch.Tensor],
        scale_k: Optional[torch.Tensor],
        scale_v: Optional[torch.Tensor],
        rope_scale: float,
        rope_theta: float,
        token_pos_in_items_len: int,
        workspace_size: int,
        num_qo_heads: Optional[int] = None,
        num_kv_heads: Optional[int] = None,
        block_tables: Optional[torch.Tensor] = None,
        kv_lens_buffer: Optional[torch.Tensor] = None,
        page_size: Optional[int] = None,
        max_q_len: Optional[int] = None,
        max_kv_len: Optional[int] = None,
        batch_size: Optional[int] = None,
        cum_seq_lens_q: Optional[torch.Tensor] = None,
        cum_seq_lens_kv: Optional[torch.Tensor] = None,
        sinks: Optional[torch.Tensor] = None,
        key_block_scales: Optional[torch.Tensor] = None,
        value_block_scales: Optional[torch.Tensor] = None,
        skip_softmax_threshold_scale_factor: Optional[float] = None,
        uses_shared_paged_kv_idx: bool = True,
        use_fp16_softmax: Optional[bool] = None,
        uses_spcompress: Optional[bool] = None,
        multi_ctas_kv_counter_buffer: Optional[torch.Tensor] = None,
    ) -> None:
        if backend == "trtllm-gen":
            assert num_qo_heads is not None
            assert num_kv_heads is not None
            assert block_tables is not None
            assert kv_lens_buffer is not None
            assert page_size is not None
            assert max_kv_len is not None
            assert batch_size is not None
            assert cum_seq_lens_q is not None
            assert cum_seq_lens_kv is not None
            assert enable_pdl is not None
            assert multi_ctas_kv_counter_buffer is not None
            assert workspace_size > 0, "workspace_size must be greater than 0"
            o = paged_run_func(
                q.contiguous(),  # NOTE(Siyuan): without contiguous, the result is incorrect
                paged_k_cache,
                paged_v_cache,
                int_workspace_buffer,
                block_tables,
                kv_lens_buffer,
                max_q_len,
                max_kv_len,
                sm_scale,
                1.0,  # NOTE(Siyuan): update this to expose bmm2 scale
                batch_size,
                cum_seq_lens_q,
                cum_seq_lens_kv,
                enable_pdl,
                workspace_size,
                window_left,
                out=o,
                sinks=sinks,
                key_block_scales=key_block_scales,
                value_block_scales=value_block_scales,
                skip_softmax_threshold_scale_factor=skip_softmax_threshold_scale_factor,
                uses_shared_paged_kv_idx=uses_shared_paged_kv_idx,
                use_fp16_softmax=use_fp16_softmax,
                uses_spcompress=uses_spcompress,
                is_causal=mask_mode != MaskMode.NON_CAUSAL.value,
                lse=maybe_lse,
                multi_ctas_kv_counter_buffer=multi_ctas_kv_counter_buffer,
            )
        elif backend == "fa2":
            assert not is_float8(q)
            if tuple(paged_k_cache.stride()) == tuple(paged_v_cache.stride()):
                routed_paged_run_func = paged_run_func
            else:
                assert lazy_independent_module is not None
                routed_paged_run_func = lazy_independent_module.get(q.device).paged_run
            routed_paged_run_func(
                float_workspace_buffer,
                int_workspace_buffer,
                plan_info_vec,
                q,
                paged_k_cache,
                paged_v_cache,
                qo_indptr,
                paged_kv_indptr,
                paged_kv_indices,
                paged_kv_last_page_len,
                o,
                maybe_lse,
                mask_mode,
                layout,
                window_left,
                enable_pdl,
                maybe_custom_mask,
                maybe_mask_indptr,
                maybe_alibi_slopes,
                maybe_prefix_len_ptr,
                maybe_token_pos_in_items_ptr,
                maybe_max_item_len_ptr,
                key_block_scales,
                value_block_scales,
                logits_soft_cap,
                sm_scale,
                1.0 / rope_scale,  # rope_rcp_scale
                1.0 / rope_theta,  # rope_rcp_theta
                token_pos_in_items_len,
            )
        else:
            scale_v_tensor, scale_v_scalar = _split_scale_param(scale_v)
            if not is_float8(q):
                paged_run_func(
                    float_workspace_buffer,
                    int_workspace_buffer,
                    plan_info_vec,
                    q,
                    paged_k_cache,
                    paged_v_cache,
                    qo_indptr,
                    paged_kv_indptr,
                    paged_kv_indices,
                    paged_kv_last_page_len,
                    o,
                    maybe_lse,
                    mask_mode,
                    layout,
                    window_left,
                    enable_pdl,
                    maybe_prefix_len_ptr,
                    maybe_token_pos_in_items_ptr,
                    maybe_max_item_len_ptr,
                    scale_v_tensor,
                    logits_soft_cap,
                    sm_scale,
                    scale_v_scalar,
                    token_pos_in_items_len,
                )
            else:
                scale_q_tensor, scale_q_scalar = _split_scale_param(scale_q)
                scale_k_tensor, scale_k_scalar = _split_scale_param(scale_k)
                paged_run_func(
                    float_workspace_buffer,
                    int_workspace_buffer,
                    plan_info_vec,
                    q,
                    paged_k_cache,
                    paged_v_cache,
                    qo_indptr,
                    paged_kv_indptr,
                    paged_kv_indices,
                    paged_kv_last_page_len,
                    o,
                    maybe_lse,
                    mask_mode,
                    layout,
                    window_left,
                    enable_pdl,
                    scale_q_tensor,
                    scale_k_tensor,
                    scale_v_tensor,
                    sm_scale,
                    scale_q_scalar,
                    scale_k_scalar,
                    scale_v_scalar,
                )
        return o

    @register_fake_op(f"flashinfer::{uri}_paged_run")
    def _fake_paged_run(
        float_workspace_buffer: torch.Tensor,
        int_workspace_buffer: torch.Tensor,
        plan_info_vec: List[int],
        q: torch.Tensor,
        paged_k_cache: torch.Tensor,
        paged_v_cache: torch.Tensor,
        qo_indptr: torch.Tensor,
        paged_kv_indptr: torch.Tensor,
        paged_kv_indices: torch.Tensor,
        paged_kv_last_page_len: torch.Tensor,
        o: torch.Tensor,
        maybe_lse: Optional[torch.Tensor],
        mask_mode: int,
        layout: int,
        window_left: int,
        enable_pdl: bool,
        maybe_custom_mask: Optional[torch.Tensor],
        maybe_mask_indptr: Optional[torch.Tensor],
        maybe_alibi_slopes: Optional[torch.Tensor],
        maybe_prefix_len_ptr: Optional[torch.Tensor],
        maybe_token_pos_in_items_ptr: Optional[torch.Tensor],
        maybe_max_item_len_ptr: Optional[torch.Tensor],
        logits_soft_cap: float,
        sm_scale: float,
        scale_q: Optional[torch.Tensor],
        scale_k: Optional[torch.Tensor],
        scale_v: Optional[torch.Tensor],
        rope_scale: float,
        rope_theta: float,
        token_pos_in_items_len: int,
        workspace_size: int,
        num_qo_heads: Optional[int] = None,
        num_kv_heads: Optional[int] = None,
        block_tables: Optional[torch.Tensor] = None,
        kv_lens_buffer: Optional[torch.Tensor] = None,
        page_size: Optional[int] = None,
        max_q_len: Optional[int] = None,
        max_kv_len: Optional[int] = None,
        batch_size: Optional[int] = None,
        cum_seq_lens_q: Optional[torch.Tensor] = None,
        cum_seq_lens_kv: Optional[torch.Tensor] = None,
        sinks: Optional[torch.Tensor] = None,
        key_block_scales: Optional[torch.Tensor] = None,
        value_block_scales: Optional[torch.Tensor] = None,
        skip_softmax_threshold_scale_factor: Optional[float] = None,
        uses_shared_paged_kv_idx: bool = True,
        use_fp16_softmax: Optional[bool] = None,
        uses_spcompress: Optional[bool] = None,
        multi_ctas_kv_counter_buffer: Optional[torch.Tensor] = None,
    ) -> None:
        pass

    # Register the module.
    #
    # Note that plan is not part of model logic. It should not be included in
    # Cuda Graph or torch.compile. So, we don't provide a torch library for plan.
    def prewarm_paged_kv_stride_variant(variant: str = "independent") -> None:
        """Load the requested lazy paged-KV-stride variant before graph capture."""
        if variant != "independent":
            raise ValueError(f"variant must be 'independent', got {variant!r}")
        if lazy_independent_module is None:
            raise RuntimeError(
                "Paged-KV-stride prewarm is available only for standard FA2 "
                f"batch-prefill modules, got backend={backend!r}."
            )
        lazy_independent_module.prewarm()

    return SimpleNamespace(
        plan=plan_func,
        workspace_size=workspace_size_func,
        ragged_run=ragged_run,
        paged_run=paged_run,
        prewarm_paged_kv_stride_variant=prewarm_paged_kv_stride_variant,
    )


@functools.cache
def get_batch_prefill_jit_module(module_name: str, jit_module: Any):
    plan_func = jit_module.plan
    workspace_size_func = getattr(jit_module, "workspace_size", None)
    ragged_run_func = jit_module.ragged_run
    paged_run_func = jit_module.paged_run

    # torch library for ragged_run
    @register_custom_op(
        f"flashinfer::{module_name}_ragged_run",
        mutates_args=(
            "float_workspace_buffer",
            "int_workspace_buffer",
            "o",
            "maybe_lse",
        ),
    )
    def ragged_run(
        float_workspace_buffer: torch.Tensor,
        int_workspace_buffer: torch.Tensor,
        plan_info_vec: List[int],
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        qo_indptr: torch.Tensor,
        kv_indptr: torch.Tensor,
        o: torch.Tensor,
        maybe_lse: Optional[torch.Tensor],
        mask_mode: int,
        layout: int,
        window_left: int,
        *args,
    ) -> None:
        ragged_run_func(
            float_workspace_buffer,
            int_workspace_buffer,
            plan_info_vec,
            q,
            k,
            v,
            qo_indptr,
            kv_indptr,
            o,
            maybe_lse,
            mask_mode,
            layout,
            window_left,
            *args,
        )

    @register_fake_op(f"flashinfer::{module_name}_ragged_run")
    def _fake_ragged_run(
        float_workspace_buffer: torch.Tensor,
        int_workspace_buffer: torch.Tensor,
        plan_info_vec: List[int],
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        qo_indptr: torch.Tensor,
        kv_indptr: torch.Tensor,
        o: torch.Tensor,
        maybe_lse: Optional[torch.Tensor],
        mask_mode: int,
        layout: int,
        window_left: int,
        *args,
    ) -> None:
        pass

    # torch library for paged_run
    @register_custom_op(
        f"flashinfer::{module_name}_paged_run",
        mutates_args=(
            "float_workspace_buffer",
            "int_workspace_buffer",
            "paged_k_cache",
            "paged_v_cache",
            "o",
            "maybe_lse",
        ),
    )
    def paged_run(
        float_workspace_buffer: torch.Tensor,
        int_workspace_buffer: torch.Tensor,
        plan_info_vec: List[int],
        q: torch.Tensor,
        paged_k_cache: torch.Tensor,
        paged_v_cache: torch.Tensor,
        qo_indptr: torch.Tensor,
        paged_kv_indptr: torch.Tensor,
        paged_kv_indices: torch.Tensor,
        paged_kv_last_page_len: torch.Tensor,
        o: torch.Tensor,
        maybe_lse: Optional[torch.Tensor],
        mask_mode: int,
        layout: int,
        window_left: int,
        *args,
    ) -> None:
        paged_run_func(
            float_workspace_buffer,
            int_workspace_buffer,
            plan_info_vec,
            q,
            paged_k_cache,
            paged_v_cache,
            qo_indptr,
            paged_kv_indptr,
            paged_kv_indices,
            paged_kv_last_page_len,
            o,
            maybe_lse,
            mask_mode,
            layout,
            window_left,
            *args,
        )

    @register_fake_op(f"flashinfer::{module_name}_paged_run")
    def _fake_paged_run(
        float_workspace_buffer: torch.Tensor,
        int_workspace_buffer: torch.Tensor,
        plan_info_vec: List[int],
        q: torch.Tensor,
        paged_k_cache: torch.Tensor,
        paged_v_cache: torch.Tensor,
        qo_indptr: torch.Tensor,
        paged_kv_indptr: torch.Tensor,
        paged_kv_indices: torch.Tensor,
        paged_kv_last_page_len: torch.Tensor,
        o: torch.Tensor,
        maybe_lse: Optional[torch.Tensor],
        mask_mode: int,
        layout: int,
        window_left: int,
        *args,
    ) -> None:
        pass

    # Register the module.
    #
    # Note that plan is not part of model logic. It should not be included in
    # Cuda Graph or torch.compile. So, we don't provide a torch library for plan.
    return SimpleNamespace(
        plan=plan_func,
        workspace_size=workspace_size_func,
        ragged_run=ragged_run,
        paged_run=paged_run,
    )


@flashinfer_api
def single_prefill_with_kv_cache_with_jit_module(
    jit_module: Any,
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    *args,
    kv_layout: str = "NHD",
    mask_mode: int = MaskMode.NON_CAUSAL.value,
    window_left: int = -1,
    return_lse: bool = False,
) -> Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
    r"""Single-request prefill / append attention using a pre-compiled JIT module.

    Low-level entry point used by :func:`single_prefill_with_kv_cache` after backend
    dispatch; user code should normally call ``single_prefill_with_kv_cache`` directly.
    Exposed for advanced users who already hold a compiled JIT module (for example to
    customize the attention variant via extra kernel arguments).

    Parameters
    ----------
    jit_module : Any
        Compiled JIT module returned by one of the ``gen_*_module`` factories.
    q : torch.Tensor
        Query tensor, shape ``[qo_len, num_qo_heads, head_dim_qk]``.
    k : torch.Tensor
        Key tensor, shape ``[kv_len, num_kv_heads, head_dim_qk]`` (``NHD``) or
        ``[num_kv_heads, kv_len, head_dim_qk]`` (``HND``).
    v : torch.Tensor
        Value tensor, layout matches ``k``; last dimension may differ when
        ``head_dim_vo != head_dim_qk``.
    *args
        Extra positional arguments forwarded to the JIT module's ``run`` symbol
        (e.g. soft-cap, sink, or custom-mask buffers required by the chosen variant).
    kv_layout : str
        Layout of ``k`` and ``v``, either ``"NHD"`` or ``"HND"``.  Defaults to ``"NHD"``.
    mask_mode : int
        Mask mode, one of the values defined by :class:`~flashinfer.utils.MaskMode`.
        Defaults to ``MaskMode.NON_CAUSAL.value``.
    window_left : int
        Left window size for sliding-window attention; ``-1`` disables it.
    return_lse : bool
        Whether to allocate and return the log-sum-exp tensor.  Defaults to ``False``.

    Returns
    -------
    Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]
        If ``return_lse`` is ``False``, the attention output tensor.  Otherwise the
        ``(output, lse)`` pair, where ``lse`` has shape
        ``[qo_len, num_qo_heads]`` and dtype ``float32``.
    """
    device = q.device
    tmp = torch.empty(SINGLE_KERNEL_TMP_SIZE, dtype=torch.uint8, device=device)
    o = torch.empty(q.shape[:-1] + v.shape[-1:], dtype=q.dtype, device=device)
    lse = None
    if return_lse:
        lse = torch.empty((q.size(0), q.size(1)), dtype=torch.float32, device=device)
    jit_module.run(
        q,
        k,
        v,
        tmp,
        o,
        lse,
        mask_mode,
        TensorLayout[kv_layout].value,
        window_left,
        *args,
    )
    return (o, lse) if return_lse else o


@overload
def single_prefill_with_kv_cache(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    scale_q: Optional[torch.Tensor] = None,
    scale_k: Optional[torch.Tensor] = None,
    scale_v: Optional[torch.Tensor] = None,
    o_dtype: Optional[torch.dtype] = None,
    custom_mask: Optional[torch.Tensor] = None,
    packed_custom_mask: Optional[torch.Tensor] = None,
    causal: bool = False,
    kv_layout: str = "NHD",
    pos_encoding_mode: str = "NONE",
    use_fp16_qk_reduction: bool = False,
    sm_scale: Optional[float] = None,
    window_left: int = -1,
    logits_soft_cap: Optional[float] = None,
    rope_scale: Optional[float] = None,
    rope_theta: Optional[float] = None,
    backend: str = "auto",
    return_lse: Literal[False] = False,
    kv_cache_sf: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
    k_scale: Optional[float] = None,
    v_scale: Optional[float] = None,
) -> torch.Tensor: ...


@overload
def single_prefill_with_kv_cache(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    scale_q: Optional[torch.Tensor] = None,
    scale_k: Optional[torch.Tensor] = None,
    scale_v: Optional[torch.Tensor] = None,
    o_dtype: Optional[torch.dtype] = None,
    custom_mask: Optional[torch.Tensor] = None,
    packed_custom_mask: Optional[torch.Tensor] = None,
    causal: bool = False,
    kv_layout: str = "NHD",
    pos_encoding_mode: str = "NONE",
    use_fp16_qk_reduction: bool = False,
    sm_scale: Optional[float] = None,
    window_left: int = -1,
    logits_soft_cap: Optional[float] = None,
    rope_scale: Optional[float] = None,
    rope_theta: Optional[float] = None,
    backend: str = "auto",
    return_lse: Literal[True] = True,
    kv_cache_sf: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
    k_scale: Optional[float] = None,
    v_scale: Optional[float] = None,
) -> Tuple[torch.Tensor, torch.Tensor]: ...


@flashinfer_api(trace=single_prefill_with_kv_cache_trace)
def single_prefill_with_kv_cache(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    scale_q: Optional[torch.Tensor] = None,
    scale_k: Optional[torch.Tensor] = None,
    scale_v: Optional[torch.Tensor] = None,
    o_dtype: Optional[torch.dtype] = None,
    custom_mask: Optional[torch.Tensor] = None,
    packed_custom_mask: Optional[torch.Tensor] = None,
    causal: bool = False,
    kv_layout: str = "NHD",
    pos_encoding_mode: str = "NONE",
    use_fp16_qk_reduction: bool = False,
    sm_scale: Optional[float] = None,
    window_left: int = -1,
    logits_soft_cap: Optional[float] = None,
    rope_scale: Optional[float] = None,
    rope_theta: Optional[float] = None,
    backend: str = "auto",
    return_lse: bool = False,
    kv_cache_sf: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
    k_scale: Optional[float] = None,
    v_scale: Optional[float] = None,
) -> Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
    r"""Prefill/Append attention with KV cache for single request, return the attention
    output.

    Parameters
    ----------
    q : torch.Tensor
        The query tensor, shape: ``[qo_len, num_qo_heads, head_dim_qk]``.
    k : torch.Tensor
        The key tensor, shape: ``[kv_len, num_kv_heads, head_dim_qk]`` if :attr:`kv_layout`
        is ``NHD``, or ``[num_kv_heads, kv_len, head_dim_qk]`` if :attr:`kv_layout` is
        ``HND``.
    v : torch.Tensor
        The key tensor, shape: ``[kv_len, num_kv_heads, head_dim_vo]`` if :attr:`kv_layout`
        is ``NHD``, ``[num_kv_heads, kv_len, head_dim_vo]`` if :attr:`kv_layout` is
        ``HND``.
    scale_q : Optional[torch.Tensor]
        The scale tensor for query, per-head quantization with shape: ``[num_qo_heads]``.
        Used with FP8 Quantization. If not provided, will be set to ``1.0``.
    scale_k : Optional[torch.Tensor]
        The scale tensor for key, per-head quantization with shape: ``[num_kv_heads]``.
        Used with FP8 Quantization. If not provided, will be set to ``1.0``.
    scale_v : Optional[torch.Tensor]
        The scale tensor for value, per-head quantization with shape: ``[num_kv_heads]``.
        Used with FP8 Quantization. If not provided, will be set to ``1.0``.
    o_dtype : Optional[torch.dtype]
        The output tensor data type, if not provided, will be set to the same as the q.
        This is necessary as output dtype cannot be automatically inferred in quant.
    custom_mask : Optional[torch.Tensor]
        The custom boolean mask tensor, shape: ``[qo_len, kv_len]``.
        The elements in the mask tensor should be either ``True`` or ``False``,
        where ``False`` means the corresponding element in the attention matrix will be
        masked out.

        When :attr:`custom_mask` is provided, and :attr:`packed_custom_mask` is not, the
        function will pack the custom mask tensor into a 1D packed mask tensor, which introduces
        additional overhead.
    packed_custom_mask : Optional[torch.Tensor]
        The 1D packed uint8 mask tensor, if provided, the :attr:`custom_mask` will be ignored.
        The packed mask tensor is generated by :func:`flashinfer.quantization.packbits`.
    causal : bool
        Whether to apply causal mask to the attention matrix.
        This is only effective when :attr:`custom_mask` is not provided.
    kv_layout : str
        The layout of the input k/v tensors, could be either ``NHD`` or ``HND``.
    pos_encoding_mode : str
        The position encoding applied inside attention kernels, could be
        ``NONE``/``ROPE_LLAMA`` (LLAMA style rotary embedding) /``ALIBI``.
        Default is ``NONE``.
    use_fp16_qk_reduction : bool
        Whether to use f16 for qk reduction (faster at the cost of slight precision
        loss).
    window_left : int
        The left (inclusive) window size for the attention window, when set to ``-1``, the window
        size will be set to the full length of the sequence. Defaults to ``-1``.
    logits_soft_cap : Optional[float]
        The attention logits soft capping value (used in Gemini, Grok and Gemma-2, etc.), if not
        provided, will be set to ``0``. If greater than 0, the logits will be capped according to
        formula:
        :math:`\texttt{logits_soft_cap} \times \mathrm{tanh}(x / \texttt{logits_soft_cap})`,
        where :math:`x` is the input logits.
    sm_scale : Optional[float]
        The scale used in softmax, if not provided, will be set to ``1.0 / sqrt(head_dim_qk)``.
    rope_scale : Optional[float]
        The scale used in RoPE interpolation, if not provided, will be set to 1.0.
    rope_theta : Optional[float]
        The theta used in RoPE, if not provided, will be set to 1e4.
    backend : str
        The implementation backend, could be ``auto``/``fa2`` or ``fa3``. Defaults to ``auto``.
        If set to ``auto``, the function will automatically choose the backend based on the
        device architecture and kernel availability.
    return_lse : bool
        Whether to return the log sum exp value of the attention logits.
    kv_cache_sf : Optional[Tuple[torch.Tensor, torch.Tensor]]
        Per-block scale factors for NVFP4 KV cache, as a tuple of ``(k_scales, v_scales)``.
        When provided, ``k`` and ``v`` are expected to be packed uint8 FP4 tensors with last
        dimension ``head_dim // 2``, and the scale factors dequantize them before attention.
        Both ``k_scales`` and ``v_scales`` use a linear (row-major) layout, and both have dtype ``torch.float8_e4m3fn``.

        Currently, NVFP4 KV only supports `fa2` backend.
    k_scale : Optional[Union[float, torch.Tensor]]
        The calibration scale of key for fp8 or nvfp4 input, if not provided, will be set to ``1.0``.
    v_scale : Optional[Union[float, torch.Tensor]]
        The calibration scale of value for fp8 or nvfp4 input, if not provided, will be set to ``1.0``.

    Returns
    -------
    Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]
        If :attr:`return_lse` is ``False``, the attention output, shape: ``[qo_len, num_qo_heads, head_dim_vo]``.
        If :attr:`return_lse` is ``True``, a tuple of two tensors:

        * The attention output, shape: ``[qo_len, num_qo_heads, head_dim_vo]``.
        * The log sum exp value, shape: ``[qo_len, num_qo_heads]``.

    Examples
    --------

    >>> import torch
    >>> import flashinfer
    >>> qo_len = 128
    >>> kv_len = 4096
    >>> num_qo_heads = 32
    >>> num_kv_heads = 4
    >>> head_dim = 128
    >>> q = torch.randn(qo_len, num_qo_heads, head_dim).half().to("cuda:0")
    >>> k = torch.randn(kv_len, num_kv_heads, head_dim).half().to("cuda:0")
    >>> v = torch.randn(kv_len, num_kv_heads, head_dim).half().to("cuda:0")
    >>> o = flashinfer.single_prefill_with_kv_cache(q, k, v, causal=True,
            use_fp16_qk_reduction=True)
    >>> o.shape
    torch.Size([128, 32, 128])
    >>> mask = torch.tril(
    >>>     torch.full((qo_len, kv_len), True, device="cuda:0"),
    >>>     diagonal=(kv_len - qo_len),
    >>> )
    >>> mask
    tensor([[ True,  True,  True,  ..., False, False, False],
            [ True,  True,  True,  ..., False, False, False],
            [ True,  True,  True,  ..., False, False, False],
            ...,
            [ True,  True,  True,  ...,  True, False, False],
            [ True,  True,  True,  ...,  True,  True, False],
            [ True,  True,  True,  ...,  True,  True,  True]], device='cuda:0')
    >>> o_custom = flashinfer.single_prefill_with_kv_cache(q, k, v, custom_mask=mask)
    >>> torch.allclose(o, o_custom, rtol=1e-3, atol=1e-3)
    True

    Note
    ----
    The ``num_qo_heads`` must be a multiple of ``num_kv_heads``. If ``num_qo_heads`` is
    not equal to ``num_kv_heads``, the function will use
    `grouped query attention <https://arxiv.org/abs/2305.13245>`_.
    """
    _check_pos_encoding_mode(pos_encoding_mode)
    _check_kv_layout(kv_layout)
    tmp = torch.empty(SINGLE_KERNEL_TMP_SIZE, dtype=torch.uint8, device=q.device)
    if logits_soft_cap is None:
        logits_soft_cap = 0.0
    if sm_scale is None:
        sm_scale = 1.0 / math.sqrt(q.size(-1))
    if rope_scale is None:
        rope_scale = 1.0
    if rope_theta is None:
        rope_theta = 1e4
    if custom_mask is not None and packed_custom_mask is None:
        # create packed custom mask from custom mask
        packed_custom_mask = packbits(
            custom_mask.contiguous().view(-1), bitorder="little"
        )

    if packed_custom_mask is not None:
        mask_mode = MaskMode.CUSTOM.value
    else:
        if causal:
            mask_mode = MaskMode.CAUSAL.value
        else:
            mask_mode = MaskMode.NON_CAUSAL.value

    lse = None
    if return_lse:
        lse = torch.empty((q.size(0), q.size(1)), dtype=torch.float32, device=q.device)

    if is_float8(q):
        # FP8 quant enabled, do sanity check:
        #   1. unsupported feature
        #   2. dtype check
        assert window_left == -1
        assert q.dtype == k.dtype == v.dtype
        assert q.shape[-1] == k.shape[-1] == v.shape[-1]
        if scale_q is None:
            scale_q = torch.ones(q.shape[1], dtype=torch.float32, device=q.device)
        if scale_k is None:
            scale_k = torch.ones(k.shape[1], dtype=torch.float32, device=q.device)
        if scale_v is None:
            scale_v = torch.ones(v.shape[1], dtype=torch.float32, device=q.device)

    # For NVFP4 KV (uint8 packed), last dim is head_dim//2 packed bytes: the
    # unpacked VO width is v.shape[-1] * 2, which equals head_dim_vo even for
    # asymmetric (QK, VO) plans; q.shape[-1] assumed QK == VO. Gate on the packed
    # (uint8) storage, not just kv_cache_sf, so a stray scale-factor tensor on a
    # non-uint8 cache cannot silently double the output width.
    out_head_dim = (
        v.shape[-1] * 2
        if kv_cache_sf is not None and v.dtype == torch.uint8
        else v.shape[-1]
    )

    if backend == "auto":
        backend = determine_attention_backend(
            q.device,
            PosEncodingMode[pos_encoding_mode].value,
            use_fp16_qk_reduction,
            packed_custom_mask is not None,  # use_custom_mask
            q.dtype,
            k.dtype,
            head_dim_qk=q.shape[-1],
            head_dim_vo=out_head_dim,
        )

    # Unpack NVFP4 scale factors
    k_sf, v_sf = None, None
    if kv_cache_sf is not None:
        k_sf, v_sf = kv_cache_sf

    if k_scale is not None:
        sm_scale *= k_scale

    # o_dtype should be provided for FP8 attention
    if o_dtype is None:
        o_dtype = q.dtype
    out = torch.empty(q.shape[:-1] + (out_head_dim,), dtype=o_dtype, device=q.device)

    module = get_single_prefill_module(
        backend,
        q.dtype,
        k.dtype,
        out.dtype,
        q.shape[-1],  # head_dim_qk
        out_head_dim,  # head_dim_vo
        PosEncodingMode[pos_encoding_mode].value,
        window_left >= 0,  # use_sliding_window
        logits_soft_cap > 0,  # use_logits_soft_cap
        use_fp16_qk_reduction,
    )

    module.run(
        q,
        k,
        v,
        tmp,
        out,
        lse,
        mask_mode,
        TensorLayout[kv_layout].value,
        window_left,
        packed_custom_mask,
        get_alibi_slopes(q.shape[1], device=q.device)
        if pos_encoding_mode == "ALIBI"
        else None,
        logits_soft_cap,
        sm_scale,
        scale_q,
        scale_k,
        scale_v,
        rope_scale,
        rope_theta,
        k_sf,
        v_sf,
    )

    is_float_one = isinstance(v_scale, float) and v_scale == 1.0
    if v_scale is not None and not is_float_one:
        if is_float8(out):
            out = (out.to(torch.float32) * v_scale).to(out.dtype)
        else:
            out *= v_scale

    return (out, lse) if return_lse else out


single_prefill_with_kv_cache_return_lse = functools.partial(
    single_prefill_with_kv_cache, return_lse=True
)
single_prefill_with_kv_cache_return_lse.__doc__ = """Convenience wrapper for :func:`single_prefill_with_kv_cache` that always returns LSE.

    Equivalent to calling
    :func:`single_prefill_with_kv_cache` with ``return_lse=True``; accepts the
    same arguments and forwards them unchanged. See
    :func:`single_prefill_with_kv_cache` for the full parameter list (including
    FP8 / NVFP4 quantization scales such as ``scale_q``, ``scale_k``,
    ``scale_v``, ``o_dtype``, ``kv_cache_sf``, ``k_scale``, and ``v_scale``).

    Returns
    -------
    Tuple[torch.Tensor, torch.Tensor]
        A pair ``(output, lse)`` where ``output`` is the attention output and
        ``lse`` is the log-sum-exp tensor used for cascade merging.
    """


def _compute_page_mask_indptr(
    qo_indptr: torch.Tensor,
    paged_kv_indptr: torch.Tensor,
    paged_kv_last_page_len: torch.Tensor,
    page_size: int,
) -> torch.Tensor:
    if len(qo_indptr) != len(paged_kv_indptr):
        raise ValueError(
            "The length of qo_indptr and paged_kv_indptr should be the same."
        )
    mask_indptr = torch.empty_like(qo_indptr)
    mask_indptr[0] = 0
    mask_indptr[1:] = torch.cumsum(
        (qo_indptr[1:] - qo_indptr[:-1])
        * (
            (paged_kv_indptr[1:] - paged_kv_indptr[:-1] - 1) * page_size
            + paged_kv_last_page_len
        ),
        0,
    )
    return mask_indptr


# Architectures on which the NVFP4 split-KV corruption was actually observed. Keep this as narrow
# as the evidence: every target added here pays the gate on low-batch decode. Measured on SM90 at
# batch 1, qo_len 1, head_dim 128, page_size 16, bf16: 3.98x at kv_len 8192, 8.14x at kv_len 32768.
_NVFP4_SPLIT_KV_BROKEN_ARCHS = ((12, 0), (12, 1))


def _nvfp4_kv_requires_disabled_split_kv(
    kv_data_type: torch.dtype, device: torch.device
) -> bool:
    """Whether split-KV must be disabled because the KV cache is NVFP4 on an affected arch.

    This gate is an *empirical workaround*: with split-KV (flash-decoding)
    enabled, NVFP4 paged KV was observed to produce corrupted outputs whenever
    a short query attends a long KV range (``qo_len << kv_len``, i.e. decode
    and prefix-cache extend), while dense full-prefill was unaffected.
    Disabling split-KV removes the corruption.

    The root cause has not been confirmed. The FP8 scale-factor blocks
    themselves cannot be the mechanism: NVFP4 scales group 16 consecutive
    *head-dim* elements of a single token, whereas split-KV partitions the
    *token* axis, so a split boundary never slices a scale block. The current
    hypothesis (unconfirmed) is that the small per-split KV chunks interact
    badly with the ``NUM_MMA_KV`` tile floor of the 1-byte-KV FA2 path.

    The corruption was only ever reported on SM120/121, alongside the
    asymmetric VO-split NVFP4 paged prefill path added for those targets, so
    the gate is scoped to them. Pre-SM100 has no native FP4 conversion, so
    every such target runs the same generic 1-byte-KV FA2 path; on that path
    split-KV yields output indistinguishable from the gated result. Review
    reproduced that on SM90 as well, over symmetric ``head_dim`` 128, the
    asymmetric 512/256 path and a needle retrieval swept across split
    boundaries, with the gate-on/gate-off difference staying at output-dtype
    rounding scale. FP8 and 16-bit KV caches were never gated and keep split-KV
    everywhere.
    """
    if not _is_nvfp4_kv_dtype(kv_data_type):
        return False
    return get_compute_capability(device) in _NVFP4_SPLIT_KV_BROKEN_ARCHS


def _host_uniform_q_len(
    uniform_q_len: Optional[int], qo_indptr_host: torch.Tensor
) -> int:
    """Return ``uniform_q_len`` when it is positive and every request in
    ``qo_indptr_host`` has exactly that many query rows, else ``0``. Pure host
    arithmetic on the copy ``plan()`` already makes; no device sync."""
    if uniform_q_len is None:
        return 0
    uniform_q_len = int(uniform_q_len)
    if uniform_q_len <= 0 or qo_indptr_host.numel() < 2:
        return 0
    q_lens = qo_indptr_host[1:] - qo_indptr_host[:-1]
    return uniform_q_len if bool((q_lens == uniform_q_len).all()) else 0


def _resolve_uniform_q_len(
    uniform_q_len: Optional[int],
    qo_indptr_host: torch.Tensor,
    is_cuda_graph_enabled: bool,
    backend: str,
    caller: str,
) -> int:
    """Return the ``uniform_q_len`` value handed to the FA2 planner.

    ``0`` means "no promise": a CUDA-graph plan then sizes its query tile for
    the ragged worst case ``total_num_rows - batch_size + 1`` rows
    (``PrefillSplitQOKVIndptr`` in include/flashinfer/attention/scheduler.cuh).
    A positive value is forwarded only when the backend is ``fa2``, the wrapper
    plans for CUDA-graph replay (the only case in which the scheduler reads the
    hint) and every request in ``qo_indptr_host`` has exactly ``uniform_q_len``
    rows -- the per-request check the scheduler performs itself (with the GQA
    factor cancelled), evaluated here on the host copy ``plan()`` already makes
    so that the C++ error path is never reached: a hint that does not describe
    the batch is dropped with one warning and the plan proceeds as if it had
    not been given.
    """
    if uniform_q_len is None:
        return 0
    uniform_q_len = int(uniform_q_len)
    if uniform_q_len <= 0:
        return 0
    if backend != "fa2" or not is_cuda_graph_enabled:
        # Only the FA2 CUDA-graph planner reads the hint; the eager planner
        # already sizes the tile from the batch's actual query lengths.
        return 0
    q_lens = qo_indptr_host[1:] - qo_indptr_host[:-1]
    if _host_uniform_q_len(uniform_q_len, qo_indptr_host) == 0:
        lo = int(q_lens.min()) if q_lens.numel() else 0
        hi = int(q_lens.max()) if q_lens.numel() else 0
        logger.warning_once(
            "%s: uniform_q_len=%d does not describe this batch (batch_size=%d, "
            "query lengths %d..%d); planning without the hint",
            caller,
            uniform_q_len,
            int(q_lens.numel()),
            lo,
            hi,
        )
        return 0
    return uniform_q_len


# ---------------------------------------------------------------------------
# Specialized SM90 kernel for speculative-decoding target verification over an
# fp8 (e4m3) paged KV cache with a custom mask
# (csrc/eagle_verify_fp8kv_sm90.cu, flashinfer/jit/eagle_verify_fp8kv_sm90.py).
#
# Dispatched from BatchPrefillWithPagedKVCacheWrapper.run() instead of the FA2
# paged kernel when the caller passed ``uniform_q_len == 4`` (the EAGLE verify
# shape: 4 draft tokens per request) and the host batch has exactly 4 query rows
# per request (eager and CUDA-graph plans alike), a custom mask is in use and the geometry
# below holds (4 query heads per KV head on the rank, head_dim 256, page size
# 1, NHD, bf16 q/o, e4m3 KV, compute capability 9.0); every other call takes
# the stock path untouched. The kernel is a numerical drop-in for the FA2
# custom-mask path (bf16 Q x exactly-dequantised e4m3 K with fp32 accumulation,
# fp32 softmax statistics, P rounded once to bf16 before the P.V MMA, fp32 O
# accumulator, fp32 partial-state merge, one final bf16 rounding).
# ``FLASHINFER_DISABLE_EAGLE_VERIFY_FP8KV_SM90=1`` (read at plan and run time)
# routes these calls back to the FA2 kernel; the ``uniform_q_len`` plan hint
# itself is unaffected. The split-KV partial-state workspace is allocated once
# per wrapper at plan time (outside CUDA-graph capture), never in run().
#
# Host-side contract of the device code (asserted here, never read back from
# the device; see the header of the .cu file): qo_indptr must be [0, 4, 8, ...]
# (the kernel derives request r's query rows as 4*r), the packed custom mask
# must be followed by >= 8 readable bytes inside the mask buffer (the kernel
# reads its mask window as two aligned 32-bit words), and the workspace keeps
# every batch x split slot (inactive splits leave their O slot uninitialised
# and publish l = 0; the merge discards it through a select).
# ---------------------------------------------------------------------------
_EAGLE_VERIFY_FP8KV_SM90_DISABLE_ENV = "FLASHINFER_DISABLE_EAGLE_VERIFY_FP8KV_SM90"
_EAGLE_VERIFY_FP8KV_SM90_MASK_TAIL_SLACK_BYTES = 8
_EAGLE_VERIFY_FP8KV_SM90_QO_LEN = 4
_EAGLE_VERIFY_FP8KV_SM90_NUM_QO_HEADS = 4
_EAGLE_VERIFY_FP8KV_SM90_NUM_KV_HEADS = 1
_EAGLE_VERIFY_FP8KV_SM90_HEAD_DIM = 256
_EAGLE_VERIFY_FP8KV_SM90_PAGE_SIZE = 1
_EAGLE_VERIFY_FP8KV_SM90_SM_SCALE = 0.0625  # 1/sqrt(256), folded into the kernel
_EAGLE_VERIFY_FP8KV_SM90_CTAS_PER_SM = 3  # __launch_bounds__(128, 3)
_EAGLE_VERIFY_FP8KV_SM90_COMPUTE_CAPABILITY = (9, 0)

_eagle_verify_fp8kv_sm90_counters: Dict[str, int] = {
    "plans_seen": 0,  # fa2 paged plans that reached the hook
    "plans_not_verify_route": 0,  # no uniform_q_len==4 or no custom mask: silent stock
    "plans_disabled": 0,  # disable switch set at plan time
    "plans_ineligible": 0,  # verify route, but the geometry/contract differs
    "plans_prepared": 0,  # module loaded + workspace ready for this wrapper
    "build_failed": 0,  # JIT build/load failed (falls back, logged once)
    "workspace_allocs": 0,  # persistent partial-state workspace (re)allocations
    "mask_buf_padded": 0,  # eager-mode mask buffer re-allocated with tail slack
    "runs_dispatched": 0,  # specialized kernel launched
    "runs_dispatched_capturing": 0,  # ... of which during CUDA-graph capture
    "runs_disabled": 0,  # disable switch set at run time
    "runs_ineligible": 0,  # prepared plan, but a run-time argument differs
    "runs_capture_unready": 0,  # capturing without a loaded module: fallback
}
_eagle_verify_fp8kv_sm90_module: Any = None
_eagle_verify_fp8kv_sm90_module_error: Optional[str] = None
# (id(module), device_index) pairs whose cudaFuncSetAttribute init has run.
# Keyed by the module object as well as the device so that a replaced module
# (tests, a rebuilt JIT) is initialised again before its first launch.
_eagle_verify_fp8kv_sm90_init_devices: set = set()
_eagle_verify_fp8kv_sm90_announced = False


def _eagle_verify_fp8kv_sm90_disabled() -> bool:
    return os.environ.get(_EAGLE_VERIFY_FP8KV_SM90_DISABLE_ENV, "") not in ("", "0")


def _eagle_verify_fp8kv_sm90_stats() -> Dict[str, Any]:
    """Introspection for benchmarks and tests: per-process plan/run census,
    build state and compile footprint of the specialized SM90 fp8-KV verify
    kernel (one JIT module, two kernels, no per-shape variants)."""
    stats: Dict[str, Any] = dict(_eagle_verify_fp8kv_sm90_counters)
    stats["module_loaded"] = _eagle_verify_fp8kv_sm90_module is not None
    stats["module_error"] = _eagle_verify_fp8kv_sm90_module_error
    stats["compiled_variants"] = 1 if _eagle_verify_fp8kv_sm90_module is not None else 0
    stats["distinct_kernels"] = 2  # split-KV attention + merge
    stats["graph_nodes_per_launch"] = 2
    stats["init_devices"] = sorted(
        {device for _, device in _eagle_verify_fp8kv_sm90_init_devices}
    )
    stats["specialized_dispatches"] = stats["runs_dispatched"]
    return stats


def _reset_eagle_verify_fp8kv_sm90_stats() -> None:
    global _eagle_verify_fp8kv_sm90_announced
    for key in _eagle_verify_fp8kv_sm90_counters:
        _eagle_verify_fp8kv_sm90_counters[key] = 0
    _eagle_verify_fp8kv_sm90_init_devices.clear()
    _eagle_verify_fp8kv_sm90_announced = False


def _get_eagle_verify_fp8kv_sm90_module() -> Any:
    """JIT-build (once per process) and return the module, or None if the build
    failed (counted and logged once; callers fall back to the FA2 kernel)."""
    global _eagle_verify_fp8kv_sm90_module, _eagle_verify_fp8kv_sm90_module_error
    if _eagle_verify_fp8kv_sm90_module is not None:
        return _eagle_verify_fp8kv_sm90_module
    if _eagle_verify_fp8kv_sm90_module_error is not None:
        return None
    try:
        from .jit.eagle_verify_fp8kv_sm90 import gen_eagle_verify_fp8kv_sm90_module

        _eagle_verify_fp8kv_sm90_module = (
            gen_eagle_verify_fp8kv_sm90_module().build_and_load()
        )
    except Exception as exc:  # build or load failure: stock path, say why
        _eagle_verify_fp8kv_sm90_module_error = f"{type(exc).__name__}: {exc}"[:800]
        _eagle_verify_fp8kv_sm90_counters["build_failed"] += 1
        logger.warning_once(
            "eagle_verify_fp8kv_sm90: JIT build failed (%s); the FA2 kernel serves "
            "the target-verify attention",
            _eagle_verify_fp8kv_sm90_module_error,
        )
        return None
    return _eagle_verify_fp8kv_sm90_module


def _eagle_verify_fp8kv_sm90_plan_eligibility(
    backend: str,
    forwarded_uniform_q_len: int,
    has_custom_mask: bool,
    num_qo_heads: int,
    num_kv_heads: int,
    head_dim_qk: int,
    head_dim_vo: int,
    page_size: int,
    q_data_type: torch.dtype,
    kv_data_type: torch.dtype,
    o_data_type: torch.dtype,
    kv_layout: str,
    pos_encoding_mode: str,
    use_fp16_qk_reduction: bool,
    batch_size: int,
    device: torch.device,
) -> Optional[str]:
    """Plan-time guard. Returns None when the plan describes the supported
    verify problem, ``"not_verify_route:..."`` when the call is not a verify
    plan at all (silent stock path) and another reason string when it is the
    verify route but the geometry differs (logged once). Ordered semantics ->
    shapes -> device so the first two groups run GPU-free."""
    if backend != "fa2":
        return "not_verify_route:backend"
    if forwarded_uniform_q_len != _EAGLE_VERIFY_FP8KV_SM90_QO_LEN:
        return "not_verify_route:uniform_q_len"
    if not has_custom_mask:
        return "not_verify_route:no_custom_mask"
    if pos_encoding_mode != "NONE":
        return f"pos_encoding_mode={pos_encoding_mode}"
    if use_fp16_qk_reduction:
        return "use_fp16_qk_reduction"
    if q_data_type != torch.bfloat16:
        return f"q_data_type={q_data_type}"
    if kv_data_type != torch.float8_e4m3fn:
        return f"kv_data_type={kv_data_type}"
    if o_data_type != torch.bfloat16:
        return f"o_data_type={o_data_type}"
    if kv_layout != "NHD":
        return f"kv_layout={kv_layout}"
    if num_qo_heads != _EAGLE_VERIFY_FP8KV_SM90_NUM_QO_HEADS:
        return f"num_qo_heads={num_qo_heads}"
    if num_kv_heads != _EAGLE_VERIFY_FP8KV_SM90_NUM_KV_HEADS:
        return f"num_kv_heads={num_kv_heads}"
    if head_dim_qk != _EAGLE_VERIFY_FP8KV_SM90_HEAD_DIM:
        return f"head_dim_qk={head_dim_qk}"
    if head_dim_vo != _EAGLE_VERIFY_FP8KV_SM90_HEAD_DIM:
        return f"head_dim_vo={head_dim_vo}"
    if page_size != _EAGLE_VERIFY_FP8KV_SM90_PAGE_SIZE:
        return f"page_size={page_size}"
    if batch_size < 1:
        return f"batch_size={batch_size}"
    if device.type != "cuda":
        return f"device={device}"
    capability = get_compute_capability(device)
    if tuple(capability) != _EAGLE_VERIFY_FP8KV_SM90_COMPUTE_CAPABILITY:
        return f"compute_capability={capability}"
    return None


def _eagle_verify_fp8kv_sm90_scale_is_identity(scale: Any) -> bool:
    if scale is None:
        return True
    if isinstance(scale, bool):
        return False
    if isinstance(scale, (int, float)):
        return float(scale) == 1.0
    return False  # tensors (would need a sync to read) -> stock path


def _eagle_verify_fp8kv_sm90_run_eligibility(
    wrapper: Any,
    q: torch.Tensor,
    k_cache: torch.Tensor,
    v_cache: torch.Tensor,
    out: torch.Tensor,
    mask_mode: int,
    window_left: int,
    q_scale: Any,
    k_scale: Any,
    v_scale: Any,
    return_lse: bool,
    sinks: Optional[torch.Tensor],
    kv_cache_sf: Any,
) -> Optional[str]:
    """Run-time guard for a prepared wrapper (``_eagle_verify_fp8kv_sm90_state``
    set at plan time). Semantics first, then shapes/dtypes/strides, device last;
    no device synchronisation anywhere."""
    state = wrapper._eagle_verify_fp8kv_sm90_state
    if getattr(wrapper, "_jit_module", None) is not None:
        return "jit_module"
    if return_lse:
        return "return_lse"
    if sinks is not None:
        return "sinks"
    if kv_cache_sf is not None:
        return "kv_cache_sf"
    if q_scale is not None:
        return "q_scale"
    if not _eagle_verify_fp8kv_sm90_scale_is_identity(k_scale):
        return "k_scale"
    if not _eagle_verify_fp8kv_sm90_scale_is_identity(v_scale):
        return "v_scale"
    if mask_mode != MaskMode.CUSTOM.value:
        return f"mask_mode={mask_mode}"
    if window_left is not None and window_left >= 0:
        return f"window_left={window_left}"
    logits_soft_cap = wrapper._logits_soft_cap
    if logits_soft_cap is not None and logits_soft_cap != 0.0:
        return f"logits_soft_cap={logits_soft_cap}"
    if wrapper._pos_encoding_mode != "NONE":
        return f"pos_encoding_mode={wrapper._pos_encoding_mode}"
    if wrapper._use_fp16_qk_reduction:
        return "use_fp16_qk_reduction"
    sm_scale = wrapper._sm_scale
    if sm_scale is not None and float(sm_scale) != _EAGLE_VERIFY_FP8KV_SM90_SM_SCALE:
        return f"sm_scale={sm_scale}"
    if wrapper._prefix_len_ptr is not None:
        return "prefix_len_ptr"

    batch_size = state.batch_size
    rows = batch_size * _EAGLE_VERIFY_FP8KV_SM90_QO_LEN
    expected_q_shape = (
        rows,
        _EAGLE_VERIFY_FP8KV_SM90_NUM_QO_HEADS,
        _EAGLE_VERIFY_FP8KV_SM90_HEAD_DIM,
    )
    if q.dtype != torch.bfloat16 or tuple(q.shape) != expected_q_shape:
        return f"q shape/dtype {tuple(q.shape)} {q.dtype}"
    if not q.is_contiguous():
        return "q not contiguous"
    if out.dtype != torch.bfloat16 or tuple(out.shape) != expected_q_shape:
        return f"out shape/dtype {tuple(out.shape)} {out.dtype}"
    if not out.is_contiguous():
        return "out not contiguous"
    for name, cache in (("k_cache", k_cache), ("v_cache", v_cache)):
        if cache.dtype != torch.float8_e4m3fn:
            return f"{name} dtype {cache.dtype}"
        if cache.dim() != 4:
            return f"{name} dim {cache.dim()}"
        if (
            cache.shape[1] != _EAGLE_VERIFY_FP8KV_SM90_PAGE_SIZE
            or cache.shape[2] != _EAGLE_VERIFY_FP8KV_SM90_NUM_KV_HEADS
            or cache.shape[3] != _EAGLE_VERIFY_FP8KV_SM90_HEAD_DIM
        ):
            return f"{name} shape {tuple(cache.shape)}"
        # one 256-byte line per slot: the kernel derives the slot address from
        # the slot id alone, so assert the strides it assumes
        if cache.stride(3) != 1 or cache.stride(0) != _EAGLE_VERIFY_FP8KV_SM90_HEAD_DIM:
            return f"{name} strides {tuple(cache.stride())}"
    for name, buf in (
        ("qo_indptr", wrapper._qo_indptr_buf),
        ("paged_kv_indptr", wrapper._paged_kv_indptr_buf),
        ("mask_indptr", wrapper._mask_indptr_buf),
    ):
        if not torch.is_tensor(buf) or buf.dtype != torch.int32 or buf.dim() != 1:
            return f"{name} buffer"
        if buf.numel() < batch_size + 1:
            return f"{name} buffer too short"
        if not buf.is_contiguous():
            return f"{name} buffer not contiguous"
    indices = wrapper._paged_kv_indices_buf
    if (
        not torch.is_tensor(indices)
        or indices.dtype != torch.int32
        or indices.dim() != 1
        or not indices.is_contiguous()
    ):
        return "paged_kv_indices buffer"
    mask = wrapper._custom_mask_buf
    if (
        not torch.is_tensor(mask)
        or mask.dtype != torch.uint8
        or mask.dim() != 1
        or not mask.is_contiguous()
    ):
        return "custom_mask buffer"
    if mask.data_ptr() % 4 != 0:
        # the kernel reads its mask window as 32-bit words aligned relative
        # to the buffer base, so the base itself must be 4-byte aligned
        return "custom_mask buffer not 4-byte aligned"
    if mask.numel() < state.mask_bytes_required:
        # the kernel reads up to 7 bytes past the packed bits (see prepare)
        return f"custom_mask buffer {mask.numel()} < {state.mask_bytes_required} bytes"
    workspace = state.workspace
    if (
        workspace is None
        or workspace.dtype != torch.float32
        or workspace.numel() < state.workspace_floats
    ):
        return "workspace"

    device = q.device
    if device.type != "cuda" or device.index != state.device_index:
        return f"device {device}"
    for name, tensor in (
        ("k_cache", k_cache),
        ("v_cache", v_cache),
        ("out", out),
        ("qo_indptr", wrapper._qo_indptr_buf),
        ("paged_kv_indptr", wrapper._paged_kv_indptr_buf),
        ("paged_kv_indices", indices),
        ("custom_mask", mask),
        ("mask_indptr", wrapper._mask_indptr_buf),
        ("workspace", workspace),
    ):
        if tensor.device != device:
            return f"{name} device {tensor.device}"
    return None


def _eagle_verify_fp8kv_sm90_prepare(
    wrapper: Any,
    forwarded_uniform_q_len: int,
    has_custom_mask: bool,
    num_qo_heads: int,
    num_kv_heads: int,
    head_dim_qk: int,
    head_dim_vo: int,
    page_size: int,
    q_data_type: torch.dtype,
    kv_data_type: torch.dtype,
    o_data_type: torch.dtype,
    pos_encoding_mode: str,
    use_fp16_qk_reduction: bool,
    batch_size: int,
    qo_indptr_host: Optional[torch.Tensor] = None,
    packed_mask_bytes: int = 0,
) -> None:
    """Plan-time half of the dispatch: decide eligibility, JIT-build the module
    (first time in the process), assert the host-side contract of the device
    code (``qo_indptr == [0, 4, 8, ...]`` on the host copy; >= 8 bytes of
    readable tail slack after the ``packed_mask_bytes`` packed mask bytes in the
    wrapper's mask buffer -- a FlashInfer-owned eager-mode buffer is re-allocated
    with the slack, a user-provided CUDA-graph buffer without it makes the plan
    ineligible), opt the kernel into its dynamic shared memory (first time per
    device) and size the persistent partial-state workspace. Everything that
    allocates, compiles or queries the device happens here, outside CUDA-graph
    capture; run() only launches."""
    counters = _eagle_verify_fp8kv_sm90_counters
    wrapper._eagle_verify_fp8kv_sm90_state = None
    counters["plans_seen"] += 1
    if getattr(wrapper, "_jit_module", None) is not None:
        # a wrapper built with jit_args runs a custom attention variant; the
        # specialized kernel implements the stock math only, so it must never
        # replace that variant (silent stock path, like a non-verify plan)
        counters["plans_not_verify_route"] += 1
        return
    try:
        reason = _eagle_verify_fp8kv_sm90_plan_eligibility(
            wrapper._backend,
            forwarded_uniform_q_len,
            has_custom_mask,
            num_qo_heads,
            num_kv_heads,
            head_dim_qk,
            head_dim_vo,
            page_size,
            q_data_type,
            kv_data_type,
            o_data_type,
            wrapper._kv_layout,
            pos_encoding_mode,
            use_fp16_qk_reduction,
            batch_size,
            wrapper.device,
        )
    except Exception as exc:  # a guard failure must never break the stock path
        reason = f"guard_error:{type(exc).__name__}: {exc}"[:300]
    if reason is not None and reason.startswith("not_verify_route:"):
        counters["plans_not_verify_route"] += 1
        return
    if _eagle_verify_fp8kv_sm90_disabled():
        counters["plans_disabled"] += 1
        logger.info_once(
            "eagle_verify_fp8kv_sm90: disabled by %s=%s; the FA2 kernel serves the "
            "target-verify attention",
            _EAGLE_VERIFY_FP8KV_SM90_DISABLE_ENV,
            os.environ.get(_EAGLE_VERIFY_FP8KV_SM90_DISABLE_ENV, ""),
        )
        return
    if reason is not None:
        counters["plans_ineligible"] += 1
        logger.info_once(
            "eagle_verify_fp8kv_sm90: not dispatched for this plan (%s); the FA2 "
            "kernel serves it",
            reason,
        )
        return
    if (
        hasattr(torch.cuda, "is_current_stream_capturing")
        and torch.cuda.is_current_stream_capturing()
    ):
        # never compile or allocate inside a capture; the stock path is baked
        counters["runs_capture_unready"] += 1
        return
    # Host-side contract of the device code (see the .cu header). The C++
    # scheduler has already validated that every request has exactly 4 query
    # rows when uniform_q_len == 4 was forwarded; this re-checks the host copy
    # arithmetically because the kernel derives request r's rows as 4*r.
    contract_reason: Optional[str] = None
    try:
        if qo_indptr_host is None or qo_indptr_host.numel() < batch_size + 1:
            contract_reason = "qo_indptr_host missing"
        else:
            qo_head = qo_indptr_host[: batch_size + 1].to("cpu")
            expected = torch.arange(
                0,
                (batch_size + 1) * _EAGLE_VERIFY_FP8KV_SM90_QO_LEN,
                _EAGLE_VERIFY_FP8KV_SM90_QO_LEN,
                dtype=qo_head.dtype,
            )
            if not torch.equal(qo_head, expected):
                contract_reason = "qo_indptr is not [0, 4, 8, ...]"
    except Exception as exc:  # pragma: no cover - defensive
        contract_reason = f"guard_error:{type(exc).__name__}: {exc}"[:300]
    if contract_reason is not None:
        counters["plans_ineligible"] += 1
        logger.info_once(
            "eagle_verify_fp8kv_sm90: not dispatched for this plan (%s); the FA2 "
            "kernel serves it",
            contract_reason,
        )
        return
    device = wrapper.device
    mask_buf = wrapper._custom_mask_buf
    mask_bytes_required = (
        int(packed_mask_bytes) + _EAGLE_VERIFY_FP8KV_SM90_MASK_TAIL_SLACK_BYTES
    )
    mask_misaligned = mask_buf.data_ptr() % 4 != 0
    if mask_buf.numel() < mask_bytes_required or mask_misaligned:
        if wrapper.is_cuda_graph_enabled:
            # the buffer belongs to the caller (shared with the captured
            # graph); never swap it behind their back -> fail closed, once
            counters["plans_ineligible"] += 1
            if mask_misaligned:
                logger.info_once(
                    "eagle_verify_fp8kv_sm90: not dispatched for this plan "
                    "(custom_mask_buf is not 4-byte aligned; the kernel reads "
                    "the mask as 32-bit words); the FA2 kernel serves it"
                )
            else:
                logger.info_once(
                    "eagle_verify_fp8kv_sm90: not dispatched for this plan "
                    "(custom_mask_buf has %d B of tail slack after the packed mask, "
                    "the kernel needs %d); the FA2 kernel serves it",
                    mask_buf.numel() - int(packed_mask_bytes),
                    _EAGLE_VERIFY_FP8KV_SM90_MASK_TAIL_SLACK_BYTES,
                )
            return
        # eager mode: plan() allocated this buffer itself (exact size), so a
        # padded, aligned copy is ours to make; the FA2 kernel reads only the
        # packed bits
        padded = torch.zeros(
            mask_bytes_required, dtype=torch.uint8, device=mask_buf.device
        )
        padded[: int(packed_mask_bytes)].copy_(mask_buf[: int(packed_mask_bytes)])
        wrapper._custom_mask_buf = padded
        counters["mask_buf_padded"] += 1
    module = _get_eagle_verify_fp8kv_sm90_module()
    if module is None:
        return
    device_index = (
        device.index if device.index is not None else torch.cuda.current_device()
    )
    init_key = (id(module), device_index)
    if init_key not in _eagle_verify_fp8kv_sm90_init_devices:
        module.init(device_index)
        _eagle_verify_fp8kv_sm90_init_devices.add(init_key)
    num_splits = max(
        1,
        ceil_div(
            _EAGLE_VERIFY_FP8KV_SM90_CTAS_PER_SM * get_device_sm_count(device),
            batch_size,
        ),
    )
    workspace_floats = int(module.workspace_floats(batch_size, num_splits))
    workspace = getattr(wrapper, "_eagle_verify_fp8kv_sm90_workspace", None)
    if workspace is None or workspace.numel() < workspace_floats:
        # grows monotonically; in CUDA-graph mode the batch size is fixed, so
        # this happens exactly once per wrapper (before capture)
        workspace = torch.empty(workspace_floats, dtype=torch.float32, device=device)
        wrapper._eagle_verify_fp8kv_sm90_workspace = workspace
        counters["workspace_allocs"] += 1
    wrapper._eagle_verify_fp8kv_sm90_state = SimpleNamespace(
        batch_size=batch_size,
        num_splits=num_splits,
        workspace=workspace,
        workspace_floats=workspace_floats,
        mask_bytes_required=mask_bytes_required,
        device_index=device_index,
    )
    counters["plans_prepared"] += 1


def _eagle_verify_fp8kv_sm90_dispatch(
    wrapper: Any,
    q: torch.Tensor,
    k_cache: torch.Tensor,
    v_cache: torch.Tensor,
    out: torch.Tensor,
    mask_mode: int,
    window_left: int,
    q_scale: Any,
    k_scale: Any,
    v_scale: Any,
    return_lse: bool,
    sinks: Optional[torch.Tensor],
    kv_cache_sf: Any,
) -> bool:
    """Run-time half: launch the specialized kernel into ``out`` and return
    True, or return False (nothing launched) so the caller runs the stock FA2
    kernel. Capture-safe: no allocation, no sync, no compilation."""
    global _eagle_verify_fp8kv_sm90_announced
    state = getattr(wrapper, "_eagle_verify_fp8kv_sm90_state", None)
    if state is None:
        return False
    counters = _eagle_verify_fp8kv_sm90_counters
    if _eagle_verify_fp8kv_sm90_disabled():
        counters["runs_disabled"] += 1
        logger.info_once(
            "eagle_verify_fp8kv_sm90: disabled by %s=%s; the FA2 kernel serves the "
            "target-verify attention",
            _EAGLE_VERIFY_FP8KV_SM90_DISABLE_ENV,
            os.environ.get(_EAGLE_VERIFY_FP8KV_SM90_DISABLE_ENV, ""),
        )
        return False
    try:
        reason = _eagle_verify_fp8kv_sm90_run_eligibility(
            wrapper,
            q,
            k_cache,
            v_cache,
            out,
            mask_mode,
            window_left,
            q_scale,
            k_scale,
            v_scale,
            return_lse,
            sinks,
            kv_cache_sf,
        )
    except Exception as exc:  # a guard failure must never break the stock path
        reason = f"guard_error:{type(exc).__name__}: {exc}"[:300]
    if reason is not None:
        counters["runs_ineligible"] += 1
        logger.info_once(
            "eagle_verify_fp8kv_sm90: not dispatched for this call (%s); the FA2 "
            "kernel serves it",
            reason,
        )
        return False
    module = _eagle_verify_fp8kv_sm90_module
    capturing = bool(
        hasattr(torch.cuda, "is_current_stream_capturing")
        and torch.cuda.is_current_stream_capturing()
    )
    if module is None:
        # prepare() loads the module before it sets the state; this only
        # happens if the module was dropped behind our back
        counters["runs_capture_unready" if capturing else "runs_ineligible"] += 1
        return False
    module.run(
        q,
        k_cache,
        v_cache,
        wrapper._qo_indptr_buf,
        wrapper._paged_kv_indptr_buf,
        wrapper._paged_kv_indices_buf,
        wrapper._custom_mask_buf,
        wrapper._mask_indptr_buf,
        state.workspace,
        out,
        state.batch_size,
        state.num_splits,
    )
    counters["runs_dispatched"] += 1
    if capturing:
        counters["runs_dispatched_capturing"] += 1
    if not _eagle_verify_fp8kv_sm90_announced:
        # one line per process so a measurement can name the kernel behind
        # its numbers (normal operation, hence INFO)
        _eagle_verify_fp8kv_sm90_announced = True
        logger.info(
            "eagle_verify_fp8kv_sm90: serving the target-verify attention "
            "(batch_size=%d, num_splits=%d, cuda_graph=%s)",
            state.batch_size,
            state.num_splits,
            wrapper.is_cuda_graph_enabled,
        )
    return True


def _build_block_tables_from_paged_kv_indices(
    paged_kv_indptr_host: torch.Tensor,
    paged_kv_indices: torch.Tensor,
    batch_size: int,
    device: torch.device,
) -> torch.Tensor:
    """Convert flat paged-KV indices to a shared ``[B, M]`` block table.

    This is the input format consumed by the existing backend and SM120 PRIMS.
    K and V share every logical-to-physical page mapping.
    """
    blocks_per_seq = [
        int(paged_kv_indptr_host[i + 1] - paged_kv_indptr_host[i])
        for i in range(batch_size)
    ]
    max_num_blocks_per_seq = max(blocks_per_seq)
    block_tables = torch.zeros(
        (batch_size, max_num_blocks_per_seq),
        dtype=torch.int32,
        device=device,
    )
    for i, num_blocks_needed in enumerate(blocks_per_seq):
        start = int(paged_kv_indptr_host[i])
        end = int(paged_kv_indptr_host[i + 1])
        block_tables[i, :num_blocks_needed] = paged_kv_indices[start:end]
    return block_tables


# Ragged-prefill `auto` on Blackwell: tried in this order, first eligible wins.
#
# NOTE this is an order over *capability*, not a cost model: the walk returns the
# first backend whose kernel serves the problem, so a backend listed earlier wins
# even where a later one is measurably faster. That is why the order is per-shape
# below rather than a single global tuple.
#
# Measured on B200 (bf16, causal, 20 iters after 5 warmup, medians):
#   d128 square    cuDNN 1.09-1.45x faster than CUTLASS -> cuDNN first
#   d256 square    CUTLASS declines the shape entirely  -> cuDNN only
#   d192/128 MHA   CUTLASS 1.09-1.12x faster than cuDNN -> CUTLASS first
_BLACKWELL_RAGGED_AUTO_PREFERENCE = ("cudnn", "cutlass")

# Per-shape overrides of the default order, keyed on
# (head_dim_qk, head_dim_vo). Deliberately EMPTY: a head-dim key turned out to
# be the wrong granularity.
#
# The 128-head d192/128 cell looked like a clean CUTLASS win at (b16, s4096) --
# 14.16 vs 15.62 ms, reproduced over four runs. Sweeping the rest of that cell
# on B200 showed the winner flips with sequence length and head config, not
# head dim (medians, 30 iters after 10 warmup):
#
#   b4  s1024  128x128   CUTLASS 0.334   cuDNN 0.265   cuDNN  1.26x
#   b16 s1024  128x128   CUTLASS 1.257   cuDNN 1.030   cuDNN  1.22x
#   b64 s1024  128x128   CUTLASS 5.764   cuDNN 4.178   cuDNN  1.38x
#   b8  s2048   32x8     CUTLASS 0.509   cuDNN 0.383   cuDNN  1.33x
#   b8  s2048   64x8     CUTLASS 0.969   cuDNN 0.716   cuDNN  1.35x
#   b1  s4096  128x128   CUTLASS 0.738   cuDNN 0.816   CUTLASS 1.11x
#   b16 s4096  128x128   CUTLASS 14.061  cuDNN 15.818  CUTLASS 1.12x
#   b4  s16384 128x128   CUTLASS 49.555  cuDNN 68.782  CUTLASS 1.39x
#
# cuDNN takes 5 of 8 -- every short-sequence case and every GQA case -- while
# CUTLASS only leads long-sequence MHA. Pinning the whole head-dim to CUTLASS
# would trade 1.22-1.38x away on the majority to win 1.11-1.39x on the rest, so
# the default order stands and this table stays empty until a heuristic keyed on
# the axes that actually discriminate (sequence length, MHA vs GQA) is measured
# across architectures. Until then, callers who know their shape can pin the
# order with the environment variable below.
_BLACKWELL_RAGGED_AUTO_PREFERENCE_BY_HEAD_DIM: Dict[
    Tuple[int, int], Tuple[str, ...]
] = {}

# Escape hatch: a comma-separated order (e.g. "cutlass,cudnn", or "cudnn" to pin
# one backend) overrides both tables. Intended for benchmarking and regression
# bisection on hardware whose ranking differs from the B200 numbers above --
# eligibility is still enforced, so an unusable backend is skipped rather than
# forced. Mirrors FLASHINFER_TOPK_ALGO's role for the top-k dispatcher.
_RAGGED_AUTO_ORDER_ENV = "FLASHINFER_RAGGED_AUTO_BACKEND_ORDER"

# (head_dim_qk, head_dim_vo) pairs validated against FA2 on the cuDNN path.
_CUDNN_RAGGED_AUTO_HEAD_DIMS = frozenset({(128, 128), (192, 128), (256, 256)})

# (head_dim_qk, head_dim_vo) pairs `auto` may route to CUTLASS. `DISPATCH_head_dim`
# in csrc/fmha_cutlass_sm100.cu accepts exactly (192,128), (128,128) and (64,64);
# the pairs are listed rather than tested as `head_dim_qk == 192`, which would
# also admit unsupported shapes such as 192/192. (64,64) is inside the kernel's
# domain but outside `auto`'s: this PR never measured it, so it stays on FA2
# until someone does.
_CUTLASS_RAGGED_AUTO_HEAD_DIMS = frozenset({(128, 128), (192, 128)})

# `fmha_varlen_plan` allocates the CUTLASS work-index buffers at this fixed
# capacity, and `plan_kernel` writes one entry per (qo_tile, head, batch) work
# item without a bounds check, so a problem that generates more work items than
# this overruns them. `auto` therefore treats capacity as an eligibility
# condition and leaves oversized problems on another backend; an explicit
# `backend="cutlass"` is unaffected and still hits the underlying limit.
_CUTLASS_PLAN_WORK_CAPACITY = 131072
_CUTLASS_PLAN_QO_TILE_SIZE = 256


def _cutlass_plan_work_items(qo_indptr_host: torch.Tensor, num_qo_heads: int) -> int:
    """Work items `fmha_varlen_plan` will emit: one per (qo_tile, head, batch).

    Mirrors the loop nest in ``plan_kernel``. Computed from the host indptr
    copy `plan()` already materialises, so it costs no extra device sync.
    """
    qo_lens = qo_indptr_host[1:] - qo_indptr_host[:-1]
    tiles_per_request = (qo_lens + (_CUTLASS_PLAN_QO_TILE_SIZE - 1)) // (
        _CUTLASS_PLAN_QO_TILE_SIZE
    )
    return int(tiles_per_request.sum().item()) * num_qo_heads


def _blackwell_ragged_auto_order(head_dim_qk: int, head_dim_vo: int) -> Tuple[str, ...]:
    """Backend preference order for this shape.

    Resolution order: the ``FLASHINFER_RAGGED_AUTO_BACKEND_ORDER`` override, then
    the per-shape table, then the global default. Read per call rather than
    cached at import so a test or a sweep can change it without a fresh
    interpreter.
    """
    override = os.environ.get(_RAGGED_AUTO_ORDER_ENV)
    if override:
        parsed = tuple(name.strip() for name in override.split(",") if name.strip())
        if parsed:
            return parsed
    return _BLACKWELL_RAGGED_AUTO_PREFERENCE_BY_HEAD_DIM.get(
        (head_dim_qk, head_dim_vo), _BLACKWELL_RAGGED_AUTO_PREFERENCE
    )


def _blackwell_ragged_auto_upgrade(
    device: torch.device,
    kv_layout: str,
    head_dim_qk: int,
    head_dim_vo: int,
    q_data_type: torch.dtype,
    kv_data_type: torch.dtype,
    o_data_type: torch.dtype,
    pos_encoding_mode: int,
    *,
    has_custom_mask: bool,
    window_left: int,
    logits_soft_cap: float,
    has_multi_item_scoring: bool,
    has_sinks: bool,
    cudnn_indptr_is_int32: bool,
    cutlass_work_items: int,
    cuda_graph_enabled: bool,
    cutlass_indptr_is_int32: bool = False,
    single_token_gqa: bool = False,
) -> Optional[str]:
    r"""Pick the Blackwell backend ``auto`` should upgrade FA2 to for ragged prefill.

    Walks the order from :func:`_blackwell_ragged_auto_order` (per-shape table,
    or the ``FLASHINFER_RAGGED_AUTO_BACKEND_ORDER`` override) and returns the
    first backend whose kernel serves the problem exactly, or ``None`` to stay
    on FA2. The walk tests *capability*, so the order decides the winner
    wherever both candidates are eligible.

    Both candidates' run paths receive only ``causal`` and the scales, so any
    request for RoPE, a custom mask, a sliding window, a logits soft cap, the
    multi-item-scoring pointers or attention sinks stashed on the wrapper
    (vLLM's ``_sinks``) disqualifies every upgrade: selecting one would
    silently drop the feature.

    ``cudnn`` is chosen only when the installed cuDNN can consume the caller's
    token-unit indptrs directly (``batch_offsets_units="tokens"``: they serve as
    ``cu_seq_len_q/kv`` for the mask and as ragged offsets scaled in-engine).
    That keeps the caller contract identical to every other backend and puts no
    conversion kernel on the run path; older cuDNN falls through to ``cutlass``.

    Every condition here is an *eligibility* test, never a deferred error: a
    backend this function returns must be able to serve the call. Conditions the
    backend would otherwise raise on later therefore belong in this walk, so
    ``auto`` routes past them instead of failing (``cudnn_indptr_is_int32`` and
    ``cutlass_work_items`` both exist for that reason).
    """
    if (
        kv_layout != "NHD"
        or q_data_type != kv_data_type
        or pos_encoding_mode != PosEncodingMode.NONE.value
        or has_custom_mask
        or window_left >= 0
        or logits_soft_cap != 0.0
        or has_multi_item_scoring
        or has_sinks
    ):
        return None
    for backend in _blackwell_ragged_auto_order(head_dim_qk, head_dim_vo):
        if backend == "cudnn":
            if (
                is_sm100a_supported(device)
                # fp16 / bf16 only: the cuDNN run branch below takes the caller's
                # tensors as they are, and the wrapper's fp8 handling (scales,
                # descale tensors) lives on the paths after it.
                and q_data_type in (torch.float16, torch.bfloat16)
                and _cudnn_supports_direct_seqlens(q_data_type)
                and (head_dim_qk, head_dim_vo) in _CUDNN_RAGGED_AUTO_HEAD_DIMS
                # cuDNN reads the indptrs as int32. plan() can re-dtype them
                # eagerly, but not buffers already registered with a captured
                # graph, where it raises instead -- so in that case cuDNN
                # cannot serve the call and must not be selected.
                and cudnn_indptr_is_int32
                # cuDNN's s_q == 1 kernel packs the q heads of a kv group and
                # writes the LSE only for the first of them (cuDNN 9.26/9.27,
                # NVBug 6783545); the output is right, the LSE is not, and run()
                # does not know yet whether the caller wants it.
                and not single_token_gqa
            ):
                return backend
        elif backend == "cutlass":
            if (
                (is_sm100a_supported(device) or is_sm110a_supported(device))
                and q_data_type in (torch.float16, torch.bfloat16)
                # DISPATCH_DTYPE_IN_OUT only handles out == in for fp16/bf16;
                # any other pairing falls into its FP8 branch, which a bf16 or
                # fp16 input does not match, and the call dies on a check that
                # reports unsupported *head dimensions*. Mismatched output
                # dtype is therefore out of domain, not a slow path.
                and o_data_type == q_data_type
                # Both the planner and kernel read these buffers as int32.
                # Device mirrors preserve the caller's dtype, so leave wider
                # indices on a compatible backend instead of reinterpreting them.
                and cutlass_indptr_is_int32
                and (head_dim_qk, head_dim_vo) in _CUTLASS_RAGGED_AUTO_HEAD_DIMS
                and cutlass_work_items <= _CUTLASS_PLAN_WORK_CAPACITY
                # `fmha_varlen_plan` allocates fresh work-index buffers on every
                # call, so a re-plan leaves a captured graph pointing at the
                # previous allocation. An explicit `cutlass` wrapper may plan
                # once before capture, but `auto` is re-resolved on every plan()
                # and graph-mode callers re-plan before each replay, so `auto`
                # stays away until those buffers are updated in place.
                and not cuda_graph_enabled
            ):
                return backend
    return None


class BatchPrefillWithPagedKVCacheWrapper:
    r"""Wrapper class for prefill/append attention with paged kv-cache for batch of
    requests.

    Check :ref:`our tutorial <kv-layout>` for page table layout.

    Example
    -------
    >>> import torch
    >>> import flashinfer
    >>> num_layers = 32
    >>> num_qo_heads = 64
    >>> num_kv_heads = 16
    >>> head_dim = 128
    >>> max_num_pages = 128
    >>> page_size = 16
    >>> # allocate 128MB workspace buffer
    >>> workspace_buffer = torch.zeros(128 * 1024 * 1024, dtype=torch.uint8, device="cuda:0")
    >>> prefill_wrapper = flashinfer.BatchPrefillWithPagedKVCacheWrapper(
    ...     workspace_buffer, "NHD"
    ... )
    >>> batch_size = 7
    >>> nnz_qo = 100
    >>> qo_indptr = torch.tensor(
    ...     [0, 33, 44, 55, 66, 77, 88, nnz_qo], dtype=torch.int32, device="cuda:0"
    ... )
    >>> paged_kv_indices = torch.arange(max_num_pages).int().to("cuda:0")
    >>> paged_kv_indptr = torch.tensor(
    ...     [0, 17, 29, 44, 48, 66, 100, 128], dtype=torch.int32, device="cuda:0"
    ... )
    >>> # 1 <= paged_kv_last_page_len <= page_size
    >>> paged_kv_last_page_len = torch.tensor(
    ...     [1, 7, 14, 4, 3, 1, 16], dtype=torch.int32, device="cuda:0"
    ... )
    >>> q_at_layer = torch.randn(num_layers, nnz_qo, num_qo_heads, head_dim).half().to("cuda:0")
    >>> kv_cache_at_layer = torch.randn(
    ...     num_layers, max_num_pages, 2, page_size, num_kv_heads, head_dim, dtype=torch.float16, device="cuda:0"
    ... )
    >>> # create auxiliary data structures for batch prefill attention
    >>> prefill_wrapper.plan(
    ...     qo_indptr,
    ...     paged_kv_indptr,
    ...     paged_kv_indices,
    ...     paged_kv_last_page_len,
    ...     num_qo_heads,
    ...     num_kv_heads,
    ...     head_dim,
    ...     page_size,
    ...     causal=True,
    ... )
    >>> outputs = []
    >>> for i in range(num_layers):
    ...     q = q_at_layer[i]
    ...     kv_cache = kv_cache_at_layer[i]
    ...     # compute batch prefill attention, reuse auxiliary data structures
    ...     o = prefill_wrapper.run(q, kv_cache)
    ...     outputs.append(o)
    ...
    >>> outputs[0].shape
    torch.Size([100, 64, 128])
    >>>
    >>> # below is another example of creating custom mask for batch prefill attention
    >>> mask_arr = []
    >>> qo_len = (qo_indptr[1:] - qo_indptr[:-1]).cpu().tolist()
    >>> kv_len = (page_size * (paged_kv_indptr[1:] - paged_kv_indptr[:-1] - 1) + paged_kv_last_page_len).cpu().tolist()
    >>> for i in range(batch_size):
    ...     mask_i = torch.tril(
    ...         torch.full((qo_len[i], kv_len[i]), True, device="cuda:0"),
    ...         diagonal=(kv_len[i] - qo_len[i]),
    ...     )
    ...     mask_arr.append(mask_i.flatten())
    ...
    >>> mask = torch.cat(mask_arr, dim=0)
    >>> prefill_wrapper.plan(
    ...     qo_indptr,
    ...     paged_kv_indptr,
    ...     paged_kv_indices,
    ...     paged_kv_last_page_len,
    ...     num_qo_heads,
    ...     num_kv_heads,
    ...     head_dim,
    ...     page_size,
    ...     custom_mask=mask,
    ... )
    >>> for i in range(num_layers):
    ...     q = q_at_layer[i]
    ...     kv_cache = kv_cache_at_layer[i]
    ...     # compute batch prefill attention, reuse auxiliary data structures
    ...     o_custom = prefill_wrapper.run(q, kv_cache)
    ...     assert torch.allclose(o_custom, outputs[i], rtol=1e-3, atol=1e-3)
    ...


    Note
    ----
    To accelerate computation, FlashInfer's batch prefill/append attention operators
    create some auxiliary data structures, these data structures can be reused across
    multiple prefill/append attention calls (e.g. different Transformer layers). This
    wrapper class manages the lifecycle of these data structures.
    """

    @flashinfer_api
    def __init__(
        self,
        float_workspace_buffer: torch.Tensor,
        kv_layout: str = "NHD",
        use_cuda_graph: bool = False,
        qo_indptr_buf: Optional[torch.Tensor] = None,
        paged_kv_indptr_buf: Optional[torch.Tensor] = None,
        paged_kv_indices_buf: Optional[torch.Tensor] = None,
        paged_kv_last_page_len_buf: Optional[torch.Tensor] = None,
        custom_mask_buf: Optional[torch.Tensor] = None,
        mask_indptr_buf: Optional[torch.Tensor] = None,
        backend: str = "auto",
        jit_args: Optional[List[Any]] = None,
        jit_kwargs: Optional[Dict[str, Any]] = None,
        variant_owns_mask: bool = False,
    ) -> None:
        r"""Constructor of :class:`BatchPrefillWithPagedKVCacheWrapper`.

        Parameters
        ----------
        float_workspace_buffer : torch.Tensor
            The user reserved workspace buffer used to store intermediate attention results in
            split-k algorithm. The recommended size is 128MB, the device of the workspace buffer
            should be the same as the device of the input tensors. The buffer must be 16-byte
            aligned; tensors created by ``torch.empty`` satisfy this on supported devices.

        kv_layout : str
            The layout of the input k/v tensors, could be either ``NHD`` or ``HND``.

        use_cuda_graph : bool
            Whether to enable CUDA graph capture for the prefill kernels, if enabled, the
            auxiliary data structures will be stored in provided buffers. The ``batch_size``
            cannot change during the lifecycle of this wrapper when CUDAGraph is enabled.

        qo_indptr_buf : Optional[torch.Tensor]
            The user reserved buffer to store the ``qo_indptr`` array, the size of the buffer
            should be ``[batch_size + 1]``.
            This argument is only effective when ``use_cuda_graph`` is ``True``.

        paged_kv_indptr_buf : Optional[torch.Tensor]
            The user reserved buffer to store the ``paged_kv_indptr`` array, the size of this
            buffer should be ``[batch_size + 1]``.
            This argument is only effective when ``use_cuda_graph`` is ``True``.

        paged_kv_indices_buf : Optional[torch.Tensor]
            The user reserved buffer to store the ``paged_kv_indices`` array, should be large
            enough to store the maximum possible size of the ``paged_kv_indices`` array during
            the lifetime of the wrapper. This argument is only effective when ``use_cuda_graph``
            is ``True``.

        paged_kv_last_page_len_buf : Optional[torch.Tensor]
            The user reserved buffer to store the ``paged_kv_last_page_len`` array, the size of
            the buffer should be ``[batch_size]``.
            This argument is only effective when ``use_cuda_graph`` is ``True``.

        custom_mask_buf : Optional[torch.Tensor]
            The user reserved buffer to store the custom mask tensor, should be large enough to
            store the maximum possible size of the packed custom mask tensor during the lifetime of
            the wrapper. This argument is only effective when ``use_cuda_graph`` is set to ``True``
            and the custom mask will be used in attention computation.

        mask_indptr_buf : Optional[torch.Tensor]
            The user reserved buffer to store the ``mask_indptr`` array, the size of the buffer
            should be ``[batch_size + 1]``.
            This argument is only effective when ``use_cuda_graph`` is ``True`` and the custom
            mask will be used in attention computation.

        backend : str
            The implementation backend, could be ``auto``/``fa2``/``fa3``/``cudnn``/``trtllm-gen``
            ``cute-dsl``/``cute-dsl-prims``.
            Defaults to ``auto``.
            If set to ``auto``, the wrapper will automatically choose the backend based on the
            device architecture and kernel availability.
            The ``cute-dsl`` backend uses the CuTe DSL attention kernel for Blackwell (SM100+).
            ``cute-dsl-prims`` backend is a SM120-only FP8 attention backend implemented using
            CUTLASS primitives.

        jit_args : Optional[List[Any]]
            If provided, the wrapper will use the provided arguments to create the JIT module,
            otherwise, the wrapper will use default attention implementation.

        jit_kwargs : Optional[Dict[str, Any]]
            The keyword arguments to create the JIT module, defaults to None.

        variant_owns_mask : bool
            If ``True``, the attention variant supplied through ``jit_args`` computes the
            complete attention mask in its ``LogitsMask`` hook, and :attr:`MaskMode.CUSTOM`
            is selected without a mask tensor: the kernel evaluates ``LogitsMask`` on every
            KV tile instead of only on the causal/window boundary tiles, and no
            ``custom_mask``/``packed_custom_mask`` needs to be passed to :meth:`plan`.
            Requires ``jit_args``, because the default attention variant dereferences the
            custom mask buffer under :attr:`MaskMode.CUSTOM`. Only supported with
            ``backend="fa2"`` (the SM90 batch prefill kernels reject
            :attr:`MaskMode.CUSTOM`), and incompatible with ``prefix_len_ptr``
            (multi-item scoring), which selects a different mask mode.
            Defaults to ``False``.
        """
        _check_workspace_buffer_alignment(
            float_workspace_buffer, "float_workspace_buffer"
        )
        _check_kv_layout(kv_layout)

        if variant_owns_mask and backend != "fa2":
            raise ValueError(
                "variant_owns_mask is only supported on the fa2 backend: the "
                "SM90 (fa3) batch prefill kernels return cudaErrorNotSupported "
                "under MaskMode.CUSTOM."
            )

        self._cute_dsl_wrapper = None
        if backend == "cute-dsl":
            from .cute_dsl.attention import BatchPrefillCuteDSLWrapper

            self._cute_dsl_wrapper = BatchPrefillCuteDSLWrapper(
                float_workspace_buffer, use_cuda_graph=use_cuda_graph
            )

        if (
            jit_args is not None
            and backend != "cute-dsl"
            and backend != "cute-dsl-prims"
        ):
            if jit_kwargs is None:
                jit_kwargs = {}
            self._jit_module = get_batch_prefill_jit_module(
                jit_args[0],
                get_customize_batch_prefill_module(backend, *jit_args, **jit_kwargs),
            )
            # jit_args[7] is additional_tensor_names from gen_customize_batch_prefill_module
            self._jit_additional_tensor_names = list(jit_args[7])
            self._jit_additional_scalar_names = list(jit_args[9])
        else:
            self._jit_module = None
            self._jit_additional_tensor_names = []
            self._jit_additional_scalar_names = []

        if variant_owns_mask and self._jit_module is None:
            raise ValueError(
                "variant_owns_mask requires a custom JIT module (jit_args): the "
                "default attention variant dereferences the custom mask buffer "
                "under MaskMode.CUSTOM."
            )
        self._variant_owns_mask = variant_owns_mask

        self._kv_layout = kv_layout
        self._float_workspace_buffer = float_workspace_buffer
        self._workspace_size = (
            self._float_workspace_buffer.numel()
            * self._float_workspace_buffer.element_size()
        )
        self.device = float_workspace_buffer.device
        self._trtllm_gen_multi_ctas_kv_counter_buffer: Optional[torch.Tensor] = None

        self._kv_lens_buffer = torch.empty(
            (32768,), dtype=torch.int32, device=self.device
        )
        self._int_workspace_buffer = torch.empty(
            (8 * 1024 * 1024,), dtype=torch.uint8, device=self.device
        )
        self._pin_memory_int_workspace_buffer = torch.empty(
            self._int_workspace_buffer.shape,
            dtype=self._int_workspace_buffer.dtype,
            device="cpu",
            pin_memory=True,
        )
        self._use_cuda_graph = use_cuda_graph
        if use_cuda_graph:
            if not torch.is_tensor(qo_indptr_buf):
                raise ValueError(
                    "qo_indptr_buf should be a torch.Tensor in CUDA graph mode"
                )
            if not torch.is_tensor(paged_kv_indptr_buf):
                raise ValueError(
                    "paged_kv_indptr_buf should be a torch.Tensor in CUDA graph mode"
                )
            if not torch.is_tensor(paged_kv_indices_buf):
                raise ValueError(
                    "paged_kv_indices_buf should be a torch.Tensor in CUDA graph mode"
                )
            if not torch.is_tensor(paged_kv_last_page_len_buf):
                raise ValueError(
                    "paged_kv_last_page_len_buf should be a torch.Tensor in CUDA graph mode"
                )
            self._fixed_batch_size = len(qo_indptr_buf) - 1
            if len(paged_kv_indptr_buf) != self._fixed_batch_size + 1:
                raise ValueError(
                    "The length of paged_kv_indptr_buf should be batch_size + 1."
                )
            if len(paged_kv_last_page_len_buf) != self._fixed_batch_size:
                raise ValueError(
                    "The length of paged_kv_last_page_len_buf should be batch_size."
                )
            # NOTE(Zihao): do not check custom_mask_buf and mask_indptr_buf here, as they are optional
        else:
            self._fixed_batch_size = 0

        self._qo_indptr_buf = qo_indptr_buf
        self._paged_kv_indptr_buf = paged_kv_indptr_buf
        self._paged_kv_indices_buf = paged_kv_indices_buf
        self._paged_kv_last_page_len_buf = paged_kv_last_page_len_buf
        self._custom_mask_buf = custom_mask_buf
        self._mask_indptr_buf = mask_indptr_buf
        self._max_total_num_rows: Optional[int] = None
        self._backend = backend
        self._plan_info = None
        self._cached_module = None
        self._seq_lens_kv = None
        self._seq_lens_q = None
        self._block_tables = None
        # specialized SM90 fp8-KV verify kernel: set by plan() when eligible
        self._eagle_verify_fp8kv_sm90_state = None
        self._eagle_verify_fp8kv_sm90_workspace = None
        self._cudnn_block_tables: Optional[torch.Tensor] = None
        self._cudnn_q_lens_buffer: Optional[torch.Tensor] = None
        self._cudnn_prepared: Optional[CudnnPrefillGraph] = None
        self._cudnn_plan: Optional[_CudnnPrefillPlan] = None
        self._prims_backend = None
        if backend == "cute-dsl-prims":
            try:
                from .attention.cute_dsl.sm120_fmha import (
                    SM120PrimsBatchPrefillBackend,
                )
            except ImportError as exc:
                raise ImportError(
                    "backend='cute-dsl-prims' requires the SM120 CuTe DSL stack "
                    "providing cutlass.experimental"
                ) from exc
            self._prims_backend = SM120PrimsBatchPrefillBackend(self.device)

    @property
    def is_cuda_graph_enabled(self) -> bool:
        return self._use_cuda_graph

    def reset_workspace_buffer(
        self, float_workspace_buffer: torch.Tensor, int_workspace_buffer: torch.Tensor
    ) -> None:
        r"""Reset the workspace buffer.

        Parameters
        ----------
        float_workspace_buffer : torch.Tensor
            The new float workspace buffer, the device of the new float workspace buffer should
            be the same as the device of the input tensors.

        int_workspace_buffer : torch.Tensor
            The new int workspace buffer, the device of the new int workspace buffer should
            be the same as the device of the input tensors.
        """
        _check_workspace_buffer_alignment(
            float_workspace_buffer, "float_workspace_buffer"
        )
        _check_workspace_buffer_alignment(int_workspace_buffer, "int_workspace_buffer")
        self._float_workspace_buffer = float_workspace_buffer
        self._cudnn_prepared = None
        self._int_workspace_buffer = int_workspace_buffer
        self._pin_memory_int_workspace_buffer = torch.empty(
            self._int_workspace_buffer.shape,
            dtype=self._int_workspace_buffer.dtype,
            device="cpu",
            pin_memory=True,
        )

    @flashinfer_api
    def workspace_size(
        self,
        qo_indptr: torch.Tensor,
        paged_kv_indptr: torch.Tensor,
        paged_kv_indices: torch.Tensor,
        paged_kv_last_page_len: torch.Tensor,
        num_qo_heads: int,
        num_kv_heads: int,
        head_dim_qk: int,
        page_size: int,
        head_dim_vo: Optional[int] = None,
        custom_mask: Optional[torch.Tensor] = None,
        packed_custom_mask: Optional[torch.Tensor] = None,
        causal: bool = False,
        pos_encoding_mode: str = "NONE",
        use_fp16_qk_reduction: bool = False,
        sm_scale: Optional[float] = None,
        window_left: int = -1,
        logits_soft_cap: Optional[float] = None,
        rope_scale: Optional[float] = None,
        rope_theta: Optional[float] = None,
        q_data_type: Union[str, torch.dtype] = "float16",
        kv_data_type: Optional[Union[str, torch.dtype]] = None,
        o_data_type: Optional[Union[str, torch.dtype]] = None,
        prefix_len_ptr: Optional[torch.Tensor] = None,
        token_pos_in_items_ptr: Optional[torch.Tensor] = None,
        token_pos_in_items_len: int = 0,
        max_item_len_ptr: Optional[torch.Tensor] = None,
        seq_lens: Optional[torch.Tensor] = None,
        seq_lens_q: Optional[torch.Tensor] = None,
        block_tables: Optional[torch.Tensor] = None,
        max_token_per_sequence: Optional[int] = None,
        max_sequence_kv: Optional[int] = None,
        fixed_split_size: Optional[int] = None,
        disable_split_kv: bool = False,
        uniform_q_len: Optional[int] = None,
    ) -> Tuple[int, int]:
        r"""Return the caller-owned workspace size required by :meth:`plan`.

        The returned tuple is ``(float_workspace_size, int_workspace_size)`` in
        bytes.  The inputs follow :meth:`plan`; host-side planning tensors such
        as ``qo_indptr`` and ``paged_kv_indptr`` are copied to CPU in the same
        way as :meth:`plan`.  The wrapper's float workspace buffer is only used
        as the device/stream selector for the underlying module query.  This
        method does not allocate buffers and does not mutate cached plan state.

        Parameters
        ----------
        qo_indptr : torch.Tensor
            The indptr of the query/output tensor, shape: ``[batch_size + 1]``.
        paged_kv_indptr : torch.Tensor
            The indptr of the paged kv-cache, shape: ``[batch_size + 1]``.
        paged_kv_indices : torch.Tensor
            The page indices of the paged kv-cache, shape: ``[paged_kv_indptr[-1]]``.
        paged_kv_last_page_len : torch.Tensor
            The number of entries in the last page of each request in the paged
            kv-cache, shape: ``[batch_size]``.
        num_qo_heads : int
            The number of query/output heads.
        num_kv_heads : int
            The number of key/value heads.
        head_dim_qk : int
            The dimension of the query/key heads.
        page_size : int
            The size of each page in the paged kv-cache.
        head_dim_vo : Optional[int]
            The dimension of the value/output heads. If not provided, defaults to
            ``head_dim_qk``.
        custom_mask : Optional[torch.Tensor]
            The flattened boolean mask tensor; when provided the packed mask is
            generated internally. See :meth:`plan` for the full description.
        packed_custom_mask : Optional[torch.Tensor]
            The 1D packed uint8 mask tensor. If provided, ``custom_mask`` is ignored.
        causal : bool
            Whether to apply a causal mask. Defaults to ``False``.
        pos_encoding_mode : str
            The position encoding applied inside attention kernels, could be
            ``NONE``/``ROPE_LLAMA`` (LLAMA style rotary embedding) /``ALIBI``.
            Defaults to ``NONE``.
        use_fp16_qk_reduction : bool
            Whether to use fp16 for qk reduction. Defaults to ``False``.
        sm_scale : Optional[float]
            Softmax scale. If ``None``, defaults to ``1.0 / sqrt(head_dim_qk)``.
        window_left : int
            The left (inclusive) window size for the attention window, when set to ``-1``, the window
            size will be set to the full length of the sequence. Defaults to ``-1``.
        logits_soft_cap : Optional[float]
            The attention logits soft capping value (used in Gemini, Grok and Gemma-2, etc.),
            if not provided, will be set to ``0``.
        rope_scale : Optional[float]
            Scale factor applied during RoPE interpolation. Defaults to ``1.0`` when ``None``.
        rope_theta : Optional[float]
            Base value for the RoPE frequencies. Defaults to ``1e4`` when ``None``.
        q_data_type : Union[str, torch.dtype]
            The data type of the query tensor. Defaults to ``torch.float16``.
        kv_data_type : Optional[Union[str, torch.dtype]]
            The data type of the key/value tensor. If ``None``, will be set to ``q_data_type``.
        o_data_type : Optional[Union[str, torch.dtype]]
            The data type of the output tensor. If ``None``, will be set to ``q_data_type``.
        prefix_len_ptr : Optional[torch.Tensor]
            A uint32 1D tensor indicating the prefix length of each prompt,
            shape: ``[batch_size]``.
        token_pos_in_items_ptr : Optional[torch.Tensor]
            A uint16 1D tensor indicating the token position of each item within its item.
        token_pos_in_items_len : int
            Zero-padding length for ``token_pos_in_items_ptr``. Defaults to ``0``.
        max_item_len_ptr : Optional[torch.Tensor]
            A uint16 vector containing the max token length of all items for each prompt.
        seq_lens : Optional[torch.Tensor]
            A uint32 1D tensor indicating the kv sequence length of each prompt,
            shape: ``[batch_size]``.
        seq_lens_q : Optional[torch.Tensor]
            A uint32 1D tensor indicating the q sequence length of each prompt,
            shape: ``[batch_size]``.
        block_tables : Optional[torch.Tensor]
            A uint32 2D tensor indicating the block table of each prompt,
            shape: ``[batch_size, max_num_blocks_per_seq]``.
        max_token_per_sequence : Optional[int]
            Required for cuDNN backend. The scalar max token length of each sequence.
        max_sequence_kv : Optional[int]
            Maximum number of KV tokens per sequence for cuDNN backend.
        fixed_split_size : Optional[int]
            The fixed split size for split-kv prefill, in pages.
        disable_split_kv : bool
            Whether to disable the split-kv. Defaults to ``False``.

        Returns
        -------
        Tuple[int, int]
            ``(float_workspace_size, int_workspace_size)`` in bytes.

        Example
        -------
        >>> float_bytes, int_bytes = wrapper.workspace_size(...)
        >>> wrapper.reset_workspace_buffer(
        ...     torch.empty(float_bytes, dtype=torch.uint8, device="cuda"),
        ...     torch.empty(int_bytes, dtype=torch.uint8, device="cuda"),
        ... )
        >>> wrapper.plan(...)
        """
        if self._backend == "cute-dsl-prims":
            return (0, 0)

        _check_workspace_buffer_alignment(
            self._float_workspace_buffer, "float_workspace_buffer"
        )
        del (
            block_tables,
            max_item_len_ptr,
            max_token_per_sequence,
            prefix_len_ptr,
            rope_scale,
            rope_theta,
            seq_lens_q,
            sm_scale,
            token_pos_in_items_len,
            token_pos_in_items_ptr,
        )
        q_data_type = canonicalize_torch_dtype(q_data_type)
        if kv_data_type is None:
            kv_data_type = q_data_type
        kv_data_type = canonicalize_torch_dtype(kv_data_type)
        if o_data_type is None:
            o_data_type = q_data_type
        o_data_type = canonicalize_torch_dtype(o_data_type)

        if logits_soft_cap is None:
            logits_soft_cap = 0.0
        if head_dim_vo is None:
            head_dim_vo = head_dim_qk
        if fixed_split_size is None:
            fixed_split_size = -1

        batch_size = len(qo_indptr) - 1
        qo_indptr_host = qo_indptr.to("cpu")
        total_num_rows = int(qo_indptr_host[-1])
        paged_kv_indptr_host = paged_kv_indptr.to("cpu")
        paged_kv_last_page_len_host = paged_kv_last_page_len.to("cpu")
        if seq_lens is None:
            kv_lens_arr_host = get_seq_lens(
                paged_kv_indptr_host, paged_kv_last_page_len_host, page_size
            )
        else:
            kv_lens_arr_host = seq_lens.cpu().flatten().to(torch.int32)

        if self.is_cuda_graph_enabled:
            if batch_size != self._fixed_batch_size:
                raise ValueError(
                    "The batch size should be fixed during the lifecycle of the wrapper in "
                    "cuda graph mode, the runtime batch size {} mismatches the batch size {} "
                    " set during initialization.".format(
                        batch_size, self._fixed_batch_size
                    )
                )
            if len(paged_kv_indices) > len(self._paged_kv_indices_buf):
                raise ValueError(
                    "The length of paged_kv_indices exceeds the allocated buffer size."
                )
            if (
                self._max_total_num_rows is not None
                and total_num_rows > self._max_total_num_rows
            ):
                raise ValueError(
                    "The total number of rows in qo_indptr {} in cuda graph mode cannot "
                    "exceed the number of rows set during initialization {}.".format(
                        total_num_rows, self._max_total_num_rows
                    )
                )

        use_custom_mask = custom_mask is not None or packed_custom_mask is not None
        backend = self._backend
        if self._jit_module is not None:
            module = self._jit_module
        else:
            if backend == "auto":
                backend = determine_attention_backend(
                    self.device,
                    PosEncodingMode[pos_encoding_mode].value,
                    use_fp16_qk_reduction,
                    use_custom_mask,
                    q_data_type,
                    kv_data_type,
                )
            if backend == "cudnn":
                raise NotImplementedError(
                    "workspace_size is not available for cudnn prefill backend"
                )
            module = get_batch_prefill_module(
                backend,
                q_data_type,
                kv_data_type,
                o_data_type,
                paged_kv_indptr.dtype,
                head_dim_qk,
                head_dim_vo,
                PosEncodingMode[pos_encoding_mode].value,
                window_left >= 0,
                logits_soft_cap > 0,
                use_fp16_qk_reduction,
            )
        if module.workspace_size is None:
            raise NotImplementedError(
                f"workspace_size is not available for prefill backend {backend!r}"
            )

        del max_sequence_kv
        total_num_rows_for_plan = self._max_total_num_rows or total_num_rows
        args = [
            self._float_workspace_buffer,
            qo_indptr_host,
            paged_kv_indptr_host,
            kv_lens_arr_host,
            total_num_rows_for_plan,
            batch_size,
            num_qo_heads,
            num_kv_heads,
            page_size,
            self.is_cuda_graph_enabled,
            head_dim_qk,
            head_dim_vo,
            causal,
            window_left,
        ]
        if backend == "fa2":
            args.append(fixed_split_size)
            args.append(disable_split_kv)
            args.append(0)  # num_colocated_ctas
            args.append(
                _resolve_uniform_q_len(
                    uniform_q_len,
                    qo_indptr_host,
                    self.is_cuda_graph_enabled,
                    backend,
                    "BatchPrefillWithPagedKVCacheWrapper.workspace_size",
                )
            )
        float_workspace_size, int_workspace_size = module.workspace_size(*args)
        return int(float_workspace_size), int(int_workspace_size)

    @flashinfer_api
    def plan(
        self,
        qo_indptr: torch.Tensor,
        paged_kv_indptr: torch.Tensor,
        paged_kv_indices: torch.Tensor,
        paged_kv_last_page_len: torch.Tensor,
        num_qo_heads: int,
        num_kv_heads: int,
        head_dim_qk: int,
        page_size: int,
        head_dim_vo: Optional[int] = None,
        custom_mask: Optional[torch.Tensor] = None,
        packed_custom_mask: Optional[torch.Tensor] = None,
        causal: bool = False,
        pos_encoding_mode: str = "NONE",
        use_fp16_qk_reduction: bool = False,
        sm_scale: Optional[float] = None,
        window_left: int = -1,
        logits_soft_cap: Optional[float] = None,
        rope_scale: Optional[float] = None,
        rope_theta: Optional[float] = None,
        q_data_type: Union[str, torch.dtype] = "float16",
        kv_data_type: Optional[Union[str, torch.dtype]] = None,
        o_data_type: Optional[Union[str, torch.dtype]] = None,
        non_blocking: bool = True,
        prefix_len_ptr: Optional[torch.Tensor] = None,
        token_pos_in_items_ptr: Optional[torch.Tensor] = None,
        token_pos_in_items_len: int = 0,
        max_item_len_ptr: Optional[torch.Tensor] = None,
        seq_lens: Optional[torch.Tensor] = None,
        seq_lens_q: Optional[torch.Tensor] = None,
        block_tables: Optional[torch.Tensor] = None,
        max_token_per_sequence: Optional[int] = None,
        max_sequence_kv: Optional[int] = None,
        fixed_split_size: Optional[int] = None,
        disable_split_kv: bool = False,
        uniform_q_len: Optional[int] = None,
    ) -> None:
        r"""Plan batch prefill/append attention on Paged KV-Cache for given problem specification.

        Parameters
        ----------
        qo_indptr : torch.Tensor
            The indptr of the query/output tensor, shape: ``[batch_size + 1]``.
            Token units for every backend, including ``cudnn`` (it previously took
            element-unit offsets; that contract has been normalized).
        paged_kv_indptr : torch.Tensor
            The indptr of the paged kv-cache, shape: ``[batch_size + 1]``.
        paged_kv_indices : torch.Tensor
            The page indices of the paged kv-cache, shape: ``[paged_kv_indptr[-1]]``.
        paged_kv_last_page_len : torch.Tensor
            The number of entries in the last page of each request in the paged
            kv-cache, shape: ``[batch_size]``.
        num_qo_heads : int
            The number of query/output heads.
        num_kv_heads : int
            The number of key/value heads.
        head_dim_qk : int
            The dimension of the query/key heads.
        page_size : int
            The size of each page in the paged kv-cache.
        head_dim_vo : Optional[int]
            The dimension of the value/output heads, if not provided, will be set to
            ``head_dim_qk``.
        custom_mask : Optional[torch.Tensor]
            The flattened boolean mask tensor, shape: ``(sum(q_len[i] * k_len[i] for i in range(batch_size))``.
            The elements in the mask tensor should be either ``True`` or ``False``,
            where ``False`` means the corresponding element in the attention matrix will be
            masked out.

            Please refer to the :ref:`mask layout <mask-layout>` for more details about flattened
            layout of mask tensor.

            When :attr:`custom_mask` is provided, and :attr:`packed_custom_mask` is not, the
            function will pack the custom mask tensor into a 1D packed mask tensor, which introduces
            additional overhead.
        packed_custom_mask : Optional[torch.Tensor]
            The 1D packed uint8 mask tensor, if provided, the :attr:`custom_mask` will be ignored.
            The packed mask tensor is generated by :func:`flashinfer.quantization.packbits`.
        causal : bool
            Whether to apply causal mask to the attention matrix.
            This is only effective when :attr:`custom_mask` is not provided in
            :meth:`plan`.
        pos_encoding_mode : str
            The position encoding applied inside attention kernels, could be
            ``NONE``/``ROPE_LLAMA`` (LLAMA style rotary embedding) /``ALIBI``.
            Default is ``NONE``.
        use_fp16_qk_reduction : bool
            Whether to use f16 for qk reduction (faster at the cost of slight precision
            loss).
        window_left : int
            The left (inclusive) window size for the attention window, when set to ``-1``, the window
            size will be set to the full length of the sequence. Defaults to ``-1``.
        logits_soft_cap : Optional[float]
            The attention logits soft capping value (used in Gemini, Grok and Gemma-2, etc.), if not
            provided, will be set to ``0``. If greater than 0, the logits will be capped according to
            formula:
            :math:`\texttt{logits_soft_cap} \times \mathrm{tanh}(x / \texttt{logits_soft_cap})`,
            where :math:`x` is the input logits.
        sm_scale : Optional[float]
            The scale used in softmax, if not provided, will be set to
            ``1.0 / sqrt(head_dim)``.
        rope_scale : Optional[float]
            The scale used in RoPE interpolation, if not provided, will be set to
            ``1.0``.
        rope_theta : Optional[float]
            The theta used in RoPE, if not provided, will be set to ``1e4``.
        q_data_type : Union[str, torch.dtype]
            The data type of the query tensor, defaults torch.float16.
        kv_data_type : Optional[Union[str, torch.dtype]]
            The data type of the key/value tensor. If None, will be set to :attr:`q_data_type`.
        o_data_type : Optional[Union[str, torch.dtype]]
            The data type of the output tensor. If None, will be set to :attr:`q_data_type`.
            For FP8 inputs, this should typically be set to torch.float16 or torch.bfloat16.
        non_blocking : bool
            Whether to copy the input tensors to the device asynchronously, defaults to ``True``.
        prefix_len_ptr :Optional[torch.Tensor]
            prefix length. A uint32 1D tensor indicating the prefix length of each prompt. The tensor size is equal to the batch size.
        token_pos_in_items_ptr : Optional[torch.Tensor]
            A uint16 1D tensor (it will be converted to uint16 in flashinfer) indicating the token position of each item and started from 0 (delimiter)
            for each item. E.g., if we have 3 items of length 3, 2, 4 respectively for this member. This vector will be looking like
            `[0, 1, 2, 3, 0, 1, 2, 0, 1, 2, 3, 4, 0]` with 4 delimiters indexed as 0. For batch size > 1,
            we will concat them as 1D with zero paddings to make sure each has the same length, the padding length is defined by
            `token_pos_in_items_len` - length of the raw `token_pos_in_items_ptr` for each prompt.
        token_pos_in_items_len : int
            zero padding length for `token_pos_in_items_ptr` to better handle the bsz > 1 case. Still using the above 3,2,4 example.
            If we set `token_pos_in_items_len` to be 20, it will be  `[0, 1, 2, 3, 0, 1, 2, 0, 1, 2, 3, 4, 0, 0, 0, 0, 0, 0, 0, 0]`
            with 7 padded zeros. (note there're 8 zeros in the end where the first one is the delimiter token 0 in the end of the prompt)
        max_item_len_ptr : Optional[torch.Tensor]
            a uint16 vector contains the max token length of all items for each prompt
        seq_lens: Optional[torch.Tensor]
            A uint32 1D tensor indicating the kv sequence length of each prompt. shape: ``[batch_size]``.
        seq_lens_q: Optional[torch.Tensor]
            A uint32 1D tensor indicating the q sequence length of each prompt. shape: ``[batch_size]``.
            For cuDNN, defaults to the differences in ``qo_indptr``.
        block_tables: Optional[torch.Tensor]
            A uint32 2D tensor indicating the block table of each prompt. shape: ``[batch_size, max_num_blocks_per_seq]``.
        max_token_per_sequence: Optional[int],
            Maximum query length for cuDNN; inferred from ``qo_indptr`` when omitted.
        max_sequence_kv: Optional[int],
            Maximum KV length for cuDNN; inferred from the paged metadata when omitted.
        fixed_split_size : Optional[int],
            The fixed split size for FA2 split-kv prefill/decode in pages. Recommend setting to the average sequence length of your workload.
            When enabled, will lead to deterministic softmax score reduction in the merge_states kernel, and therefore
            batch-size invariant outputs. See https://thinkingmachines.ai/blog/defeating-nondeterminism-in-llm-inference/
            Note that compatibility with CUDA graph is NOT guaranteed, as even when bs is fixed, kv seq len can change
            and lead to a varied number of launched CTAs.
        disable_split_kv : bool,
            Whether to disable the split-kv for determinism in CUDA Graph, defaults to ``False``.
        uniform_q_len : Optional[int]
            Number of query rows of every request in the batch, when the caller can
            guarantee it for every plan replayed through this wrapper (speculative-decoding
            target verify: each request carries exactly ``draft_token_num`` query rows).
            Only the ``fa2`` backend in CUDA-graph mode uses it: the scheduler then sizes
            the query tile for ``uniform_q_len * gqa_group_size`` packed rows instead of
            the ragged worst case ``total_num_rows - batch_size + 1``. The hint is checked
            against ``qo_indptr`` on the host and dropped, with one warning, when the batch
            is not uniform. Defaults to ``None`` (no hint).
        Note
        ----
        The :meth:`plan` method should be called before any :meth:`run` or
        :meth:`run_return_lse` calls, auxiliary data structures will be created
        during this call and cached for multiple kernel runs.

        The ``num_qo_heads`` must be a multiple of ``num_kv_heads``. If ``num_qo_heads``
        is not equal to ``num_kv_heads``, the function will use
        `grouped query attention <https://arxiv.org/abs/2305.13245>`_.

        The :meth:`plan` method cannot be used in Cuda Graph or in ``torch.compile``.
        """
        _check_workspace_buffer_alignment(
            self._float_workspace_buffer, "float_workspace_buffer"
        )
        _check_workspace_buffer_alignment(
            self._int_workspace_buffer, "int_workspace_buffer"
        )
        # every plan() decides the specialized verify kernel afresh
        self._eagle_verify_fp8kv_sm90_state = None
        q_data_type = canonicalize_torch_dtype(q_data_type)
        if kv_data_type is None:
            kv_data_type = q_data_type
        kv_data_type = canonicalize_torch_dtype(kv_data_type)
        if o_data_type is None:
            o_data_type = q_data_type
        o_data_type = canonicalize_torch_dtype(o_data_type)

        if logits_soft_cap is None:
            logits_soft_cap = 0.0
        if head_dim_vo is None:
            head_dim_vo = head_dim_qk
        if fixed_split_size is None:
            fixed_split_size = -1

        batch_size = len(qo_indptr) - 1
        self._batch_size = batch_size
        self._num_qo_heads = num_qo_heads
        self._num_kv_heads = num_kv_heads
        if custom_mask is not None or packed_custom_mask is not None:
            mask_indptr = _compute_page_mask_indptr(
                qo_indptr,
                paged_kv_indptr,
                paged_kv_last_page_len,
                page_size,
            )
        if packed_custom_mask is None and custom_mask is not None:
            # create packed custom mask from custom mask
            # The segment_packbits kernel requires the indptr on the mask's
            # device (CHECK_DEVICE in quantization.cu), but mask_indptr
            # inherits qo_indptr's device, which callers (e.g. vLLM) routinely
            # keep on CPU while the mask is on GPU.
            packed_custom_mask, mask_indptr = segment_packbits(
                custom_mask.contiguous().view(-1),
                mask_indptr.to(custom_mask.device),
                bitorder="little",
            )

        if prefix_len_ptr is not None and self._variant_owns_mask:
            raise ValueError(
                "prefix_len_ptr (multi-item scoring) selects "
                "MaskMode.MULTIITEMSCORING, which overrides the MaskMode.CUSTOM "
                "required by variant_owns_mask; the two are incompatible."
            )
        self._prefix_len_ptr = prefix_len_ptr
        self._token_pos_in_items_ptr = token_pos_in_items_ptr
        self._token_pos_in_items_len = token_pos_in_items_len
        self._max_item_len_ptr = max_item_len_ptr

        # NOTE(Zihao): only required if qo_indptr/paged_kv_indptr are device tensors
        qo_indptr_host = qo_indptr.to("cpu")
        self._qo_indptr_last = int(qo_indptr_host[-1])
        total_num_rows = self._qo_indptr_last
        if max_token_per_sequence is not None:
            self._max_q_len = max_token_per_sequence
        else:
            self._max_q_len = (qo_indptr_host[1:] - qo_indptr_host[:-1]).max().item()

        if max_sequence_kv is not None:
            self._max_kv_len = max_sequence_kv
        # Non-cuDNN planners still consume host page metadata even when the
        # caller supplies a maximum. Keep cuDNN's device-length fast path.
        if max_sequence_kv is None or self._backend != "cudnn":
            paged_kv_indptr_host = paged_kv_indptr.to("cpu")
            paged_kv_last_page_len_host = paged_kv_last_page_len.to("cpu")
            if seq_lens is None:
                kv_lens_arr_host = get_seq_lens(
                    paged_kv_indptr_host, paged_kv_last_page_len_host, page_size
                )
            else:
                kv_lens_arr_host = seq_lens.cpu().flatten().to(torch.int32)
            required_size = len(kv_lens_arr_host)
            if required_size > self._kv_lens_buffer.shape[0]:
                self._kv_lens_buffer = torch.empty(
                    (required_size,), dtype=torch.int32, device=self.device
                )
            self._kv_lens_buffer[:required_size].copy_(
                kv_lens_arr_host, non_blocking=non_blocking
            )
            if max_sequence_kv is None:
                self._max_kv_len = kv_lens_arr_host.max().item()

        if self.is_cuda_graph_enabled:
            if self._max_total_num_rows is None:
                self._max_total_num_rows = total_num_rows
            elif total_num_rows > self._max_total_num_rows:
                raise ValueError(
                    "The total number of rows in qo_indptr {} in cuda graph mode cannot "
                    "exceed the number of rows set during initialization {}.".format(
                        total_num_rows, self._max_total_num_rows
                    )
                )

            if batch_size != self._fixed_batch_size:
                raise ValueError(
                    "The batch size should be fixed during the lifecycle of the wrapper in "
                    "cuda graph mode, the runtime batch size {} mismatches the batch size {} "
                    " set during initialization.".format(
                        batch_size, self._fixed_batch_size
                    )
                )
            if len(paged_kv_indices) > len(self._paged_kv_indices_buf):
                raise ValueError(
                    "The length of paged_kv_indices exceeds the allocated buffer size."
                )

            self._qo_indptr_buf.copy_(qo_indptr, non_blocking=non_blocking)
            self._paged_kv_indptr_buf.copy_(paged_kv_indptr, non_blocking=non_blocking)
            self._paged_kv_last_page_len_buf.copy_(
                paged_kv_last_page_len, non_blocking=non_blocking
            )
            self._paged_kv_indices_buf[: len(paged_kv_indices)].copy_(
                paged_kv_indices,
                non_blocking=(paged_kv_indices.device == self.device) and non_blocking,
            )

            if packed_custom_mask is not None:
                if not torch.is_tensor(self._custom_mask_buf):
                    raise ValueError(
                        "custom_mask_buf must be initialized with a torch.Tensor in cuda graph mode if we use custom mask in attention computation."
                    )
                if not torch.is_tensor(self._mask_indptr_buf):
                    raise ValueError(
                        "mask_indptr_buf must be initialized with a torch.Tensor in cuda graph mode if we use custom mask in attention computation."
                    )
                self._custom_mask_buf[: len(packed_custom_mask)].copy_(
                    packed_custom_mask,
                    non_blocking=(packed_custom_mask.device == self.device)
                    and non_blocking,
                )
                # NOTE(Zihao): mask_indptr has the same length as qo_indptr
                self._mask_indptr_buf.copy_(mask_indptr, non_blocking=non_blocking)
        else:
            self._qo_indptr_buf = qo_indptr.to(self.device, non_blocking=non_blocking)
            self._paged_kv_indptr_buf = paged_kv_indptr.to(
                self.device, non_blocking=non_blocking
            )
            self._paged_kv_indices_buf = paged_kv_indices.to(
                self.device, non_blocking=non_blocking
            )
            self._paged_kv_last_page_len_buf = paged_kv_last_page_len.to(
                self.device, non_blocking=non_blocking
            )
            if packed_custom_mask is not None:
                self._custom_mask_buf = packed_custom_mask.to(
                    self.device, non_blocking=non_blocking
                )
                self._mask_indptr_buf = mask_indptr.to(
                    self.device, non_blocking=non_blocking
                )
            else:
                self._custom_mask_buf = None
                self._mask_indptr_buf = None

        self._cached_q_data_type = q_data_type
        self._cached_kv_data_type = kv_data_type
        self._cached_o_data_type = o_data_type

        if self._backend == "cute-dsl":
            if custom_mask is not None or packed_custom_mask is not None:
                raise NotImplementedError(
                    "cute-dsl backend does not support custom_mask"
                )
            if head_dim_vo is not None and head_dim_vo != head_dim_qk:
                raise NotImplementedError(
                    "cute-dsl backend requires head_dim_vo == head_dim_qk"
                )
            if pos_encoding_mode not in ("NONE", "ALIBI"):
                raise NotImplementedError(
                    f"cute-dsl backend does not support pos_encoding_mode={pos_encoding_mode!r}. "
                    "For RoPE, apply rotary embeddings to Q/K before calling the kernel."
                )
            if kv_data_type is not None and q_data_type != kv_data_type:
                raise ValueError(
                    "cute-dsl paged prefill requires q_data_type == "
                    f"kv_data_type, got {q_data_type} and {kv_data_type}"
                )

            cute_variant: Optional[Any] = None
            if pos_encoding_mode == "ALIBI":
                from .cute_dsl.attention import ALiBiAttention

                slopes = ALiBiAttention.get_slopes(num_qo_heads)
                cute_variant = ALiBiAttention(
                    torch.tensor(slopes, dtype=torch.float32, device=self.device)
                )
            if logits_soft_cap is not None and logits_soft_cap > 0:
                from .cute_dsl.attention import SoftCappingAttention

                if cute_variant is not None:
                    raise NotImplementedError(
                        "the public cute-dsl route cannot combine ALiBi with "
                        "logits_soft_cap (one plan-time variant per kernel); "
                        "a fused custom variant can express both — use "
                        "flashinfer.cute_dsl.attention."
                        "BatchPrefillCuteDSLWrapper with plan(..., variant=...)"
                    )
                cute_variant = SoftCappingAttention(cap=logits_soft_cap)

            _sm_scale = (
                sm_scale if sm_scale is not None else 1.0 / math.sqrt(head_dim_qk)
            )
            # All paged plans use the modular kernel — the vendored FMHA
            # artifacts (the ragged wrapper's dense/causal route) have no
            # paged variant.
            # Consume the wrapper-owned buffers (populated above) rather
            # than the raw arguments: they are the stable-address contract
            # for CUDA-graph mode and the single normalized copy otherwise.
            self._cute_dsl_wrapper.plan(
                self._qo_indptr_buf,
                None,
                num_qo_heads,
                num_kv_heads,
                head_dim_qk,
                head_dim_vo=head_dim_qk,
                causal=causal,
                sm_scale=_sm_scale,
                q_data_type=q_data_type,
                kv_data_type=kv_data_type if kv_data_type is not None else q_data_type,
                window_left=window_left,
                variant=cute_variant,
                page_size=page_size,
                paged_kv_indptr=self._paged_kv_indptr_buf,
                paged_kv_indices=self._paged_kv_indices_buf,
                paged_kv_last_page_len=self._paged_kv_last_page_len_buf,
                kv_layout=self._kv_layout,
            )
        elif self._backend == "cute-dsl-prims":
            from .attention.cute_dsl.sm120_fmha import (
                _validate_sm120_prims_plan_options,
            )

            _validate_sm120_prims_plan_options(
                kv_layout=self._kv_layout,
                required_kv_layout="HND",
                custom_mask=custom_mask,
                packed_custom_mask=packed_custom_mask,
                pos_encoding_mode=pos_encoding_mode,
                use_fp16_qk_reduction=use_fp16_qk_reduction,
                window_left=window_left,
                logits_soft_cap=logits_soft_cap,
                prefix_len_ptr=prefix_len_ptr,
                token_pos_in_items_ptr=token_pos_in_items_ptr,
                max_item_len_ptr=max_item_len_ptr,
                max_sequence_kv=max_sequence_kv,
                fixed_split_size=fixed_split_size,
            )
            if block_tables is None:
                block_tables = _build_block_tables_from_paged_kv_indices(
                    paged_kv_indptr_host,
                    self._paged_kv_indices_buf,
                    batch_size,
                    self.device,
                )
            self._block_tables = block_tables
            assert self._prims_backend is not None
            self._prims_backend.plan_paged(
                qo_indptr=self._qo_indptr_buf,
                qo_indptr_host=qo_indptr_host,
                seqlens_kv=self._kv_lens_buffer[:batch_size],
                seqlens_kv_host=kv_lens_arr_host,
                block_tables=self._block_tables,
                q_dtype=q_data_type,
                kv_dtype=kv_data_type,
                o_dtype=o_data_type,
                num_qo_heads=num_qo_heads,
                num_kv_heads=num_kv_heads,
                head_dim_qk=head_dim_qk,
                head_dim_vo=head_dim_vo,
                page_size=page_size,
                causal=causal,
                sm_scale=sm_scale,
            )
        elif self._jit_module is not None:
            self._cached_module = self._jit_module
        else:
            if self._backend == "auto":
                self._backend = determine_attention_backend(
                    self.device,
                    PosEncodingMode[pos_encoding_mode].value,
                    use_fp16_qk_reduction,
                    self._custom_mask_buf is not None,  # use_custom_mask
                    q_data_type,
                    kv_data_type,
                    head_dim_qk=head_dim_qk,
                    head_dim_vo=head_dim_vo,
                )
            if self._backend != "cudnn":
                get_module_args = (
                    q_data_type,
                    kv_data_type,
                    o_data_type,
                    paged_kv_indptr.dtype,
                    head_dim_qk,
                    head_dim_vo,
                    PosEncodingMode[pos_encoding_mode].value,
                    window_left >= 0,  # use_sliding_window
                    logits_soft_cap > 0,  # use_logits_soft_cap
                    use_fp16_qk_reduction,
                )

                self._cached_module = get_batch_prefill_module(
                    self._backend, *get_module_args
                )

        self._block_tables = block_tables
        if self._backend == "trtllm-gen":
            # Allocated once per plan and reused across run() launches; the
            # trtllm-gen kernel self-resets the counters after each launch.
            self._trtllm_gen_multi_ctas_kv_counter_buffer = (
                _get_trtllm_gen_multi_ctas_kv_counter_buffer(
                    batch_size,
                    num_qo_heads,
                    get_device_sm_count(self.device),
                    self.device,
                )
            )
            if logits_soft_cap != 0.0:
                raise ValueError(
                    "logits_soft_cap must be 0.0 for trtllm-gen paged KV cache"
                )
            if not causal and window_left >= 0:
                raise NotImplementedError(
                    "Sliding-window non-causal attention is not supported for trtllm-gen paged KV cache. "
                    "Use window_left=-1 for dense bidirectional attention."
                )
            if self._block_tables is None:
                self._block_tables = _build_block_tables_from_paged_kv_indices(
                    paged_kv_indptr_host,
                    paged_kv_indices,
                    batch_size,
                    self.device,
                )

        if self._cached_module is not None:
            args = [
                self._float_workspace_buffer,
                self._int_workspace_buffer,
                self._pin_memory_int_workspace_buffer,
                qo_indptr_host,
                paged_kv_indptr_host,
                kv_lens_arr_host,
                self._max_total_num_rows or total_num_rows,
                batch_size,
                num_qo_heads,
                num_kv_heads,
                page_size,
                self.is_cuda_graph_enabled,
                head_dim_qk,
                head_dim_vo,
                causal,
                window_left,
            ]
            if self._backend == "fa2":
                args.append(fixed_split_size or -1)  # fixed_split_size
                if not disable_split_kv and _nvfp4_kv_requires_disabled_split_kv(
                    kv_data_type, self.device
                ):
                    # Empirical workaround: split-KV corrupted NVFP4 KV reads
                    # when qo_len << kv_len (decode / prefix-cache extend); see
                    # _nvfp4_kv_requires_disabled_split_kv for details.
                    disable_split_kv = True
                args.append(disable_split_kv)  # disable_split_kv
                args.append(0)  # num_colocated_ctas
                forwarded_uniform_q_len = _resolve_uniform_q_len(
                    uniform_q_len,
                    qo_indptr_host,
                    self.is_cuda_graph_enabled,
                    self._backend,
                    "BatchPrefillWithPagedKVCacheWrapper.plan",
                )
                args.append(forwarded_uniform_q_len)
            self._plan_info = self._cached_module.plan(
                *args,
            )
            if self._backend == "fa2":
                # specialized SM90 fp8-KV verify kernel: eligibility, JIT
                # build and workspace are settled here, outside the hot path
                # The kernel route needs the caller's promise to hold on the
                # host batch, not the FA2 planner to have consumed it: the
                # eager planner never reads the hint, so forwarded_uniform_q_len
                # is 0 there while the shape contract is the same.
                _eagle_verify_fp8kv_sm90_prepare(
                    self,
                    _host_uniform_q_len(uniform_q_len, qo_indptr_host),
                    self._custom_mask_buf is not None,
                    num_qo_heads,
                    num_kv_heads,
                    head_dim_qk,
                    head_dim_vo,
                    page_size,
                    q_data_type,
                    kv_data_type,
                    o_data_type,
                    pos_encoding_mode,
                    use_fp16_qk_reduction,
                    batch_size,
                    qo_indptr_host=qo_indptr_host,
                    packed_mask_bytes=(
                        int(packed_custom_mask.numel())
                        if packed_custom_mask is not None
                        else 0
                    ),
                )

        self._causal = causal
        self._pos_encoding_mode = pos_encoding_mode
        self._use_fp16_qk_reduction = use_fp16_qk_reduction
        self._window_left = window_left
        self._logits_soft_cap = logits_soft_cap
        self._sm_scale = sm_scale
        self._rope_scale = rope_scale
        self._rope_theta = rope_theta
        self._seq_lens_kv = seq_lens
        self._seq_lens_q = seq_lens_q if seq_lens_q is not None else seq_lens

        if self._backend == "cudnn":
            if (
                pos_encoding_mode != "NONE"
                or window_left != -1
                or logits_soft_cap != 0
                or packed_custom_mask is not None
                or self._variant_owns_mask
                or prefix_len_ptr is not None
            ):
                raise NotImplementedError(
                    "cuDNN paged prefill supports only causal or full attention without "
                    "position encoding, window_left, logits_soft_cap or custom masks"
                )
            if self._qo_indptr_buf.dtype != torch.int32:
                if self.is_cuda_graph_enabled:
                    raise ValueError(
                        "cuDNN requires int32 qo_indptr buffers in CUDA-graph mode"
                    )
                self._qo_indptr_buf = self._qo_indptr_buf.to(torch.int32)
            # Without an explicit maximum, KV lengths were already staged
            # above to compute _max_kv_len. With one, still update the captured
            # buffer on every plan; the bound does not replace actual lengths.
            # Supplied lengths are copied straight from their own device into
            # the wrapper-owned buffers (stream-ordered, cast on copy); reading
            # them back to the host would block plan() on all queued GPU work.
            if max_sequence_kv is not None:
                kv_lengths = (
                    seq_lens.flatten()
                    if seq_lens is not None
                    else get_seq_lens(
                        paged_kv_indptr.to("cpu"),
                        paged_kv_last_page_len.to("cpu"),
                        page_size,
                    )
                )
                if batch_size > self._kv_lens_buffer.shape[0]:
                    self._kv_lens_buffer = torch.empty(
                        batch_size, dtype=torch.int32, device=self.device
                    )
                self._kv_lens_buffer[:batch_size].copy_(
                    kv_lengths, non_blocking=non_blocking
                )
            self._seq_lens_kv = self._kv_lens_buffer[:batch_size].view(
                batch_size, 1, 1, 1
            )
            if (
                self._cudnn_q_lens_buffer is None
                or self._cudnn_q_lens_buffer.shape[0] < batch_size
            ):
                self._cudnn_q_lens_buffer = torch.empty(
                    batch_size, dtype=torch.int32, device=self.device
                )
            q_lengths = (
                seq_lens_q.flatten()
                if seq_lens_q is not None
                else qo_indptr_host[1:] - qo_indptr_host[:-1]
            )
            self._cudnn_q_lens_buffer[:batch_size].copy_(
                q_lengths, non_blocking=non_blocking
            )
            self._seq_lens_q = self._cudnn_q_lens_buffer[:batch_size].view(
                batch_size, 1, 1, 1
            )
            if block_tables is None:
                table = _build_block_tables_from_paged_kv_indices(
                    paged_kv_indptr.to("cpu"), paged_kv_indices, batch_size, self.device
                )
                old_table = self._cudnn_block_tables
                if (
                    old_table is None
                    or old_table.shape[0] != batch_size
                    or old_table.shape[1] < table.shape[1]
                ):
                    if self.is_cuda_graph_enabled and old_table is not None:
                        raise ValueError(
                            "captured cuDNN block table cannot grow; supply a fixed block_tables buffer"
                        )
                    self._cudnn_block_tables = table
                else:
                    old_table.zero_()
                    old_table[:, : table.shape[1]].copy_(table)
                self._block_tables = self._cudnn_block_tables
            previous_cudnn_plan = self._cudnn_plan
            self._cudnn_plan = None
            if _CUDNN_GRAPH_AVAILABLE and _cudnn_supports_direct_seqlens(
                q_data_type, mixed=True
            ):
                metadata = _PrefillMetadata(
                    self._max_q_len,
                    self._max_kv_len,
                    causal,
                    True,
                    o_data_type=o_data_type,
                    actual_seq_lens_q=self._seq_lens_q,
                    actual_seq_lens_kv=self._seq_lens_kv,
                    block_tables=self._block_tables,
                    batch_offsets_q=self._qo_indptr_buf,
                    batch_offsets_o=self._qo_indptr_buf,
                    batch_offsets_stats=self._qo_indptr_buf,
                ).resolve_from_plan(
                    q_data_type, num_qo_heads, num_kv_heads, head_dim_qk, head_dim_vo
                )
                self._cudnn_plan = _CudnnPrefillPlan.prepare(
                    metadata, q_data_type, self.device, previous_cudnn_plan
                )

    @flashinfer_api
    def prewarm_paged_kv_stride_variant(self, variant: str = "independent") -> None:
        r"""Load a lazy paged-KV-stride variant after :meth:`plan`.

        Call this method before CUDA graph capture when a planned standard FA2
        wrapper will receive K and V tensors with different data strides.

        Parameters
        ----------
        variant : str
            The paged-KV-stride variant to prewarm. The only supported value is
            ``"independent"`` (the default), for K and V with different data strides.
        """
        if (
            getattr(self, "_plan_info", None) is None
            or getattr(self, "_cached_module", None) is None
        ):
            raise RuntimeError(
                "plan() must complete before prewarming a paged-KV-stride variant."
            )
        if self._jit_module is not None:
            raise RuntimeError(
                "Paged-KV-stride prewarm is not supported for a custom JIT module."
            )
        if self._backend != "fa2":
            raise RuntimeError(
                "Paged-KV-stride prewarm requires a standard FA2 plan, "
                f"got backend={self._backend!r}."
            )
        assert self._cached_module is not None
        with torch.cuda.device(self.device):
            self._cached_module.prewarm_paged_kv_stride_variant(variant)

    begin_forward = plan

    def forward(
        self,
        q: torch.Tensor,
        paged_kv_cache: Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]],
        causal: bool = False,
        pos_encoding_mode: str = "NONE",
        use_fp16_qk_reduction: bool = False,
        k_scale: Optional[float] = None,
        v_scale: Optional[float] = None,
        window_left: int = -1,
        logits_soft_cap: Optional[float] = None,
        sm_scale: Optional[float] = None,
        rope_scale: Optional[float] = None,
        rope_theta: Optional[float] = None,
    ) -> torch.Tensor:
        r"""Warning: This function is deprecated, please use :meth:`run` instead."""
        self._causal = causal
        self._pos_encoding_mode = pos_encoding_mode
        self._use_fp16_qk_reduction = use_fp16_qk_reduction
        self._window_left = window_left
        self._logits_soft_cap = logits_soft_cap
        self._sm_scale = sm_scale
        self._rope_scale = rope_scale
        self._rope_theta = rope_theta
        return self.run(q, paged_kv_cache, k_scale=k_scale, v_scale=v_scale)

    @overload
    def run(
        self,
        q: torch.Tensor,
        paged_kv_cache: Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]],
        *args,
        q_scale: Optional[Union[float, torch.Tensor]] = None,
        k_scale: Optional[Union[float, torch.Tensor]] = None,
        v_scale: Optional[Union[float, torch.Tensor]] = None,
        out: Optional[torch.Tensor] = None,
        lse: Optional[torch.Tensor] = None,
        return_lse: Literal[False] = False,
        lse_base: str = "log2",
        lse_layout: str = "NH",
        enable_pdl: Optional[bool] = None,
        window_left: Optional[int] = None,
        sinks: Optional[torch.Tensor] = None,
        kv_cache_sf: Optional[
            Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]
        ] = None,
        skip_softmax_threshold_scale_factor: Optional[float] = None,
        use_fp16_softmax: Optional[bool] = None,
        uses_spcompress: Optional[bool] = None,
    ) -> torch.Tensor: ...

    @overload
    def run(
        self,
        q: torch.Tensor,
        paged_kv_cache: Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]],
        *args,
        q_scale: Optional[Union[float, torch.Tensor]] = None,
        k_scale: Optional[Union[float, torch.Tensor]] = None,
        v_scale: Optional[Union[float, torch.Tensor]] = None,
        out: Optional[torch.Tensor] = None,
        lse: Optional[torch.Tensor] = None,
        return_lse: Literal[True] = True,
        lse_base: str = "log2",
        lse_layout: str = "NH",
        enable_pdl: Optional[bool] = None,
        window_left: Optional[int] = None,
        sinks: Optional[torch.Tensor] = None,
        kv_cache_sf: Optional[
            Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]
        ] = None,
        skip_softmax_threshold_scale_factor: Optional[float] = None,
        use_fp16_softmax: Optional[bool] = None,
        uses_spcompress: Optional[bool] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]: ...

    @flashinfer_api(trace=gqa_paged_prefill_trace)
    def run(
        self,
        q: torch.Tensor,
        paged_kv_cache: Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]],
        *args,
        q_scale: Optional[Union[float, torch.Tensor]] = None,
        k_scale: Optional[Union[float, torch.Tensor]] = None,
        v_scale: Optional[Union[float, torch.Tensor]] = None,
        out: Optional[torch.Tensor] = None,
        lse: Optional[torch.Tensor] = None,
        return_lse: bool = False,
        lse_base: str = "log2",
        lse_layout: str = "NH",
        enable_pdl: Optional[bool] = None,
        window_left: Optional[int] = None,
        sinks: Optional[torch.Tensor] = None,
        kv_cache_sf: Optional[
            Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]
        ] = None,
        skip_softmax_threshold_scale_factor: Optional[float] = None,
        use_fp16_softmax: Optional[bool] = None,
        uses_spcompress: Optional[bool] = None,
    ) -> Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
        r"""Compute batch prefill/append attention between query and paged kv-cache.

        Parameters
        ----------
        q : torch.Tensor
            The query tensor, shape: ``[qo_indptr[-1], num_qo_heads, head_dim]``
        paged_kv_cache : Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]
            The paged KV-Cache stored as a tuple of tensors or a single tensor:

            * a tuple ``(k_cache, v_cache)`` of 4-D tensors, each with shape:
              ``[max_num_pages, page_size, num_kv_heads, head_dim]`` if :attr:`kv_layout` is ``NHD``,
              and ``[max_num_pages, num_kv_heads, page_size, head_dim]`` if :attr:`kv_layout` is ``HND``.

            * a single 5-D tensor with shape:
              ``[max_num_pages, 2, page_size, num_kv_heads, head_dim]`` if
              :attr:`kv_layout` is ``NHD``, and
              ``[max_num_pages, 2, num_kv_heads, page_size, head_dim]`` if
              :attr:`kv_layout` is ``HND``. Where ``paged_kv_cache[:, 0]`` is the key-cache and
              ``paged_kv_cache[:, 1]`` is the value-cache.

        *args
            Additional arguments for custom kernels.
        q_scale : Optional[Union[float, torch.Tensor]]
            The calibration scale of query for fp8 input, if not provided, will be set to ``1.0``.
        k_scale : Optional[Union[float, torch.Tensor]]
            The calibration scale of key for fp8 or nvfp4 input, if not provided, will be set to ``1.0``.
        v_scale : Optional[Union[float, torch.Tensor]]
            The calibration scale of value for fp8 or nvfp4 input, if not provided, will be set to ``1.0``.
        out : Optional[torch.Tensor]
            The output tensor, if not provided, will be allocated internally.
        lse : Optional[torch.Tensor]
            The log-sum-exp of attention logits, if not provided, will be allocated internally.
        return_lse : bool
            Whether to return the logsumexp of attention output
        lse_base : str
            Base of the returned ``lse`` when :attr:`return_lse` is ``True``:
            ``"log2"`` (default, FlashInfer's convention, ``max + log2(sum(exp2(...)))``)
            or ``"ln"`` (natural log, the ``torch.logsumexp`` convention that merge
            kernels written with ``expf`` consume). ``"ln"`` lets the cuDNN backend hand
            out its native stats without a conversion kernel; the other backends rescale.
        lse_layout : str
            Layout of the returned ``lse``: ``"NH"`` (default) is
            ``[qo_indptr[-1], num_qo_heads]``, ``"HN"`` is the contiguous transpose
            ``[num_qo_heads, qo_indptr[-1]]`` (one fused transpose + rescale kernel).
            A caller-provided :attr:`lse` must have the requested layout.
        enable_pdl : bool
            Whether to enable Programmatic Dependent Launch (PDL). See https://docs.nvidia.com/cuda/cuda-c-programming-guide/#programmatic-dependent-launch-and-synchronization
            Only effective on backends and devices that support PDL.
        window_left : Optional[int]
            Per-call override for the left (inclusive) sliding-window size.  When
            ``None``, the value supplied to :meth:`plan` is used.  Pass ``-1`` to
            disable the sliding window for this call.
        sinks : Optional[torch.Tensor]
            Per-head attention-sink logits.  When provided, the kernel applies the
            attention-with-sink variant: an additional virtual token whose logit is
            ``sinks[head_idx]`` is appended to each row of the softmax denominator.
            Shape: ``[num_qo_heads]``, dtype ``float32``.
        kv_cache_sf : Optional[Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]]
            Per-block scale factors for NVFP4 KV cache. Accepts the same formats as
            ``paged_kv_cache``:

            * a tuple ``(k_scales, v_scales)`` of 4-D tensors, each with shape:
              ``[num_pages, page_size, num_kv_heads, head_dim // 16]`` if :attr:`kv_layout` is ``NHD``,
              and ``[num_pages, num_kv_heads, page_size, head_dim // 16]`` if :attr:`kv_layout` is ``HND``.
            * a single 5-D tensor with shape:
              ``[num_pages, 2, page_size, num_kv_heads, head_dim // 16]`` if :attr:`kv_layout` is ``NHD``,
              and ``[num_pages, 2, num_kv_heads, page_size, head_dim // 16]`` if :attr:`kv_layout` is ``HND``,
              where dim 1 holds k (index 0) and v (index 1) scales.

            Both tensors have dtype ``torch.float8_e4m3fn``. ``k_scales`` uses a linear
            (row-major) layout, while ``v_scales`` must use TRT-LLM's 4-token interleaved
            layout within each ``[page_size, head_dim // 16]`` tile if backend is `trtllm-gen`. Use
            :func:`flashinfer.fp4_quantization.nvfp4_quantize_paged_kv_cache` to produce
            correctly formatted scale factors.

            For the trtllm-gen backend with ``NHD`` layout, scale tensors are transposed
            to HND internally (incurring a copy). Use ``HND`` for better performance.
            Currently, NVFP4 KV supports `fa2` and `trtllm-gen` backend.
        use_fp16_softmax : Optional[bool]
            trtllm-gen backend only. Select the ``…Fp16Softmax…`` cubin variant
            (FP16 softmax accumulator). Currently only shipped for BF16 Q/KV/O context
            kernels. Ignored by other backends.
        uses_spcompress : Optional[bool]
            trtllm-gen backend only. Select the ``…Spcomp…`` cubin variant
            (sparse compression). Currently only shipped for FP8 Q context kernels.
            Ignored by other backends.

        skip_softmax_threshold_scale_factor : Optional[float]
            Threshold scale factor for skipping softmax operations.  Providing a
            value enables skip-softmax sparsity as described in
            https://arxiv.org/abs/2512.12087.  Defaults to ``None`` (standard
            attention).  Higher values yield faster kernels at the cost of accuracy;
            the effective threshold equals the supplied factor divided by the
            context length.
        Returns
        -------
        Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]
            If :attr:`return_lse` is ``False``, the attention output, shape: ``[qo_indptr[-1], num_qo_heads, head_dim]``.
            If :attr:`return_lse` is ``True``, a tuple of two tensors:

            * The attention output, shape: ``[qo_indptr[-1], num_qo_heads, head_dim]``.
            * The logsumexp of attention output, shape: ``[qo_indptr[-1], num_qo_heads]``
              (``lse_layout="NH"``, default) or ``[num_qo_heads, qo_indptr[-1]]``
              (``"HN"``), in the base selected by :attr:`lse_base`.
        """
        if enable_pdl is None:
            enable_pdl = device_support_pdl(q.device)
        k_cache, v_cache = _unpack_paged_kv_cache(paged_kv_cache, self._kv_layout)
        check_lse_base(lse_base)
        check_lse_layout(lse_layout)
        _check_cached_qkv_data_type(
            q, k_cache, self._cached_q_data_type, self._cached_kv_data_type
        )
        # Validate q shape matches qo_indptr (using value cached in plan() to avoid GPU sync)
        if self._backend == "cudnn":
            if q.size(0) != self._qo_indptr_last:
                hint = ""
                if q.numel() == self._qo_indptr_last:
                    hint = (
                        " qo_indptr looks like element-unit offsets "
                        "(total_tokens * num_heads * head_dim); the cudnn backend now "
                        "takes token-unit qo_indptr, like every other backend."
                    )
                raise ValueError(
                    f"q.shape[0] ({q.size(0)}) does not match qo_indptr[-1] ({self._qo_indptr_last})."
                    + hint
                )
        else:
            if q.size(0) != self._qo_indptr_last:
                raise ValueError(
                    f"q.shape[0] ({q.size(0)}) does not match qo_indptr[-1] ({self._qo_indptr_last}). "
                    f"For paged prefill, q must have shape [total_tokens, num_heads, head_dim] "
                    f"where total_tokens = qo_indptr[-1]."
                )

        if self._backend == "cute-dsl":
            if q_scale is not None or k_scale is not None or v_scale is not None:
                raise NotImplementedError(
                    "cute-dsl paged backend does not support q/k/v scale factors"
                )
            if kv_cache_sf is not None:
                raise NotImplementedError(
                    "cute-dsl paged backend does not support NVFP4 KV cache "
                    "scale factors (kv_cache_sf)"
                )
            if sinks is not None:
                raise NotImplementedError(
                    "the public cute-dsl paged route does not accept run-time "
                    "attention sinks yet; the backend supports sinks as a "
                    "plan-time variant — use flashinfer.cute_dsl.attention."
                    "BatchPrefillCuteDSLWrapper with "
                    "plan(..., variant=AttentionWithSink(sinks))"
                )
            if skip_softmax_threshold_scale_factor is not None:
                raise NotImplementedError(
                    "cute-dsl paged backend does not support skip-softmax"
                )
            if window_left is not None and window_left != self._window_left:
                raise NotImplementedError(
                    "cute-dsl paged backend does not support per-call "
                    "window_left overrides; re-plan instead"
                )
            # enable_pdl is accepted as a hint (no-op for the modular kernel,
            # matching the ragged cute-dsl route).
            if out is None and q.dtype.itemsize == 1:
                # fp8 inputs produce bf16 output, matching the ragged
                # cute-dsl route's convention (the kernel's native scratch
                # is fp16; the copy-out converts).
                out = torch.empty(q.shape, dtype=torch.bfloat16, device=q.device)
            lse, lse_out = _stage_lse(lse, lse_layout, return_lse, q)
            res = self._cute_dsl_wrapper.run_paged(
                q,
                (k_cache, v_cache),
                out=out,
                return_lse=return_lse,
                lse=lse,
            )
            if isinstance(res, tuple):
                return res[0], _finish_lse(res[1], lse_base, lse_layout, lse_out)
            return res
        elif self._backend == "cute-dsl-prims":
            if args:
                raise NotImplementedError(
                    "backend='cute-dsl-prims' does not accept custom run arguments"
                )
            if sinks is not None:
                raise NotImplementedError(
                    "backend='cute-dsl-prims' does not support attention sinks"
                )
            if kv_cache_sf is not None:
                raise NotImplementedError(
                    "backend='cute-dsl-prims' does not support NVFP4 kv_cache_sf"
                )
            if skip_softmax_threshold_scale_factor is not None:
                raise NotImplementedError(
                    "backend='cute-dsl-prims' does not support "
                    "skip_softmax_threshold_scale_factor"
                )
            if window_left is not None and window_left != self._window_left:
                raise NotImplementedError(
                    "backend='cute-dsl-prims' does not support a run-time "
                    "window_left override"
                )
            if k_cache.ndim != 4 or v_cache.shape != k_cache.shape:
                raise ValueError(
                    "backend='cute-dsl-prims' requires HND K/V pools with shape "
                    "[num_pages, num_kv_heads, page_size, head_dim]"
                )
            if out is None:
                out = torch.empty(
                    q.shape,
                    dtype=self._cached_o_data_type,
                    device=q.device,
                )
            assert self._prims_backend is not None
            lse, lse_out = _stage_lse(lse, lse_layout, return_lse, q)
            res = self._prims_backend.run_paged(
                q,
                k_cache,
                v_cache,
                out,
                return_lse=return_lse,
                lse=lse,
                enable_pdl=enable_pdl,
                q_scale=q_scale,
                k_scale=k_scale,
                v_scale=v_scale,
            )
            if isinstance(res, tuple):
                return res[0], _finish_lse(res[1], lse_base, lse_layout, lse_out)
            return res

        check_trtllm_gen_sm107_only_feature(
            use_fp16_softmax, "use_fp16_softmax", q.device
        )
        check_trtllm_gen_sm107_only_feature(
            uses_spcompress, "uses_spcompress", q.device
        )

        if (
            k_cache.dtype == torch.uint8 or v_cache.dtype == torch.uint8
        ) and kv_cache_sf is None:
            raise ValueError("kv_cache_sf must be provided for NVFP4 KV cache.")
        key_block_scales, value_block_scales = (
            _unpack_paged_kv_cache(kv_cache_sf, self._kv_layout)
            if kv_cache_sf is not None
            else (None, None)
        )

        o_dtype = self._cached_o_data_type
        if out is not None and out.dtype != o_dtype:
            raise ValueError(
                f"The dtype of out {out.dtype} does not match the o_data_type {o_dtype} specified in plan function."
            )

        if self._kv_layout == "NHD":
            page_size = k_cache.shape[1]
        else:
            page_size = k_cache.shape[2]
        window_left = self._window_left if window_left is None else window_left
        if self._backend != "trtllm-gen":
            # NOTE(Siyuan): since window_left is appeared in the plan function, we need to make sure it is the same as the one in the plan function.
            # Remove this check if the backend supports dynamic window_left.
            assert window_left == self._window_left
        logits_soft_cap = self._logits_soft_cap
        sm_scale = self._sm_scale
        rope_scale = self._rope_scale
        rope_theta = self._rope_theta
        if logits_soft_cap is None:
            logits_soft_cap = 0.0
        if sm_scale is None:
            sm_scale = 1.0 / math.sqrt(q.size(-1))
        if self._backend != "cudnn":
            if q_scale is not None:
                sm_scale *= q_scale
            if k_scale is not None:
                sm_scale *= k_scale
        if rope_scale is None:
            rope_scale = 1.0
        if rope_theta is None:
            rope_theta = 1e4
        lse, lse_out = _stage_lse(lse, lse_layout, return_lse, q)
        if return_lse:
            if lse is None:
                lse = torch.empty(
                    (q.size(0), q.size(1)), dtype=torch.float32, device=q.device
                )
            else:
                check_shape_dtype_device(
                    lse, (q.size(0), q.size(1)), torch.float32, q.device, "lse"
                )

        # For NVFP4 KV (uint8 packed), v_cache last dim is head_dim//2;
        # use q's head_dim for output instead
        # For NVFP4 KV (uint8 packed), v_cache last dim is packed bytes
        # (2 values per byte): the unpacked VO width is v_cache.shape[-1]*2,
        # which equals head_dim_vo even for asymmetric (QK, VO) plans.
        # Using q.shape[-1] here assumed head_dim_vo == head_dim_qk and made
        # the kernel (which writes head_dim_vo-wide rows) garble a too-wide
        # output buffer whenever VO < QK.
        out_head_dim = (
            v_cache.shape[-1] * 2
            if kv_cache_sf is not None and v_cache.dtype == torch.uint8
            else v_cache.shape[-1]
        )
        if out is None:
            # Use cached output data type if available (for FP8 attention with FP16 output)
            out_dtype = getattr(self, "_cached_o_data_type", None) or q.dtype
            out = torch.zeros(
                q.shape[:-1] + (out_head_dim,), dtype=out_dtype, device=q.device
            )
        else:
            out_dtype = getattr(self, "_cached_o_data_type", None) or q.dtype
            check_shape_dtype_device(
                out, q.shape[:-1] + (out_head_dim,), out_dtype, q.device, "out"
            )

        # Convert NHD layout to HND for trtllm-gen backend
        if self._backend == "trtllm-gen" and self._kv_layout == "NHD":
            k_cache = k_cache.transpose(-3, -2)
            v_cache = v_cache.transpose(-3, -2)
            if key_block_scales is not None:
                print(
                    "[WARNING] NVFP4 KV cache with NHD layout will be converted to HND, "
                    "incurring extra transpose and contiguous copy overhead. "
                    "Use kv_layout='HND' for better performance."
                )
                k_cache = k_cache.contiguous()
                v_cache = v_cache.contiguous()
                key_block_scales = key_block_scales.transpose(-3, -2).contiguous()
                value_block_scales = value_block_scales.transpose(-3, -2).contiguous()

        if self._custom_mask_buf is not None or self._variant_owns_mask:
            mask_mode = MaskMode.CUSTOM.value
        else:
            if self._causal:
                mask_mode = MaskMode.CAUSAL.value
            else:
                mask_mode = MaskMode.NON_CAUSAL.value

        if self._prefix_len_ptr is not None:
            mask_mode = MaskMode.MULTIITEMSCORING.value

        if self._eagle_verify_fp8kv_sm90_state is not None and (
            _eagle_verify_fp8kv_sm90_dispatch(
                self,
                q,
                k_cache,
                v_cache,
                out,
                mask_mode,
                window_left,
                q_scale,
                k_scale,
                v_scale,
                return_lse,
                sinks,
                kv_cache_sf,
            )
        ):
            # the specialized kernel wrote `out`; k/v scales are identity by
            # the guard, so no post-scaling applies
            return out

        if self._backend == "cudnn":
            # The cuDNN graph declares dense output and Stats strides.
            if (
                sinks is not None
                or kv_cache_sf is not None
                or skip_softmax_threshold_scale_factor is not None
            ):
                raise NotImplementedError(
                    "cuDNN paged prefill does not support sinks, NVFP4 or skip-softmax"
                )
            if self._kv_layout == "NHD":
                k_cache = k_cache.transpose(-3, -2)
                v_cache = v_cache.transpose(-3, -2)
            if return_lse and self._max_q_len == 1 and q.shape[1] != k_cache.shape[1]:
                raise NotImplementedError(
                    "cuDNN single-token GQA prefill does not write every LSE head "
                    "(NVBug 6783545); use another backend or return_lse=False"
                )
            if not out.is_contiguous():
                raise ValueError("out must be contiguous for the cuDNN backend")
            if return_lse and not lse.is_contiguous():
                raise ValueError("lse must be contiguous for the cuDNN backend")
            if self._seq_lens_q is not None and self._seq_lens_q.dim() == 1:
                self._seq_lens_q = self._seq_lens_q.reshape(self._batch_size, 1, 1, 1)

            if self._seq_lens_kv is not None and self._seq_lens_kv.dim() == 1:
                self._seq_lens_kv = self._seq_lens_kv.reshape(self._batch_size, 1, 1, 1)

            # qo_indptr is token-unit (like every other backend). The low level
            # consumes it directly as cu_seq_len_q / the Q and O ragged offsets,
            # applying the per-tensor (num_heads * head_dim) multipliers itself, so
            # head_dim_qk != head_dim_vo is handled without any offset rescaling.
            plan = self._cudnn_plan
            if (
                plan is not None
                and plan.metadata.causal == self._causal
                and q_scale is None
                and k_scale is None
                and v_scale is None
            ):
                prepared = self._cudnn_prepared
                if prepared is None or not prepared.matches_plan(
                    q, k_cache, v_cache, sm_scale, plan, return_lse
                ):
                    prepared = self._cudnn_prepared = prepare_cudnn_batch_prefill(
                        q,
                        k_cache,
                        v_cache,
                        sm_scale,
                        self._float_workspace_buffer,
                        metadata=plan.build_metadata(return_lse),
                    )
                prepared.run_planned(
                    q,
                    k_cache,
                    v_cache,
                    out,
                    lse,
                    self._float_workspace_buffer,
                    plan=plan,
                    lse_base=lse_base,
                )
            else:
                cudnn_batch_prefill_with_kv_cache(
                    q,
                    k_cache,
                    v_cache,
                    sm_scale,
                    self._float_workspace_buffer,
                    actual_seq_lens_q=self._seq_lens_q,
                    actual_seq_lens_kv=self._seq_lens_kv,
                    max_token_per_sequence=self._max_q_len,
                    max_sequence_kv=self._max_kv_len,
                    block_tables=self._block_tables,
                    causal=self._causal,
                    return_lse=return_lse,
                    lse_base=lse_base,
                    q_scale=q_scale,
                    k_scale=k_scale,
                    v_scale=v_scale,
                    batch_offsets_q=self._qo_indptr_buf,
                    batch_offsets_stats=self._qo_indptr_buf if return_lse else None,
                    batch_offsets_units="tokens",
                    out=out,
                    lse=lse,
                    o_data_type=out_dtype,
                )
        else:
            if self._backend != "trtllm-gen":
                assert self._plan_info is not None, "plan info is not initialized"
            run_args = [
                self._float_workspace_buffer,
                self._int_workspace_buffer,
                self._plan_info,
                q,
                k_cache,
                v_cache,
                self._qo_indptr_buf,
                self._paged_kv_indptr_buf,
                self._paged_kv_indices_buf,
                self._paged_kv_last_page_len_buf,
                out,
                lse,
                mask_mode,
                TensorLayout[self._kv_layout].value,
                window_left,
                enable_pdl,
            ]
            if self._jit_module is not None:
                additional_args = prepare_jit_additional_args(
                    self._jit_additional_tensor_names,
                    {
                        "maybe_custom_mask": self._custom_mask_buf,
                        "maybe_mask_indptr": self._mask_indptr_buf,
                        "maybe_alibi_slopes": lambda: _get_cache_alibi_slopes_buf(
                            q.shape[1], q.device
                        ),
                        "maybe_prefix_len_ptr": self._prefix_len_ptr,
                        "maybe_token_pos_in_items_ptr": self._token_pos_in_items_ptr,
                        "maybe_max_item_len_ptr": self._max_item_len_ptr,
                        "maybe_k_cache_sf": key_block_scales,
                        "maybe_v_cache_sf": value_block_scales,
                    },
                    args,
                )
                expected_additional_arg_count = len(
                    self._jit_additional_tensor_names
                ) + len(self._jit_additional_scalar_names)
                if len(additional_args) < expected_additional_arg_count:
                    _, scale_q_scalar = _split_scale_param(q_scale)
                    _, scale_k_scalar = _split_scale_param(k_scale)
                    _, scale_v_scalar = _split_scale_param(v_scale)
                    jit_scalar_values = {
                        "logits_soft_cap": logits_soft_cap,
                        "sm_scale": sm_scale,
                        "rope_rcp_scale": 1.0 / rope_scale,
                        "rope_rcp_theta": 1.0 / rope_theta,
                        "scale_q_scalar": scale_q_scalar,
                        "scale_k_scalar": scale_k_scalar,
                        "scale_v_scalar": scale_v_scalar,
                        "token_pos_in_items_len": self._token_pos_in_items_len,
                    }
                    # prepare_jit_additional_args returns one entry per declared
                    # tensor name plus any scalars the caller passed
                    # positionally, so the number of scalars already provided is
                    # exactly the excess over the tensor-name count.
                    num_scalars_provided = len(additional_args) - len(
                        self._jit_additional_tensor_names
                    )
                    for name in self._jit_additional_scalar_names[
                        num_scalars_provided:
                    ]:
                        if name not in jit_scalar_values:
                            raise ValueError(
                                f"JIT module declares additional scalar {name!r}, "
                                "which was not passed positionally to run() and "
                                "cannot be derived automatically; derivable "
                                f"scalars are: {sorted(jit_scalar_values)}"
                            )
                        additional_args.append(jit_scalar_values[name])
                run_args.extend(additional_args)
            else:
                # Extract FP8 scale tensors from *args if q is FP8
                fp8_scale_q = None
                fp8_scale_k = None
                fp8_scale_v = None
                if is_float8(q) and len(args) >= 3:
                    fp8_scale_q = args[0]
                    fp8_scale_k = args[1]
                    fp8_scale_v = args[2]
                run_args += [
                    self._custom_mask_buf,
                    self._mask_indptr_buf,
                    _get_cache_alibi_slopes_buf(q.shape[1], q.device),
                    self._prefix_len_ptr,
                    self._token_pos_in_items_ptr,
                    self._max_item_len_ptr,
                    logits_soft_cap,
                    sm_scale,
                    fp8_scale_q,
                    fp8_scale_k,
                    fp8_scale_v,
                    rope_scale,
                    rope_theta,
                    self._token_pos_in_items_len,
                    self._workspace_size,
                    self._num_qo_heads,
                    self._num_kv_heads,
                    self._block_tables,
                    self._kv_lens_buffer,
                    page_size,
                    self._max_q_len,
                    self._max_kv_len,
                    self._batch_size,
                    self._qo_indptr_buf,
                    self._paged_kv_indptr_buf,
                    sinks,
                    key_block_scales,
                    value_block_scales,
                    skip_softmax_threshold_scale_factor,
                    True,  # uses_shared_paged_kv_idx
                    use_fp16_softmax,
                    uses_spcompress,
                    self._trtllm_gen_multi_ctas_kv_counter_buffer,
                ]

            if self._backend == "trtllm-gen":
                assert self._trtllm_gen_multi_ctas_kv_counter_buffer is not None
            assert self._cached_module is not None, "cached module is not initialized"
            self._cached_module.paged_run(*run_args)

            is_float_one = isinstance(v_scale, float) and v_scale == 1.0
            if v_scale is not None and not is_float_one:
                # TODO(Zihao): fused into kernel
                if is_float8(out):
                    out = (out.to(torch.float32) * v_scale).to(out.dtype)
                else:
                    out *= v_scale

        if return_lse:
            # cuDNN already produced the requested base
            lse = _finish_lse(
                lse,
                "log2" if self._backend == "cudnn" else lse_base,
                lse_layout,
                lse_out,
            )
        return (out, lse) if return_lse else out

    run_return_lse = functools.partialmethod(run, return_lse=True)

    def forward_return_lse(
        self,
        q: torch.Tensor,
        paged_kv_cache: Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]],
        causal: bool = False,
        pos_encoding_mode: str = "NONE",
        use_fp16_qk_reduction: bool = False,
        k_scale: Optional[float] = None,
        v_scale: Optional[float] = None,
        window_left: int = -1,
        logits_soft_cap: Optional[float] = None,
        sm_scale: Optional[float] = None,
        rope_scale: Optional[float] = None,
        rope_theta: Optional[float] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        r"""Warning: This function is deprecated, please use :meth:`run_return_lse` instead."""
        self._causal = causal
        self._pos_encoding_mode = pos_encoding_mode
        self._use_fp16_qk_reduction = use_fp16_qk_reduction
        self._window_left = window_left
        self._logits_soft_cap = logits_soft_cap
        self._sm_scale = sm_scale
        self._rope_scale = rope_scale
        self._rope_theta = rope_theta
        return self.run_return_lse(q, paged_kv_cache, k_scale=k_scale, v_scale=v_scale)


def _compute_mask_indptr(
    qo_indptr: torch.Tensor, kv_indptr: torch.Tensor
) -> torch.Tensor:
    if len(qo_indptr) != len(kv_indptr):
        raise ValueError("The length of qo_indptr and kv_indptr should be the same.")
    mask_indptr = torch.empty_like(qo_indptr)
    mask_indptr[0] = 0
    mask_indptr[1:] = torch.cumsum(
        (qo_indptr[1:] - qo_indptr[:-1]) * (kv_indptr[1:] - kv_indptr[:-1]),
        0,
    )
    return mask_indptr


class BatchPrefillWithRaggedKVCacheWrapper:
    r"""Wrapper class for prefill/append attention with ragged (tensor) kv-cache for
    batch of requests.

    Check :ref:`our tutorial <kv-layout>` for ragged kv-cache layout.

    Example
    -------
    >>> import torch
    >>> import flashinfer
    >>> num_layers = 32
    >>> num_qo_heads = 64
    >>> num_kv_heads = 16
    >>> head_dim = 128
    >>> # allocate 128MB workspace buffer
    >>> workspace_buffer = torch.empty(128 * 1024 * 1024, dtype=torch.uint8, device="cuda:0")
    >>> prefill_wrapper = flashinfer.BatchPrefillWithRaggedKVCacheWrapper(
    ...     workspace_buffer, "NHD"
    ... )
    >>> batch_size = 7
    >>> nnz_kv = 100
    >>> nnz_qo = 100
    >>> qo_indptr = torch.tensor(
    ...     [0, 33, 44, 55, 66, 77, 88, nnz_qo], dtype=torch.int32, device="cuda:0"
    ... )
    >>> kv_indptr = qo_indptr.clone()
    >>> q_at_layer = torch.randn(num_layers, nnz_qo, num_qo_heads, head_dim).half().to("cuda:0")
    >>> k_at_layer = torch.randn(num_layers, nnz_kv, num_kv_heads, head_dim).half().to("cuda:0")
    >>> v_at_layer = torch.randn(num_layers, nnz_kv, num_kv_heads, head_dim).half().to("cuda:0")
    >>> # create auxiliary data structures for batch prefill attention
    >>> prefill_wrapper.plan(
    ...     qo_indptr,
    ...     kv_indptr,
    ...     num_qo_heads,
    ...     num_kv_heads,
    ...     head_dim,
    ...     causal=True,
    ... )
    >>> outputs = []
    >>> for i in range(num_layers):
    ...     q = q_at_layer[i]
    ...     k = k_at_layer[i]
    ...     v = v_at_layer[i]
    ...     # compute batch prefill attention, reuse auxiliary data structures
    ...     o = prefill_wrapper.run(q, k, v)
    ...     outputs.append(o)
    ...
    >>> outputs[0].shape
    torch.Size([100, 64, 128])
    >>>
    >>> # below is another example of creating custom mask for batch prefill attention
    >>> mask_arr = []
    >>> qo_len = (qo_indptr[1:] - qo_indptr[:-1]).cpu().tolist()
    >>> kv_len = (kv_indptr[1:] - kv_indptr[:-1]).cpu().tolist()
    >>> for i in range(batch_size):
    ...     mask_i = torch.tril(
    ...         torch.full((qo_len[i], kv_len[i]), True, device="cuda:0"),
    ...         diagonal=(kv_len[i] - qo_len[i]),
    ...     )
    ...     mask_arr.append(mask_i.flatten())
    ...
    >>> mask = torch.cat(mask_arr, dim=0)
    >>> prefill_wrapper.plan(
    ...     qo_indptr,
    ...     kv_indptr,
    ...     num_qo_heads,
    ...     num_kv_heads,
    ...     head_dim,
    ...     custom_mask=mask
    ... )
    >>> outputs_custom_mask = []
    >>> for i in range(num_layers):
    ...     q = q_at_layer[i]
    ...     k = k_at_layer[i]
    ...     v = v_at_layer[i]
    ...     # compute batch prefill attention, reuse auxiliary data structures
    ...     o_custom = prefill_wrapper.run(q, k, v)
    ...     assert torch.allclose(o_custom, outputs[i], rtol=1e-3, atol=1e-3)
    ...
    >>> outputs_custom_mask[0].shape
    torch.Size([100, 64, 128])


    Note
    ----
    To accelerate computation, FlashInfer's batch prefill/append attention operators
    create some auxiliary data structures, these data structures can be reused across
    multiple prefill/append attention calls (e.g. different Transformer layers). This
    wrapper class manages the lifecycle of these data structures.
    """

    @flashinfer_api
    def __init__(
        self,
        float_workspace_buffer: torch.Tensor,
        kv_layout: str = "NHD",
        use_cuda_graph: bool = False,
        qo_indptr_buf: Optional[torch.Tensor] = None,
        kv_indptr_buf: Optional[torch.Tensor] = None,
        custom_mask_buf: Optional[torch.Tensor] = None,
        mask_indptr_buf: Optional[torch.Tensor] = None,
        backend: str = "auto",
        jit_args: Optional[List[Any]] = None,
        jit_kwargs: Optional[Dict[str, Any]] = None,
        variant_owns_mask: bool = False,
    ) -> None:
        r"""Constructor of :class:`BatchPrefillWithRaggedKVCacheWrapper`.

        Parameters
        ----------
        float_workspace_buffer : torch.Tensor
            The user reserved float workspace buffer used to store intermediate attention results
            in the split-k algorithm. The recommended size is 128MB, the device of the workspace
            buffer should be the same as the device of the input tensors. The buffer must be
            16-byte aligned; tensors created by ``torch.empty`` satisfy this on supported devices.

        kv_layout : str
            The layout of the input k/v tensors, could be either ``NHD`` or ``HND``.

        use_cuda_graph : bool
            Whether to enable CUDA graph capture for the prefill kernels, if enabled, the
            auxiliary data structures will be stored as the provided buffers.

        qo_indptr_buf : Optional[torch.Tensor]
            The user reserved GPU buffer to store the ``qo_indptr`` array, the size of the buffer
            should be ``[batch_size + 1]``.
            This argument is only effective when ``use_cuda_graph`` is ``True``.

        kv_indptr_buf : Optional[torch.Tensor]
            The user reserved GPU buffer to store the ``kv_indptr`` array, the size of the buffer
            should be ``[batch_size + 1]``.
            This argument is only effective when ``use_cuda_graph`` is ``True``.

        custom_mask_buf : Optional[torch.Tensor]
            The user reserved GPU buffer to store the custom mask tensor, should be large
            enough to store the maximum possible size of the packed custom mask tensor during the
            lifetime of the wrapper. This argument is only effective when ``use_cuda_graph``
            is ``True`` and custom mask will be used in attention computation.

        mask_indptr_buf : Optional[torch.Tensor]
            The user reserved GPU buffer to store the ``mask_indptr`` array, the size of the buffer
            should be ``[batch_size]``.
            This argument is only effective when ``use_cuda_graph`` is ``True`` and custom mask
            will be used in attention computation.

        backend : str
            The implementation backend, could be ``auto``/``fa2``/``fa3``/``cudnn``/``cutlass``
            or ``cute-dsl``/``cute-dsl-prims``/``cutile``.
            Defaults to ``auto``.
            If set to ``auto``, the wrapper will automatically choose the backend based on the
            device architecture and kernel availability: ``fa3`` on Hopper where it applies,
            ``fmha_v2`` for large-sequence MHA on SM120, and on SM100a ``cudnn`` (when the
            installed cuDNN can consume token-unit indptrs directly, see
            :func:`~flashinfer.cudnn.prefill._cudnn_supports_direct_seqlens`) or else
            ``cutlass`` on SM100a/SM110a, for the head dims those kernels serve, when no
            sliding window, logits soft cap, custom mask or multi-item-scoring pointer is in
            play -- neither path accepts those, so ``auto`` stays on ``fa2`` for them.
            Otherwise ``fa2``.
            The ``cudnn`` backend takes ``qo_indptr``/``kv_indptr`` in the same **token**
            units as every other backend, whether selected explicitly or via ``auto``.
            The ``cute-dsl`` backend uses the CuTe DSL attention kernel for Blackwell (SM100+).
            ``cute-dsl-prims`` is an explicit SM120-only packed FP8 prefill backend.
            The ``cutile`` backend uses the pure cuda.tile Python prefill kernel (Blackwell,
            opt-in); it requires ``qo_indptr == kv_indptr`` (equal-length prefill).

        jit_args : Optional[List[Any]]
            If provided, the wrapper will use the provided arguments to create the JIT module,
            otherwise, the wrapper will use default attention implementation.

        jit_kwargs : Optional[Dict[str, Any]]
            The keyword arguments to create the JIT module, defaults to None.

        variant_owns_mask : bool
            If ``True``, the attention variant supplied through ``jit_args`` computes the
            complete attention mask in its ``LogitsMask`` hook, and :attr:`MaskMode.CUSTOM`
            is selected without a mask tensor: the kernel evaluates ``LogitsMask`` on every
            KV tile instead of only on the causal/window boundary tiles, and no
            ``custom_mask``/``packed_custom_mask`` needs to be passed to :meth:`plan`.
            Requires ``jit_args``, because the default attention variant dereferences the
            custom mask buffer under :attr:`MaskMode.CUSTOM`. Only supported with
            ``backend="fa2"`` (the SM90 batch prefill kernels reject
            :attr:`MaskMode.CUSTOM`), and incompatible with ``prefix_len_ptr``
            (multi-item scoring), which selects a different mask mode.
            Defaults to ``False``.
        """
        _check_kv_layout(kv_layout)
        if variant_owns_mask and backend != "fa2":
            raise ValueError(
                "variant_owns_mask is only supported on the fa2 backend: the "
                "SM90 (fa3) batch prefill kernels return cudaErrorNotSupported "
                "under MaskMode.CUSTOM."
            )
        if (
            jit_args is not None
            and backend != "cute-dsl"
            and backend != "cute-dsl-prims"
        ):
            if jit_kwargs is None:
                jit_kwargs = {}
            self._jit_module = get_batch_prefill_jit_module(
                jit_args[0],
                get_customize_batch_prefill_module(backend, *jit_args, **jit_kwargs),
            )
            # jit_args[7] is additional_tensor_names from gen_customize_batch_prefill_module
            self._jit_additional_tensor_names = list(jit_args[7])
        else:
            self._jit_module = None
            self._jit_additional_tensor_names = []

        if variant_owns_mask and self._jit_module is None:
            raise ValueError(
                "variant_owns_mask requires a custom JIT module (jit_args): the "
                "default attention variant dereferences the custom mask buffer "
                "under MaskMode.CUSTOM."
            )
        self._variant_owns_mask = variant_owns_mask

        self._cute_dsl_wrapper = None
        self._prims_backend = None
        if backend == "cute-dsl":
            from .cute_dsl.attention import BatchPrefillCuteDSLWrapper

            self._cute_dsl_wrapper = BatchPrefillCuteDSLWrapper(
                float_workspace_buffer, use_cuda_graph=use_cuda_graph
            )
        elif backend == "cute-dsl-prims":
            try:
                from .attention.cute_dsl.sm120_fmha import (
                    SM120PrimsBatchPrefillBackend,
                )
            except ImportError as exc:
                raise ImportError(
                    "backend='cute-dsl-prims' requires the SM120 CuTe DSL stack "
                    "providing cutlass.experimental"
                ) from exc
            self._prims_backend = SM120PrimsBatchPrefillBackend(
                float_workspace_buffer.device
            )

        self._kv_layout = kv_layout
        self._float_workspace_buffer = float_workspace_buffer
        self.device = float_workspace_buffer.device
        self._int_workspace_buffer = torch.empty(
            (8 * 1024 * 1024,), dtype=torch.uint8, device=self.device
        )
        self._pin_memory_int_workspace_buffer = torch.empty(
            self._int_workspace_buffer.shape,
            dtype=torch.uint8,
            pin_memory=True,
            device="cpu",
        )
        self._use_cuda_graph = use_cuda_graph
        # Set once an explicit-CUTLASS plan exists: `fmha_varlen_plan` allocates
        # fresh work-index buffers per call, so in CUDA-graph mode the first
        # plan is safe (nothing captured yet) but a re-plan is not.
        self._cutlass_graph_planned = False
        if use_cuda_graph:
            if not torch.is_tensor(qo_indptr_buf):
                raise ValueError(
                    "qo_indptr_buf should be a torch.Tensor in cuda graph mode"
                )
            if not torch.is_tensor(kv_indptr_buf):
                raise ValueError(
                    "kv_indptr_buf should be a torch.Tensor in cuda graph mode"
                )
            self._fixed_batch_size = len(qo_indptr_buf) - 1
            if len(kv_indptr_buf) != self._fixed_batch_size + 1:
                raise ValueError(
                    "The length of kv_indptr_buf ({}) should be the same as qo_indptr_buf ({}).".format(
                        len(kv_indptr_buf), self._fixed_batch_size
                    )
                )
            # NOTE(Zihao): do not check custom_mask_buf and mask_indptr_buf here,
            # as they may not be used.

        self._qo_indptr_buf = qo_indptr_buf
        self._kv_indptr_buf = kv_indptr_buf
        self._custom_mask_buf = custom_mask_buf
        self._mask_indptr_buf = mask_indptr_buf
        self._max_total_num_rows: Optional[int] = None
        # `auto` is re-resolved on every plan() (its answer depends on plan
        # arguments such as window_left); _backend holds the resolved value.
        self._requested_backend = backend
        self._backend = backend
        self._cached_module = None
        # cudnn: stats ragged offset so the LSE lands packed as
        # [total_tokens, num_qo_heads]; token-unit, so it is qo_indptr itself.
        self._cudnn_stats_offsets: Optional[torch.Tensor] = None
        self._cudnn_prepared: Optional[CudnnPrefillGraph] = None
        self._cudnn_plan: Optional[_CudnnPrefillPlan] = None
        self._cudnn_cpu_indptr_buffers: list[Optional[torch.Tensor]] = [None, None]

    def _stage_cudnn_indptr(self, source, index, non_blocking):
        if source.device.type != "cpu":
            return source.to(self.device, non_blocking=non_blocking)
        buffer = self._cudnn_cpu_indptr_buffers[index]
        if (
            buffer is None
            or buffer.shape != source.shape
            or buffer.dtype != source.dtype
        ):
            buffer = torch.empty(source.shape, device=self.device, dtype=source.dtype)
            self._cudnn_cpu_indptr_buffers[index] = buffer
        buffer.copy_(source, non_blocking=non_blocking)
        return buffer

    @property
    def is_cuda_graph_enabled(self) -> bool:
        return self._use_cuda_graph

    def reset_workspace_buffer(
        self, float_workspace_buffer: torch.Tensor, int_workspace_buffer
    ) -> None:
        r"""Reset the workspace buffer.

        Parameters
        ----------
        float_workspace_buffer : torch.Tensor
            The new float workspace buffer, the device of the new float workspace buffer should
            be the same as the device of the input tensors.

        int_workspace_buffer : torch.Tensor
            The new int workspace buffer, the device of the new int workspace buffer should
            be the same as the device of the input tensors.
        """
        self._float_workspace_buffer = float_workspace_buffer
        self._cudnn_prepared = None
        self._int_workspace_buffer = int_workspace_buffer
        self._pin_memory_int_workspace_buffer = torch.empty(
            self._int_workspace_buffer.shape,
            dtype=self._int_workspace_buffer.dtype,
            device="cpu",
            pin_memory=True,
        )

    @flashinfer_api
    def plan(
        self,
        qo_indptr: torch.Tensor,
        kv_indptr: torch.Tensor,
        num_qo_heads: int,
        num_kv_heads: int,
        head_dim_qk: int,
        head_dim_vo: Optional[int] = None,
        custom_mask: Optional[torch.Tensor] = None,
        packed_custom_mask: Optional[torch.Tensor] = None,
        causal: bool = False,
        pos_encoding_mode: str = "NONE",
        use_fp16_qk_reduction: bool = False,
        window_left: int = -1,
        logits_soft_cap: Optional[float] = None,
        sm_scale: Optional[float] = None,
        rope_scale: Optional[float] = None,
        rope_theta: Optional[float] = None,
        q_data_type: Union[str, torch.dtype] = "float16",
        kv_data_type: Optional[Union[str, torch.dtype]] = None,
        o_data_type: Optional[Union[str, torch.dtype]] = None,
        non_blocking: bool = True,
        prefix_len_ptr: Optional[torch.Tensor] = None,
        token_pos_in_items_ptr: Optional[torch.Tensor] = None,
        token_pos_in_items_len: int = 0,
        max_item_len_ptr: Optional[torch.Tensor] = None,
        fixed_split_size: Optional[int] = None,
        disable_split_kv: bool = False,
        seq_lens: Optional[torch.Tensor] = None,
        seq_lens_q: Optional[torch.Tensor] = None,
        max_token_per_sequence: Optional[int] = None,
        max_sequence_kv: Optional[int] = None,
        v_indptr: Optional[torch.Tensor] = None,
        o_indptr: Optional[torch.Tensor] = None,
        uniform_q_len: Optional[int] = None,
    ) -> None:
        r"""Plan batch prefill/append attention on Ragged KV-Cache for given problem specification.

        Parameters
        ----------
        qo_indptr : torch.Tensor
            The indptr of the query/output tensor, shape: ``[batch_size + 1]``.
            Token units for every backend, including ``cudnn`` (it previously took
            element-unit offsets; that contract has been normalized). The ``cudnn``
            backend also requires ``kv_layout="NHD"``.
        kv_indptr : torch.Tensor
            The indptr of the key/value tensor, shape: ``[batch_size + 1]``.
        num_qo_heads : int
            The number of query/output heads.
        num_kv_heads : int
            The number of key/value heads.
        head_dim_qk : int
            The dimension of the heads on query/key tensor.
        head_dim_vo : Optional[int]
            The dimension of the heads on value/output tensor.
            If not provided, will be set to ``head_dim_qk``.
        custom_mask : Optional[torch.Tensor]
            The flattened boolean mask tensor, shape: ``(sum(q_len[i] * k_len[i] for i in range(batch_size))``.
            The elements in the mask tensor should be either ``True`` or ``False``,
            where ``False`` means the corresponding element in the attention matrix will be
            masked out.

            Please refer to the :ref:`mask layout <mask-layout>` for more details about flattened
            layout of mask tensor.

            When :attr:`custom_mask` is provided, and :attr:`packed_custom_mask` is not, the
            function will pack the custom mask tensor into a 1D packed mask tensor, which introduces
            additional overhead.
        packed_custom_mask : Optional[torch.Tensor]
            The 1D packed uint8 mask tensor, if provided, the :attr:`custom_mask` will be ignored.
            The packed mask tensor is generated by :func:`flashinfer.quantization.packbits`.

            If provided, the custom mask will be added to the attention matrix before softmax
            and after scaling. The mask tensor should be in the same device as the input tensors.
        causal : bool
            Whether to apply causal mask to the attention matrix.
            This argument is ignored if ``mask`` is provided in :meth:`plan`.
        pos_encoding_mode : str
            The position encoding applied inside attention kernels, could be
            ``NONE``/``ROPE_LLAMA`` (LLAMA style rotary embedding) /``ALIBI``.
            Default is ``NONE``.
        use_fp16_qk_reduction : bool
            Whether to use f16 for qk reduction (faster at the cost of slight precision
            loss).
        window_left : int
            The left (inclusive) window size for the attention window, when set to ``-1``, the window
            size will be set to the full length of the sequence. Defaults to ``-1``.
        logits_soft_cap : Optional[float]
            The attention logits soft capping value (used in Gemini, Grok and Gemma-2, etc.), if not
            provided, will be set to ``0``. If greater than 0, the logits will be capped according to
            formula:
            :math:`\texttt{logits_soft_cap} \times \mathrm{tanh}(x / \texttt{logits_soft_cap})`,
            where :math:`x` is the input logits.
        sm_scale : Optional[float]
            The scale used in softmax, if not provided, will be set to
            ``1.0 / sqrt(head_dim_qk)``.
        rope_scale : Optional[float]
            The scale used in RoPE interpolation, if not provided, will be set to
            ``1.0``.
        rope_theta : Optional[float]
            The theta used in RoPE, if not provided, will be set to ``1e4``.
        q_data_type : Union[str, torch.dtype]
            The data type of the query tensor, defaults to torch.float16.
        kv_data_type : Optional[Union[str, torch.dtype]]
            The data type of the key/value tensor. If None, will be set to :attr:`q_data_type`.
        o_data_type : Optional[Union[str, torch.dtype]]
            The data type of the output tensor. If None, will be set to :attr:`q_data_type`.
            For FP8 inputs, this should typically be set to torch.float16 or torch.bfloat16.
        non_blocking : bool
            Whether to copy the input tensors to the device asynchronously, defaults to ``True``.
        prefix_len_ptr :Optional[torch.Tensor]
            prefix length. A uint32 1D tensor indicating the prefix length of each prompt. The tensor size is equal to the batch size.
        token_pos_in_items_ptr : Optional[torch.Tensor]
            A uint16 1D tensor (it will be converted to uint16 in flashinfer) indicating the token position of each item and started from 0 (delimiter)
            for each item. E.g., if we have 3 items of length 3, 2, 4 respectively for this member. This vector will be looking like
            `[0, 1, 2, 3, 0, 1, 2, 0, 1, 2, 3, 4, 0]` with 4 delimiters indexed as 0. For batch size > 1,
            we will concat them as 1D with zero paddings to make sure each has the same length, the padding length is defined by
            `token_pos_in_items_len` - length of the raw `token_pos_in_items_ptr` for each prompt.
        token_pos_in_items_len : int
            zero padding length for `token_pos_in_items_ptr` to better handle the bsz > 1 case. Still using the above 3,2,4 example.
            If we set `token_pos_in_items_len` to be 20, it will be  `[0, 1, 2, 3, 0, 1, 2, 0, 1, 2, 3, 4, 0, 0, 0, 0, 0, 0, 0, 0]`
            with 7 padded zeros. (note there're 8 zeros in the end where the first one is the delimiter token 0 in the end of the prompt)
        max_item_len_ptr : Optional[torch.Tensor]
            a uint16 vector contains the max token length of all items for each prompt
        fixed_split_size : Optional[int],
            The fixed split size for split-kv FA2 prefill/decode, in pages. Recommend setting to the average sequence length of your workload.
            When enabled, will lead to deterministic softmax score reduction in the merge_states kernel, and therefore
            batch-size invariant outputs. See https://thinkingmachines.ai/blog/defeating-nondeterminism-in-llm-inference/
            Note that compatibility with CUDA graph is NOT guaranteed, as even when bs is fixed, kv seq len can change
            and lead to a varied number of launched CTAs.
        disable_split_kv : bool,
            Whether to disable the split-kv for determinism in CUDA Graph, defaults to ``False``.
        seq_lens: Optional[torch.Tensor]
            Only used by the cudnn backend. A 1D int32 tensor with the kv sequence length
            of each prompt, shape: ``[batch_size]``. Optional: cuDNN derives it from ``kv_indptr``.
        seq_lens_q: Optional[torch.Tensor]
            Only used by the cudnn backend. A 1D int32 tensor with the q sequence length
            of each prompt, shape: ``[batch_size]``. Optional: cuDNN derives it from ``qo_indptr``.
        max_token_per_sequence: Optional[int],
            Only used by the cudnn backend. The max q length of any sequence; defaults to
            ``max(qo_indptr[1:] - qo_indptr[:-1])``.
        max_sequence_kv: Optional[int],
            Only used by the cudnn backend. The max kv length of any sequence; defaults to
            ``max(kv_indptr[1:] - kv_indptr[:-1])``.
        v_indptr: Optional[torch.Tensor]
            Only used by the cudnn backend. Token-unit indptr of the value tensor;
            defaults to ``kv_indptr``.
        o_indptr: Optional[torch.Tensor]
            Only used by the cudnn backend. Token-unit indptr of the output tensor;
            defaults to ``qo_indptr``.
        uniform_q_len : Optional[int]
            Number of query rows of every request in the batch, when the caller can
            guarantee it for every plan replayed through this wrapper. Only the ``fa2``
            backend in CUDA-graph mode uses it (query tile sized for
            ``uniform_q_len * gqa_group_size`` packed rows instead of the ragged worst
            case); see :meth:`BatchPrefillWithPagedKVCacheWrapper.plan`. Checked against
            ``qo_indptr`` on the host and dropped when the batch is not uniform.
            Defaults to ``None``.
        Note
        ----
        The :meth:`plan` method should be called before any :meth:`run` or
        :meth:`run_return_lse` calls, auxiliary data structures will be created
        during this plan call and cached for multiple kernel runs.

        The ``num_qo_heads`` must be a multiple of ``num_kv_heads``. If ``num_qo_heads``
        is not equal to ``num_kv_heads``, the function will use
        `grouped query attention <https://arxiv.org/abs/2305.13245>`_.

        The :meth:`plan` method cannot be used in Cuda Graph or in ``torch.compile``.
        """
        q_data_type = canonicalize_torch_dtype(q_data_type)
        if kv_data_type is None:
            kv_data_type = q_data_type
        kv_data_type = canonicalize_torch_dtype(kv_data_type)
        if o_data_type is None:
            o_data_type = q_data_type
        o_data_type = canonicalize_torch_dtype(o_data_type)
        if head_dim_vo is None:
            head_dim_vo = head_dim_qk
        if fixed_split_size is None:
            fixed_split_size = -1
        if logits_soft_cap is None:
            logits_soft_cap = 0.0

        batch_size = len(qo_indptr) - 1
        if len(kv_indptr) != batch_size + 1:
            raise ValueError(
                "The kv_indptr length should be equal to mask_indptr length."
            )
        if custom_mask is not None or packed_custom_mask is not None:
            mask_indptr = _compute_mask_indptr(qo_indptr, kv_indptr)
        if packed_custom_mask is None and custom_mask is not None:
            # create packed custom mask from custom mask
            # segment_packbits requires mask_indptr on the same device as
            # custom_mask, but mask_indptr inherits qo_indptr's device (often
            # CPU) while custom_mask is on GPU. Mirror the paged path's
            # .to(device) so the ragged custom-mask flow doesn't crash.
            packed_custom_mask, mask_indptr = segment_packbits(
                custom_mask.contiguous().view(-1),
                mask_indptr.to(custom_mask.device),
                bitorder="little",
            )

        if (
            self.is_cuda_graph_enabled
            and self._requested_backend == "cutlass"
            and self._cutlass_graph_planned
        ):
            # Reject before updating cached plan state or registered buffers
            # so the original plan remains usable after a refused re-plan.
            raise ValueError(
                "the cutlass backend allocates fresh plan buffers on every "
                "plan() call, so re-planning in CUDA-graph mode would leave "
                "a captured graph pointing at the previous ones; plan once "
                "before capture, or use backend='auto' or an explicit "
                "'cudnn'/'fa2' if you need to re-plan"
            )

        # NOTE(Zihao): only required if qo_indptr/paged_kv_indptr are device tensors
        qo_indptr_host = qo_indptr.to("cpu")
        kv_indptr_host = kv_indptr.to("cpu")

        self._qo_indptr_last = int(qo_indptr_host[-1])
        total_num_rows = self._qo_indptr_last

        if self.is_cuda_graph_enabled:
            if self._max_total_num_rows is None:
                self._max_total_num_rows = total_num_rows
            elif total_num_rows > self._max_total_num_rows:
                raise ValueError(
                    "The total number of rows in qo_indptr {} in cuda graph mode cannot "
                    "exceed the number of rows set during initialization {}.".format(
                        total_num_rows, self._max_total_num_rows
                    )
                )

            if batch_size != self._fixed_batch_size:
                raise ValueError(
                    "The batch size should be fixed in cudagraph mode, the runtime batch size {} "
                    " mismatches the batch size set during initialization {}.".format(
                        batch_size, self._fixed_batch_size
                    )
                )
            self._qo_indptr_buf.copy_(qo_indptr, non_blocking=non_blocking)
            self._kv_indptr_buf.copy_(kv_indptr, non_blocking=non_blocking)
            if packed_custom_mask is not None:
                if not torch.is_tensor(self._custom_mask_buf):
                    raise ValueError(
                        "custom_mask_buf must be initialized with a torch.Tensor in cuda graph mode if we use custom mask in attention computation."
                    )
                if not torch.is_tensor(self._mask_indptr_buf):
                    raise ValueError(
                        "mask_indptr_buf must be initialized with a torch.Tensor in cuda graph mode if we use custom mask in the attention computation."
                    )
                self._custom_mask_buf[: len(packed_custom_mask)] = packed_custom_mask
                self._mask_indptr_buf.copy_(mask_indptr, non_blocking=non_blocking)
        else:
            if self._backend == "cudnn":
                # CPU metadata needs a device mirror, not a new allocation on
                # every replan. Never overwrite a caller-owned CUDA tensor.
                self._qo_indptr_buf = self._stage_cudnn_indptr(
                    qo_indptr, 0, non_blocking
                )
                self._kv_indptr_buf = self._stage_cudnn_indptr(
                    kv_indptr, 1, non_blocking
                )
            else:
                self._qo_indptr_buf = qo_indptr.to(
                    self.device, non_blocking=non_blocking
                )
                self._kv_indptr_buf = kv_indptr.to(
                    self.device, non_blocking=non_blocking
                )
            if packed_custom_mask is not None:
                self._custom_mask_buf = packed_custom_mask.to(
                    self.device, non_blocking=non_blocking
                )
                self._mask_indptr_buf = mask_indptr.to(
                    self.device, non_blocking=non_blocking
                )

        self._o_indptr_buf = (
            o_indptr.to(self.device, non_blocking=non_blocking)
            if o_indptr is not None
            else self._qo_indptr_buf
        )
        self._v_indptr_buf = (
            v_indptr.to(self.device, non_blocking=non_blocking)
            if v_indptr is not None
            else self._kv_indptr_buf
        )

        self._cached_q_data_type = q_data_type
        self._cached_kv_data_type = kv_data_type
        self._cached_o_data_type = o_data_type
        kv_len_arr = kv_indptr_host[1:] - kv_indptr_host[:-1]

        if prefix_len_ptr is not None and self._variant_owns_mask:
            raise ValueError(
                "prefix_len_ptr (multi-item scoring) selects "
                "MaskMode.MULTIITEMSCORING, which overrides the MaskMode.CUSTOM "
                "required by variant_owns_mask; the two are incompatible."
            )
        self._prefix_len_ptr = prefix_len_ptr
        self._token_pos_in_items_ptr = token_pos_in_items_ptr
        self._token_pos_in_items_len = token_pos_in_items_len
        self._max_item_len_ptr = max_item_len_ptr

        self._seq_lens_q = seq_lens_q
        self._seq_lens_kv = seq_lens
        self._max_token_per_sequence = max_token_per_sequence
        self._max_sequence_kv = max_sequence_kv

        # Precompute sequence length maxima (used by fmha_v2 and other backends)
        max_seq_in_batch = int(kv_len_arr.max().item())
        max_qo_len = int((qo_indptr_host[1:] - qo_indptr_host[:-1]).max().item())

        if self._backend == "cute-dsl-prims":
            from .attention.cute_dsl.sm120_fmha import (
                _validate_sm120_prims_plan_options,
            )

            _validate_sm120_prims_plan_options(
                kv_layout=self._kv_layout,
                required_kv_layout="NHD",
                custom_mask=custom_mask,
                packed_custom_mask=packed_custom_mask,
                pos_encoding_mode=pos_encoding_mode,
                use_fp16_qk_reduction=use_fp16_qk_reduction,
                window_left=window_left,
                logits_soft_cap=logits_soft_cap,
                prefix_len_ptr=prefix_len_ptr,
                token_pos_in_items_ptr=token_pos_in_items_ptr,
                max_item_len_ptr=max_item_len_ptr,
                max_sequence_kv=max_sequence_kv,
                fixed_split_size=fixed_split_size,
            )
            assert self._prims_backend is not None
            self._prims_backend.plan_ragged(
                qo_indptr=self._qo_indptr_buf,
                kv_indptr=self._kv_indptr_buf,
                qo_indptr_host=qo_indptr_host,
                kv_indptr_host=kv_indptr_host,
                q_dtype=q_data_type,
                kv_dtype=kv_data_type,
                o_dtype=o_data_type,
                num_qo_heads=num_qo_heads,
                num_kv_heads=num_kv_heads,
                head_dim_qk=head_dim_qk,
                head_dim_vo=head_dim_vo,
                causal=causal,
                sm_scale=sm_scale,
            )
        elif self._backend == "cute-dsl":
            if custom_mask is not None or packed_custom_mask is not None:
                raise NotImplementedError(
                    "cute-dsl backend does not support custom_mask"
                )
            if head_dim_vo is not None and head_dim_vo != head_dim_qk:
                raise NotImplementedError(
                    "cute-dsl backend requires head_dim_vo == head_dim_qk"
                )
            if self._kv_layout == "HND":
                raise NotImplementedError("cute-dsl backend only supports NHD layout")
            if pos_encoding_mode not in ("NONE", "ALIBI"):
                raise NotImplementedError(
                    f"cute-dsl backend does not support pos_encoding_mode={pos_encoding_mode!r}. "
                    "For RoPE, apply rotary embeddings to Q/K before calling the kernel."
                )

            variant: Optional[Any] = None
            if pos_encoding_mode == "ALIBI":
                from .cute_dsl.attention import ALiBiAttention

                slopes = ALiBiAttention.get_slopes(num_qo_heads)
                variant = ALiBiAttention(
                    torch.tensor(slopes, dtype=torch.float32, device=self.device)
                )
            if logits_soft_cap is not None and logits_soft_cap > 0:
                from .cute_dsl.attention import SoftCappingAttention

                if variant is not None:
                    raise NotImplementedError(
                        "the public cute-dsl route cannot combine ALiBi with "
                        "logits_soft_cap (one plan-time variant per kernel); "
                        "a fused custom variant can express both — use "
                        "flashinfer.cute_dsl.attention."
                        "BatchPrefillCuteDSLWrapper with plan(..., variant=...)"
                    )
                variant = SoftCappingAttention(cap=logits_soft_cap)

            _sm_scale = (
                sm_scale if sm_scale is not None else 1.0 / math.sqrt(head_dim_qk)
            )
            # Variant-less head-128 dense/causal plans route to the trtllm
            # CuTe DSL FMHA kernel (prebuilt artifacts).  Sliding-window
            # plans use the modular cute-dsl path, which measures faster on
            # windows (banded masks skip dead work) for every V dtype —
            # mixed V (e.g. fp8 V with bf16 Q/K) forces the FMHA path onto
            # JIT compilation, where the modular kernel wins.
            self._cute_dsl_use_fmha = (
                variant is None and head_dim_qk == 128 and window_left < 0
            )
            if self._cute_dsl_use_fmha:
                # Wrapper-owned buffers (populated above): stable addresses
                # for CUDA-graph mode, single normalized copy otherwise.
                q_lens = self._qo_indptr_buf[1:] - self._qo_indptr_buf[:-1]
                k_lens = self._kv_indptr_buf[1:] - self._kv_indptr_buf[:-1]
                # Snapshot host-side seq-lens at plan time so run() can pass
                # them into trtllm_ragged_attention_deepseek without touching
                # the device during CUDA graph capture (see issue #4609).
                q_lens_cpu = q_lens.to(torch.int32).cpu()
                k_lens_cpu = k_lens.to(torch.int32).cpu()
                self._cute_dsl_fmha_plan = {
                    "qo_indptr": self._qo_indptr_buf,
                    "kv_indptr": self._kv_indptr_buf,
                    "seq_lens": k_lens.to(torch.int32),
                    "q_seq_lens_cpu": q_lens_cpu,
                    "kv_seq_lens_cpu": k_lens_cpu,
                    "batch_size": qo_indptr.shape[0] - 1,
                    "max_q_len": int(q_lens.max().item()),
                    "max_kv_len": int(k_lens.max().item()),
                    "sm_scale": _sm_scale,
                    "causal": causal,
                    "window_left": window_left,
                }
            else:
                # The modular kernel requires q and k to share one dtype
                # (kv_data_type covers both K and V; a V-only mismatch is a
                # run()-time property served natively).  Reject mismatched
                # plan dtypes here with a clear error — they would otherwise
                # surface as an opaque FFI signature mismatch at run().
                if kv_data_type is not None and q_data_type != kv_data_type:
                    raise ValueError(
                        "cute-dsl modular prefill requires q_data_type == "
                        f"kv_data_type, got {q_data_type} and {kv_data_type}"
                    )
                self._cute_dsl_wrapper.plan(
                    self._qo_indptr_buf,
                    self._kv_indptr_buf,
                    num_qo_heads,
                    num_kv_heads,
                    head_dim_qk,
                    head_dim_vo=head_dim_qk,
                    causal=causal,
                    sm_scale=_sm_scale,
                    q_data_type=q_data_type,
                    kv_data_type=kv_data_type
                    if kv_data_type is not None
                    else q_data_type,
                    window_left=window_left,
                    variant=variant,
                )
        elif self._backend == "cutile":
            # cuTile ragged prefill: no C++ module to build. Materialize the
            # per-request length/offset arrays the kernel needs from
            # qo_indptr/kv_indptr here (plan() may host-sync; run() must not).
            if custom_mask is not None or packed_custom_mask is not None:
                raise NotImplementedError(
                    "cuTile ragged prefill does not support custom_mask."
                )
            if pos_encoding_mode != "NONE":
                raise NotImplementedError(
                    "cuTile ragged prefill only supports pos_encoding_mode='NONE'. "
                    "Apply RoPE to Q/K before calling the kernel."
                )
            if logits_soft_cap is not None and logits_soft_cap > 0:
                raise NotImplementedError(
                    "cuTile ragged prefill does not support logits_soft_cap."
                )
            if window_left >= 0:
                raise NotImplementedError(
                    "cuTile ragged prefill does not support sliding window."
                )
            # The kernel slices Q and KV with a single shared per-request offset,
            # so it only supports qo_indptr == kv_indptr (equal-length prefill /
            # self-attention, no cached prefix). Append/chunked prefill with
            # kv_len != q_len must use another backend.
            if not torch.equal(qo_indptr_host, kv_indptr_host):
                raise NotImplementedError(
                    "cuTile ragged prefill requires qo_indptr == kv_indptr "
                    "(equal-length prefill). For append/chunked prefill with "
                    "kv_len != q_len, use backend='fa2'."
                )
            seq_lens_q_host = (qo_indptr_host[1:] - qo_indptr_host[:-1]).to(torch.int32)
            kv_len_arr_i32 = kv_len_arr.to(torch.int32)
            self._cutile_num_batch = batch_size
            self._cutile_seq_lens_q = seq_lens_q_host.to(
                self.device, non_blocking=non_blocking
            )
            self._cutile_seq_lens_kv = kv_len_arr_i32.to(
                self.device, non_blocking=non_blocking
            )
            # Shared exclusive-prefix-sum offset (== qo_indptr[:-1] == kv_indptr[:-1]).
            self._cutile_seq_offset = self._qo_indptr_buf[:-1].to(torch.int32)
            self._cutile_max_seq_len = (
                int(kv_len_arr_i32.max().item()) if batch_size > 0 else 0
            )
            # block_tables is accepted but unused by the ragged kernel.
            self._cutile_block_tables = torch.zeros(
                batch_size, 1, dtype=torch.int32, device=self.device
            )
        elif self._jit_module is not None:
            self._cached_module = self._jit_module
        else:
            if self._requested_backend == "auto":
                self._backend = determine_attention_backend(
                    self.device,
                    PosEncodingMode[pos_encoding_mode].value,
                    use_fp16_qk_reduction,
                    self._custom_mask_buf is not None,  # use_custom_mask
                    q_data_type,
                    kv_data_type,
                    head_dim_qk=head_dim_qk,
                    head_dim_vo=head_dim_vo,
                )
                # SM12x: use fmha_v2 HMMA kernels for large-sequence MHA.
                # fmha_v2 outperforms FA2 at longer sequences (S>=256) on SM120
                # due to optimized tiled flash attention, but has higher CTA
                # launch overhead for small sequences or high head counts.
                # Only supports: MHA, standard symmetric head dims, matching
                # q/kv dtype, no sliding window, no softcap, equal q/kv
                # segments, NHD layout. The kernel reduces QK in fp16 on bf16,
                # so only auto-select it when the caller allows fp16 QK
                # reduction (mirrors is_fa3_backend_supported's convention).
                same_qk_segments = torch.equal(qo_indptr_host, kv_indptr_host)
                is_standard_shape = head_dim_qk == head_dim_vo and head_dim_qk in (
                    64,
                    128,
                    256,
                )
                if (
                    self._backend == "fa2"
                    and self._kv_layout == "NHD"
                    and num_qo_heads == num_kv_heads
                    and same_qk_segments
                    and is_standard_shape
                    and q_data_type == kv_data_type
                    and use_fp16_qk_reduction
                    and max_seq_in_batch >= 256
                    and window_left < 0
                    and logits_soft_cap == 0.0
                    and prefix_len_ptr is None
                    and token_pos_in_items_ptr is None
                    and max_item_len_ptr is None
                    and _should_use_fmha_v2_sm120(
                        self.device,
                        PosEncodingMode[pos_encoding_mode].value,
                        self._custom_mask_buf is not None,
                        q_data_type,
                        kv_data_type,
                    )
                ):
                    self._backend = "fmha_v2"

                # Blackwell: determine_attention_backend only ever answers
                # fa3/fa2 and FA3 is Hopper-gated, so `auto` lands on FA2 here.
                # Walk the explicit preference list (cudnn, then cutlass) and
                # take the first backend whose kernel serves this problem
                # exactly; none eligible -> stay on FA2. Explicit backends are
                # never rewritten.
                elif self._backend == "fa2":
                    upgraded = _blackwell_ragged_auto_upgrade(
                        self.device,
                        self._kv_layout,
                        head_dim_qk,
                        head_dim_vo,
                        q_data_type,
                        kv_data_type,
                        o_data_type,
                        PosEncodingMode[pos_encoding_mode].value,
                        has_custom_mask=self._custom_mask_buf is not None,
                        window_left=window_left,
                        logits_soft_cap=logits_soft_cap,
                        has_multi_item_scoring=(
                            prefix_len_ptr is not None
                            or token_pos_in_items_ptr is not None
                            or max_item_len_ptr is not None
                        ),
                        has_sinks=getattr(self, "_sinks", None) is not None,
                        # Outside graph mode the cuDNN branch below converts a
                        # non-int32 indptr in place, so any dtype is fine; under
                        # capture it raises, and `auto` must route around that
                        # rather than pick a backend that cannot run.
                        cudnn_indptr_is_int32=(
                            not self.is_cuda_graph_enabled
                            or all(
                                buf.dtype == torch.int32
                                for buf in (
                                    self._qo_indptr_buf,
                                    self._kv_indptr_buf,
                                    self._o_indptr_buf,
                                    self._v_indptr_buf,
                                )
                            )
                        ),
                        cutlass_work_items=_cutlass_plan_work_items(
                            qo_indptr_host, num_qo_heads
                        ),
                        cuda_graph_enabled=self.is_cuda_graph_enabled,
                        cutlass_indptr_is_int32=(
                            self._qo_indptr_buf.dtype == torch.int32
                            and self._kv_indptr_buf.dtype == torch.int32
                        ),
                        single_token_gqa=(
                            max_qo_len == 1 and num_qo_heads != num_kv_heads
                        ),
                    )
                    if upgraded is not None:
                        self._backend = upgraded

            get_module_args = (
                q_data_type,
                kv_data_type,
                o_data_type,
                kv_indptr.dtype,
                head_dim_qk,
                head_dim_vo,
                PosEncodingMode[pos_encoding_mode].value,
                window_left >= 0,  # use_sliding_window
                logits_soft_cap > 0,  # use_logits_soft_cap
                use_fp16_qk_reduction,
            )
            if self._backend == "fmha_v2":
                # Cache plan data for run() — avoid GPU-CPU sync in hot path
                self._fmha_v2_seq_lens = kv_len_arr.to(torch.int32).to(
                    self.device, non_blocking=non_blocking
                )
                self._fmha_v2_batch_size = batch_size
                self._fmha_v2_max_q_len = max_qo_len
                self._fmha_v2_max_kv_len = max_seq_in_batch
                self._fmha_v2_qo_indptr = self._qo_indptr_buf.to(torch.int32)
                self._fmha_v2_kv_indptr = self._kv_indptr_buf.to(torch.int32)
            elif self._backend == "cutlass":
                # insert the wrapper's device at the 9th position (0-indexed) of
                # get_module_args. `self.device`, not `qo_indptr.device`: the
                # caller may pass a host indptr, and the module has to be built
                # for the device the kernel will run on.
                new_get_module_args = (
                    get_module_args[:9] + (self.device,) + get_module_args[9:]
                )
                self._cached_module = get_fmha_module(*new_get_module_args)
            elif self._backend != "cudnn":
                self._cached_module = get_batch_prefill_module(
                    self._backend, *get_module_args
                )

        if self._backend == "cudnn":
            if (
                pos_encoding_mode != "NONE"
                or window_left != -1
                or logits_soft_cap != 0
                or self._custom_mask_buf is not None
                or prefix_len_ptr is not None
            ):
                raise NotImplementedError(
                    "cuDNN ragged prefill supports only causal or full attention without "
                    "position encoding, window_left, logits_soft_cap or custom masks"
                )
            # The graph's padded dims default to the indptr diffs computed
            # above, and cuDNN reads cu_seq_lens as int32. Done once here so
            # run() launches no conversion kernel.
            if self._max_token_per_sequence is None:
                self._max_token_per_sequence = max_qo_len
            if self._max_sequence_kv is None:
                self._max_sequence_kv = max_seq_in_batch
            indptr_bufs = (
                self._qo_indptr_buf,
                self._kv_indptr_buf,
                self._o_indptr_buf,
                self._v_indptr_buf,
            )
            if any(buf.dtype != torch.int32 for buf in indptr_bufs):
                if self.is_cuda_graph_enabled:
                    raise ValueError(
                        "the cudnn backend reads qo_indptr/kv_indptr (and o_indptr/"
                        "v_indptr) as int32; pass int32 indptr buffers in CUDA-graph mode"
                    )
                # All four together: o/v default to aliases of q/kv taken above,
                # so converting only q/kv would hand cuDNN mixed dtypes.
                self._qo_indptr_buf = self._qo_indptr_buf.to(torch.int32)
                self._kv_indptr_buf = self._kv_indptr_buf.to(torch.int32)
                self._o_indptr_buf = self._o_indptr_buf.to(torch.int32)
                self._v_indptr_buf = self._v_indptr_buf.to(torch.int32)
            self._cudnn_stats_offsets = self._qo_indptr_buf
            previous_cudnn_plan = self._cudnn_plan
            self._cudnn_plan = None
            if _CUDNN_GRAPH_AVAILABLE and _cudnn_supports_direct_seqlens(q_data_type):
                # run() defaults an FP8 output declaration to BF16.
                cudnn_out_dtype = (
                    torch.bfloat16
                    if o_data_type in (torch.float8_e4m3fn, torch.float8_e5m2)
                    else o_data_type
                )
                metadata = _PrefillMetadata(
                    self._max_token_per_sequence,
                    self._max_sequence_kv,
                    causal,
                    True,
                    o_data_type=cudnn_out_dtype,
                    actual_seq_lens_q=self._seq_lens_q,
                    actual_seq_lens_kv=self._seq_lens_kv,
                    batch_offsets_q=self._qo_indptr_buf,
                    batch_offsets_o=self._o_indptr_buf,
                    batch_offsets_k=self._kv_indptr_buf,
                    batch_offsets_v=self._v_indptr_buf,
                    batch_offsets_stats=self._cudnn_stats_offsets,
                ).resolve_from_plan(
                    q_data_type, num_qo_heads, num_kv_heads, head_dim_qk, head_dim_vo
                )
                self._cudnn_plan = _CudnnPrefillPlan.prepare(
                    metadata, q_data_type, self.device, previous_cudnn_plan
                )

        if self._backend == "cutlass":
            # In CUDA-graph mode only the first plan reaches here: a re-plan is
            # refused above, before the indptr copies, because the captured
            # graph would keep the previous work-index buffers and max_qo_len.
            # `auto` never lands here in graph mode -- it re-resolves on every
            # plan(), so it treats graph mode as CUTLASS-ineligible.
            # Device mirrors, not the caller's tensors: in CUDA-graph mode the
            # kernel reads the registered buffers, and a host-side indptr would
            # otherwise be planned against.
            self._plan_info = fmha_varlen_plan(
                self._cached_module,
                self._qo_indptr_buf,
                self._kv_indptr_buf,
                num_qo_heads,
                causal,
            )
            self._max_qo_len = torch.max(
                self._qo_indptr_buf[1:] - self._qo_indptr_buf[:-1]
            ).item()
            self._cutlass_graph_planned = True
        elif self._backend == "fmha_v2":
            # fmha_v2 handles planning internally — no JIT module plan needed
            pass
        elif self._backend not in (
            "cudnn",
            "cute-dsl",
            "cute-dsl-prims",
            "cutile",
        ):
            assert self._cached_module is not None, "cached module is not initialized"
            args = [
                self._float_workspace_buffer,
                self._int_workspace_buffer,
                self._pin_memory_int_workspace_buffer,
                qo_indptr_host,
                kv_indptr_host,
                kv_len_arr,
                self._max_total_num_rows or total_num_rows,
                batch_size,
                num_qo_heads,
                num_kv_heads,
                1,  # page_size
                self.is_cuda_graph_enabled,
                head_dim_qk,
                head_dim_vo,
                causal,
                window_left,
            ]
            if self._backend == "fa2":
                args.append(fixed_split_size or -1)  # fixed_split_size
                if not disable_split_kv and _nvfp4_kv_requires_disabled_split_kv(
                    kv_data_type, self.device
                ):
                    # Empirical workaround: split-KV corrupted NVFP4 KV reads
                    # when qo_len << kv_len (decode / prefix-cache extend); see
                    # _nvfp4_kv_requires_disabled_split_kv for details.
                    disable_split_kv = True
                args.append(disable_split_kv)  # disable_split_kv
                args.append(0)  # num_colocated_ctas
                args.append(
                    _resolve_uniform_q_len(
                        uniform_q_len,
                        qo_indptr_host,
                        self.is_cuda_graph_enabled,
                        self._backend,
                        "BatchPrefillWithRaggedKVCacheWrapper.plan",
                    )
                )
            self._plan_info = self._cached_module.plan(
                *args,
            )

        self._causal = causal
        self._pos_encoding_mode = pos_encoding_mode
        self._use_fp16_qk_reduction = use_fp16_qk_reduction
        self._window_left = window_left
        self._logits_soft_cap = logits_soft_cap
        self._sm_scale = sm_scale
        self._rope_scale = rope_scale
        self._rope_theta = rope_theta

    begin_forward = plan

    def forward(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        causal: bool = False,
        pos_encoding_mode: str = "NONE",
        use_fp16_qk_reduction: bool = False,
        window_left: int = -1,
        logits_soft_cap: Optional[float] = None,
        sm_scale: Optional[float] = None,
        rope_scale: Optional[float] = None,
        rope_theta: Optional[float] = None,
    ) -> torch.Tensor:
        r"""Warning: This function is deprecated, please use :meth:`run` instead."""
        self._causal = causal
        self._pos_encoding_mode = pos_encoding_mode
        self._use_fp16_qk_reduction = use_fp16_qk_reduction
        self._window_left = window_left
        self._logits_soft_cap = logits_soft_cap
        self._sm_scale = sm_scale
        self._rope_scale = rope_scale
        self._rope_theta = rope_theta
        return self.run(q, k, v)

    @overload
    def run(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        *args,
        out: Optional[torch.Tensor] = None,
        lse: Optional[torch.Tensor] = None,
        return_lse: Literal[False] = False,
        lse_base: str = "log2",
        lse_layout: str = "NH",
        enable_pdl: Optional[bool] = None,
        kv_cache_sf: Optional[
            Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]
        ] = None,
    ) -> torch.Tensor: ...

    @overload
    def run(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        *args,
        out: Optional[torch.Tensor] = None,
        lse: Optional[torch.Tensor] = None,
        return_lse: Literal[True] = True,
        lse_base: str = "log2",
        lse_layout: str = "NH",
        enable_pdl: Optional[bool] = None,
        kv_cache_sf: Optional[
            Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]
        ] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]: ...

    @flashinfer_api(trace=gqa_ragged_prefill_trace)
    def run(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        *args,
        q_scale: Optional[float] = None,
        k_scale: Optional[float] = None,
        v_scale: Optional[float] = None,
        o_scale: Optional[float] = None,
        out: Optional[torch.Tensor] = None,
        lse: Optional[torch.Tensor] = None,
        return_lse: bool = False,
        lse_base: str = "log2",
        lse_layout: str = "NH",
        enable_pdl: Optional[bool] = None,
        kv_cache_sf: Optional[
            Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]
        ] = None,
    ) -> Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
        r"""Compute batch prefill/append attention between query and kv-cache stored as
        ragged tensor.

        Parameters
        ----------
        q : torch.Tensor
            The query tensor, shape: ``[qo_indptr[-1], num_qo_heads, head_dim_qk]``
        k : torch.Tensor
            The key tensor, shape: ``[kv_indptr[-1], num_kv_heads, head_dim_qk]``
        v : torch.Tensor
            The value tensor, shape: ``[kv_indptr[-1], num_kv_heads, head_dim_vo]``
        *args
            Additional arguments for the custom kernel.
        q_scale: Optional[float]
            The calibration scale of fp8 query, if not provided, will be set to ``1.0``.
        k_scale: Optional[float]
            The calibration scale of fp8 or nvfp4 key, if not provided, will be set to ``1.0``.
        v_scale: Optional[float]
            The calibration scale of fp8 or nvfp4 value, if not provided, will be set to ``1.0``.
        o_scale: Optional[float]
            The calibration scale of output, if not provided, will be set to ``1.0``.
        out : Optional[torch.Tensor]
            The output tensor, if not provided, will be allocated internally.
        lse : Optional[torch.Tensor]
            The log-sum-exp of attention logits, if not provided, will be allocated internally.
        return_lse : bool
            Whether to return the logsumexp of attention output
        lse_base : str
            Base of the returned ``lse`` when :attr:`return_lse` is ``True``:
            ``"log2"`` (default, FlashInfer's convention, ``max + log2(sum(exp2(...)))``)
            or ``"ln"`` (natural log, the ``torch.logsumexp`` convention that merge
            kernels written with ``expf`` consume). ``"ln"`` lets the cuDNN backend hand
            out its native stats without a conversion kernel; the other backends rescale.
        lse_layout : str
            Layout of the returned ``lse``: ``"NH"`` (default) is
            ``[qo_indptr[-1], num_qo_heads]``, ``"HN"`` is the contiguous transpose
            ``[num_qo_heads, qo_indptr[-1]]`` (one fused transpose + rescale kernel).
            A caller-provided :attr:`lse` must have the requested layout.
        enable_pdl : bool
            Whether to enable Programmatic Dependent Launch (PDL). See https://docs.nvidia.com/cuda/cuda-c-programming-guide/#programmatic-dependent-launch-and-synchronization
            Only effective on backends and devices that support PDL.
        kv_cache_sf : Optional[Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]]
            Per-block scale factors for NVFP4 KV input.  Accepts either a single
            packed scale tensor or a ``(k_scales, v_scales)`` tuple matching the
            structure expected by the chosen backend.  When ``None`` (default), the
            kernel runs without NVFP4 KV scaling.  See
            :func:`flashinfer.fp4_quantization.nvfp4_quantize` for layout details.
        Returns
        -------
        Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]
            If :attr:`return_lse` is ``False``, the attention output, shape: ``[qo_indptr[-1], num_qo_heads, head_dim_vo]``.
            If :attr:`return_lse` is ``True``, a tuple of two tensors:

            * The attention output, shape: ``[qo_indptr[-1], num_qo_heads, head_dim_vo]``.
            * The logsumexp of attention output, shape: ``[qo_indptr[-1], num_qo_heads]``
              (``lse_layout="NH"``, default) or ``[num_qo_heads, qo_indptr[-1]]``
              (``"HN"``), in the base selected by :attr:`lse_base`.
        """
        if enable_pdl is None:
            enable_pdl = device_support_pdl(q.device)
        check_lse_base(lse_base)
        check_lse_layout(lse_layout)
        _check_cached_qkv_data_type(
            q, k, self._cached_q_data_type, self._cached_kv_data_type
        )
        # Validate q shape matches qo_indptr (using value cached in plan() to avoid GPU sync)
        if self._backend == "cudnn":
            if q.size(0) != self._qo_indptr_last:
                hint = ""
                if q.numel() == self._qo_indptr_last:
                    hint = (
                        " qo_indptr looks like element-unit offsets "
                        "(total_tokens * num_heads * head_dim); the cudnn backend now "
                        "takes token-unit qo_indptr, like every other backend."
                    )
                raise ValueError(
                    f"q.shape[0] ({q.size(0)}) does not match qo_indptr[-1] ({self._qo_indptr_last})."
                    + hint
                )
        else:
            if q.size(0) != self._qo_indptr_last:
                raise ValueError(
                    f"q.shape[0] ({q.size(0)}) does not match qo_indptr[-1] ({self._qo_indptr_last}). "
                    f"For ragged prefill, q must have shape [total_tokens, num_heads, head_dim] "
                    f"where total_tokens = qo_indptr[-1]."
                )

        window_left = self._window_left
        logits_soft_cap = self._logits_soft_cap
        sm_scale = self._sm_scale
        rope_scale = self._rope_scale
        rope_theta = self._rope_theta
        if logits_soft_cap is None:
            logits_soft_cap = 0.0
        if sm_scale is None:
            sm_scale = 1.0 / math.sqrt(q.size(-1))
        # FA2/FA3 with a 16-bit query consumes unscaled FP8 KV values.
        # Full-FP8 and other backends handle their scales separately.
        apply_kv_scales = kv_cache_sf is not None or (
            self._backend in ("fa2", "fa3") and is_float8(k) and not is_float8(q)
        )
        if kv_cache_sf is not None:
            if q_scale is not None:
                sm_scale *= q_scale
        if apply_kv_scales and k_scale is not None:
            sm_scale *= k_scale
        if rope_scale is None:
            rope_scale = 1.0
        if rope_theta is None:
            rope_theta = 1e4
        lse, lse_out = _stage_lse(lse, lse_layout, return_lse, q)
        if return_lse:
            if lse is None:
                lse = torch.empty(
                    (q.size(0), q.size(1)), dtype=torch.float32, device=q.device
                )
            else:
                check_shape_dtype_device(
                    lse, (q.size(0), q.size(1)), torch.float32, q.device, "lse"
                )
        # Unpack kv_cache_sf for NVFP4 ragged KV
        k_sf, v_sf = None, None
        if kv_cache_sf is not None:
            if isinstance(kv_cache_sf, tuple):
                k_sf, v_sf = kv_cache_sf
            else:
                k_sf, v_sf = kv_cache_sf.unbind(dim=1)

        # NVFP4 packed: unpacked VO width is packed bytes * 2 (supports
        # asymmetric QK/VO; q.shape[-1] assumed QK == VO). Gate on the packed
        # (uint8) storage so a stray scale-factor tensor on a non-uint8 cache
        # can't silently double the output width (matches the decode-side guard).
        out_head_dim = (
            v.shape[-1] * 2
            if kv_cache_sf is not None and v.dtype == torch.uint8
            else v.shape[-1]
        )
        # Effective output dtype for allocation and validation; an 8-bit cached
        # dtype is just plan()'s q_data_type default, so fall back to bf16.
        out_dtype = getattr(self, "_cached_o_data_type", None)
        if out_dtype is None or out_dtype.itemsize == 1:
            out_dtype = torch.bfloat16 if q.dtype.itemsize == 1 else q.dtype
        if out is None:
            out = torch.empty(
                q.shape[:-1] + (out_head_dim,),
                dtype=out_dtype,
                device=q.device,
            )
        else:
            check_shape_dtype_device(
                out,
                q.shape[:-1] + (out_head_dim,),
                out_dtype,
                q.device,
                "out",
            )
        if self._backend == "cute-dsl-prims":
            assert self._prims_backend is not None
            if args:
                raise NotImplementedError(
                    "backend='cute-dsl-prims' does not accept custom run arguments"
                )
            if getattr(self, "_sinks", None) is not None:
                raise NotImplementedError(
                    "attention sinks were set on the wrapper (_sinks) but "
                    "backend='cute-dsl-prims' does not support attention sinks"
                )
            if kv_cache_sf is not None:
                raise NotImplementedError(
                    "backend='cute-dsl-prims' does not support NVFP4 kv_cache_sf"
                )
            if o_scale is not None:
                raise NotImplementedError(
                    "backend='cute-dsl-prims' does not support o_scale"
                )
            self._prims_backend.run_ragged(
                q,
                k,
                v,
                out,
                lse=lse if return_lse else None,
                enable_pdl=enable_pdl,
                q_scale=q_scale,
                k_scale=k_scale,
                v_scale=v_scale,
            )
            return (
                (out, _finish_lse(lse, lse_base, lse_layout, lse_out))
                if return_lse
                else out
            )
        elif self._backend == "fmha_v2":
            if return_lse:
                raise NotImplementedError(
                    "return_lse is not yet supported for backend='fmha_v2'. "
                    "TRT-LLM fmha_v2 softmax stats have a different format "
                    "than the expected [total_q_tokens, num_heads] LSE tensor."
                )
            fmha_v2_mask_mode = "causal" if self._causal else "padding"
            # Use CONTIGUOUS_Q_KV layout: pass Q separately and stack only
            # K+V into [num_tokens, 2, num_kv_heads, head_dim]. This avoids
            # the 3-way torch.stack copy that PACKED_QKV requires.
            # (fmha_v2 auto-selection already requires MHA, so Q/K head counts match)
            #
            # CONTIGUOUS_Q_KV requires Q to be contiguous. torch.stack() below
            # materializes a contiguous kv_packed, but Q is forwarded directly, so a
            # non-contiguous (e.g. packed/strided) Q would be read with the wrong
            # strides and yield garbage. .contiguous() is a no-op when Q is already
            # contiguous (the common hot path), so it restores correctness for
            # non-contiguous Q with no cost otherwise.
            q = q.contiguous()
            kv_packed = torch.stack([k, v], dim=1)
            # Pass window_left and sinks for sliding-window + attention sink
            # support. sinks is stored on the wrapper by vLLM's metadata builder.
            fmha_v2_sinks = getattr(self, "_sinks", None)
            fmha_v2_kwargs = {}
            if self._window_left >= 0:
                fmha_v2_kwargs["window_left"] = self._window_left
            if fmha_v2_sinks is not None:
                fmha_v2_kwargs["sinks"] = fmha_v2_sinks
            out = trtllm_fmha_v2_prefill(
                (q, kv_packed),
                input_layout="CONTIGUOUS_Q_KV",
                workspace_buffer=self._float_workspace_buffer,
                seq_lens=self._fmha_v2_seq_lens,
                max_q_len=self._fmha_v2_max_q_len,
                max_kv_len=self._fmha_v2_max_kv_len,
                bmm1_scale=sm_scale,
                bmm2_scale=1.0,
                batch_size=self._fmha_v2_batch_size,
                cum_seq_lens_q=self._fmha_v2_qo_indptr,
                cum_seq_lens_kv=self._fmha_v2_kv_indptr,
                out=out,
                mask_mode=fmha_v2_mask_mode,
                save_softmax_stats=False,
                **fmha_v2_kwargs,
            )
            return out
        elif self._backend == "cute-dsl":
            if kv_cache_sf is not None:
                raise NotImplementedError(
                    "cute-dsl backend does not support NVFP4 packed KV cache "
                    "(kv_cache_sf)"
                )
            # vLLM's metadata builder stashes attention sinks on the wrapper
            # for the fmha_v2 route; the cute-dsl route would silently
            # ignore them (wrong results), so fail loudly with the
            # supported alternative.
            if getattr(self, "_sinks", None) is not None:
                raise NotImplementedError(
                    "attention sinks were set on the wrapper (_sinks) but "
                    "the public cute-dsl ragged route does not consume "
                    "them; the backend supports sinks as a plan-time "
                    "variant — use flashinfer.cute_dsl.attention."
                    "BatchPrefillCuteDSLWrapper with "
                    "plan(..., variant=AttentionWithSink(sinks))"
                )
            # enable_pdl is a launch-latency hint: forwarded on the FMHA
            # route below; the modular kernel has no PDL support.
            if self._cute_dsl_use_fmha:
                # Delegate dense/causal plans to the trtllm CuTe DSL FMHA
                # kernel (mixed V dtype included: it JIT-compiles
                # separate-V-dtype variants).  Windowed plans stay on the
                # modular path for every V dtype.
                p = self._cute_dsl_fmha_plan
                bmm1_scale = (
                    p["sm_scale"]
                    * (q_scale if q_scale is not None else 1.0)
                    * (k_scale if k_scale is not None else 1.0)
                )
                bmm2_scale = (v_scale if v_scale is not None else 1.0) / (
                    o_scale if o_scale is not None else 1.0
                )
                res = trtllm_ragged_attention_deepseek(
                    query=q,
                    key=k,
                    value=v,
                    workspace_buffer=self._float_workspace_buffer,
                    seq_lens=p["seq_lens"],
                    max_q_len=p["max_q_len"],
                    max_kv_len=p["max_kv_len"],
                    bmm1_scale=bmm1_scale,
                    bmm2_scale=bmm2_scale,
                    o_sf_scale=1.0,
                    batch_size=p["batch_size"],
                    window_left=p["window_left"],
                    cum_seq_lens_q=p["qo_indptr"],
                    cum_seq_lens_kv=p["kv_indptr"],
                    enable_pdl=enable_pdl,
                    is_causal=p["causal"],
                    return_lse=return_lse,
                    out=out,
                    lse=lse,
                    backend="cute-dsl",
                    q_seq_lens_cpu=p["q_seq_lens_cpu"],
                    kv_seq_lens_cpu=p["kv_seq_lens_cpu"],
                    skip_all_rows_active_check=False,
                )
                if isinstance(res, tuple):
                    return res[0], _finish_lse(res[1], lse_base, lse_layout, lse_out)
                return res
            # Modular CuTe DSL backend does not support scale parameters.
            if any(s is not None for s in (q_scale, k_scale, v_scale, o_scale)):
                raise NotImplementedError(
                    "cute-dsl backend does not support FP8 scale parameters"
                )
            if return_lse:
                # Standard-path modular kernel computes LSE natively; the
                # wrapper raises NotImplementedError for attention variants.
                out, lse = self._cute_dsl_wrapper.run(
                    q, k, v, out=out, return_lse=True, lse=lse
                )
                return out, _finish_lse(lse, lse_base, lse_layout, lse_out)
            out = self._cute_dsl_wrapper.run(q, k, v, out=out)
            return out
        elif self._backend == "cutlass":
            if getattr(self, "_sinks", None) is not None:
                raise NotImplementedError(
                    "attention sinks were set on the wrapper (_sinks) but the "
                    "cutlass ragged prefill backend does not consume them; plan() "
                    "again (auto routes past cutlass when sinks are set) or use fa2"
                )
            out, lse = fmha_varlen(
                q,
                k,
                v,
                self._qo_indptr_buf,
                self._kv_indptr_buf,
                plan_info=self._plan_info,
                causal=self._causal,
                sm_scale=sm_scale,
                q_scale=q_scale,
                k_scale=k_scale,
                v_scale=v_scale,
                o_scale=o_scale,
                max_qo_len=self._max_qo_len,
                out=out,
                lse=lse,
            )
            return (
                (out, _finish_lse(lse, lse_base, lse_layout, lse_out))
                if return_lse
                else out
            )
        elif self._backend == "cudnn":
            # The cuDNN graph declares dense output and Stats strides.
            if o_scale is not None or kv_cache_sf is not None:
                raise NotImplementedError(
                    "cuDNN ragged prefill does not support o_scale or NVFP4"
                )
            if not out.is_contiguous():
                raise ValueError("out must be contiguous for the cuDNN backend")
            if return_lse and not lse.is_contiguous():
                raise ValueError("lse must be contiguous for the cuDNN backend")
            # cuDNN's ragged prefill graph has no kv_layout input and reads
            # k.shape[1] as the kv head count, i.e. it assumes NHD. Reject HND
            # loudly rather than silently addressing the wrong data.
            if self._kv_layout != "NHD":
                raise NotImplementedError(
                    "cuDNN ragged prefill backend requires kv_layout='NHD'"
                )
            if getattr(self, "_sinks", None) is not None:
                raise NotImplementedError(
                    "attention sinks were set on the wrapper (_sinks) but the "
                    "cuDNN ragged prefill backend does not consume them; plan() "
                    "again (auto routes past cuDNN when sinks are set) or use fa2"
                )
            if (
                return_lse
                and self._max_token_per_sequence == 1
                and q.shape[1] != k.shape[1]
            ):
                raise NotImplementedError(
                    "cuDNN's single-token (max q_len == 1) GQA kernel writes the "
                    "LSE only for the first head of each kv group (cuDNN 9.26/9.27 "
                    "bug, NVBug 6783545); use backend='auto', which routes these steps "
                    "to another backend, or return_lse=False"
                )
            # The caller's token-unit indptrs go straight to cuDNN (mask +
            # ragged offsets, scaled in-engine); no per-call conversion kernels.
            # actual_seq_lens_q/kv are optional: the direct path derives them
            # from the indptrs. The stats ragged offset makes cuDNN write the
            # LSE packed as [total_tokens, num_qo_heads], the wrapper's contract.
            if self._seq_lens_q is not None and self._seq_lens_q.dim() == 1:
                self._seq_lens_q = self._seq_lens_q.reshape(-1, 1, 1, 1)
            if self._seq_lens_kv is not None and self._seq_lens_kv.dim() == 1:
                self._seq_lens_kv = self._seq_lens_kv.reshape(-1, 1, 1, 1)

            plan = self._cudnn_plan
            if (
                plan is not None
                and plan.metadata.causal == self._causal
                and q_scale is None
                and k_scale is None
                and v_scale is None
            ):
                prepared = self._cudnn_prepared
                if prepared is None or not prepared.matches_plan(
                    q, k, v, sm_scale, plan, return_lse
                ):
                    prepared = self._cudnn_prepared = prepare_cudnn_batch_prefill(
                        q,
                        k,
                        v,
                        sm_scale,
                        self._float_workspace_buffer,
                        metadata=plan.build_metadata(return_lse),
                    )
                prepared.run_planned(
                    q,
                    k,
                    v,
                    out,
                    lse,
                    self._float_workspace_buffer,
                    plan=plan,
                    lse_base=lse_base,
                )
            else:
                cudnn_batch_prefill_with_kv_cache(
                    q,
                    k,
                    v,
                    sm_scale,
                    self._float_workspace_buffer,
                    max_token_per_sequence=self._max_token_per_sequence,
                    max_sequence_kv=self._max_sequence_kv,
                    actual_seq_lens_q=self._seq_lens_q,
                    actual_seq_lens_kv=self._seq_lens_kv,
                    return_lse=return_lse,
                    causal=self._causal,
                    q_scale=q_scale,
                    k_scale=k_scale,
                    v_scale=v_scale,
                    batch_offsets_q=self._qo_indptr_buf,
                    batch_offsets_k=self._kv_indptr_buf,
                    batch_offsets_v=self._v_indptr_buf,
                    batch_offsets_o=self._o_indptr_buf,
                    batch_offsets_stats=(
                        self._cudnn_stats_offsets if return_lse else None
                    ),
                    batch_offsets_units="tokens",
                    is_cuda_graph_compatible=self._use_cuda_graph,
                    lse_base=lse_base,
                    out=out,
                    lse=lse,
                    o_data_type=out_dtype,
                )

            # base already handled inside cudnn_batch_prefill_with_kv_cache
            return (
                (out, _finish_lse(lse, "log2", lse_layout, lse_out))
                if return_lse
                else out
            )
        elif self._backend == "cutile":
            if any(s is not None for s in (q_scale, k_scale, v_scale, o_scale)):
                raise NotImplementedError(
                    "cuTile ragged prefill does not support FP8 scale parameters."
                )
            if kv_cache_sf is not None:
                raise NotImplementedError(
                    "cuTile ragged prefill does not support NVFP4 KV scaling."
                )
            from .attention.kernels.cutile.fmha_prefill_bsr_cutile import (  # noqa: PLC0415
                prefill_attention_kv_ragged_cutile,
            )

            # k/v are ragged [total_kv, num_kv_heads, head_dim]. The kernel folds
            # the softmax scale into k_scale (qk_scale = k_scale * INV_LOG_2),
            # matching single_prefill_with_kv_cache's default.
            out_ragged, lse_ragged = prefill_attention_kv_ragged_cutile(
                q=q,
                k_cache=k,
                v_cache=v,
                actual_seq_lens_q=self._cutile_seq_lens_q,
                actual_seq_lens_kv=self._cutile_seq_lens_kv,
                actual_seq_offset=self._cutile_seq_offset,
                block_tables=self._cutile_block_tables,
                k_scale=sm_scale,
                v_scale=1.0,
                num_batch=self._cutile_num_batch,
                max_seq_len=self._cutile_max_seq_len,
                is_causal=self._causal,
                outputs=out,
                out_lse=lse if return_lse else None,
            )
            return (
                (out_ragged, _finish_lse(lse_ragged, lse_base, lse_layout, lse_out))
                if return_lse
                else out_ragged
            )

        # Skip FP8->FP16 conversion for FA3 backend with FP8 support
        # The JIT module will handle FP8 natively
        if is_float8(q) and self._backend != "fa3":
            logging.warning(
                "Our current prefill kernel implementation needs f16 input, the f8 inputs "
                " are casted to f16, which could result in performance degradation."
            )
            q = q.to(torch.float16)
            k = k.to(torch.float16)
            v = v.to(torch.float16)

        if self._custom_mask_buf is not None or self._variant_owns_mask:
            mask_mode = MaskMode.CUSTOM.value
        else:
            if self._causal:
                mask_mode = MaskMode.CAUSAL.value
            else:
                mask_mode = MaskMode.NON_CAUSAL.value

        run_args = [
            self._float_workspace_buffer,
            self._int_workspace_buffer,
            self._plan_info,
            q,
            k,
            v,
            self._qo_indptr_buf,
            self._kv_indptr_buf,
            out,
            lse,
            mask_mode,
            TensorLayout[self._kv_layout].value,
            window_left,
            enable_pdl,
        ]
        if self._jit_module is not None:
            run_args.extend(
                prepare_jit_additional_args(
                    self._jit_additional_tensor_names,
                    {
                        "maybe_custom_mask": self._custom_mask_buf,
                        "maybe_mask_indptr": self._mask_indptr_buf,
                        "maybe_alibi_slopes": lambda: _get_cache_alibi_slopes_buf(
                            q.shape[1], self.device
                        ),
                    },
                    args,
                )
            )
        else:
            run_args += [
                self._custom_mask_buf,
                self._mask_indptr_buf,
                _get_cache_alibi_slopes_buf(q.shape[1], self.device),
                self._prefix_len_ptr,
                self._token_pos_in_items_ptr,
                self._max_item_len_ptr,
                logits_soft_cap,
                sm_scale,
                rope_scale,
                rope_theta,
                self._token_pos_in_items_len,
                k_sf,
                v_sf,
            ]
            # For FP8, append scale tensors
            if is_float8(q):
                run_args.extend(list(args))  # scale_q, scale_k, scale_v

        assert self._cached_module is not None, "cached module is not initialized"
        self._cached_module.ragged_run(*run_args)

        # Apply global V calibration after attention, without changing the LSE.
        is_float_one = isinstance(v_scale, float) and v_scale == 1.0
        if apply_kv_scales and v_scale is not None and not is_float_one:
            out *= v_scale

        return (
            (out, _finish_lse(lse, lse_base, lse_layout, lse_out))
            if return_lse
            else out
        )

    run_return_lse = functools.partialmethod(run, return_lse=True)

    def forward_return_lse(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        causal: bool = False,
        pos_encoding_mode: str = "NONE",
        use_fp16_qk_reduction: bool = False,
        window_left: int = -1,
        logits_soft_cap: Optional[float] = None,
        sm_scale: Optional[float] = None,
        rope_scale: Optional[float] = None,
        rope_theta: Optional[float] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        r"""Warning: This function is deprecated, please use :meth:`run_return_lse` instead."""
        self._causal = causal
        self._pos_encoding_mode = pos_encoding_mode
        self._use_fp16_qk_reduction = use_fp16_qk_reduction
        self._window_left = window_left
        self._logits_soft_cap = logits_soft_cap
        self._sm_scale = sm_scale
        self._rope_scale = rope_scale
        self._rope_theta = rope_theta
        return self.run_return_lse(q, k, v)


def fmha_varlen_plan(
    module,
    qo_segment_offsets: torch.Tensor,
    kv_segment_offsets: torch.Tensor,
    num_qo_heads: int,
    causal: bool,
):
    num_ctas = torch.cuda.get_device_properties(
        qo_segment_offsets.device
    ).multi_processor_count
    work_indptr = torch.empty(
        num_ctas + 1, device=qo_segment_offsets.device, dtype=torch.int32
    )
    qo_tile_indices = torch.empty(
        131072, device=qo_segment_offsets.device, dtype=torch.int32
    )
    head_indices = torch.empty(
        131072, device=qo_segment_offsets.device, dtype=torch.int32
    )
    batch_indices = torch.empty(
        131072, device=qo_segment_offsets.device, dtype=torch.int32
    )
    module.plan(
        qo_segment_offsets,
        kv_segment_offsets,
        work_indptr,
        qo_tile_indices,
        head_indices,
        batch_indices,
        256,  # qo_tile_size
        num_qo_heads,
        num_ctas,
        causal,
    )
    return (
        work_indptr,
        qo_tile_indices,
        head_indices,
        batch_indices,
    )


@overload
def fmha_varlen(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    qo_segment_offsets: torch.Tensor,
    kv_segment_offsets: torch.Tensor,
    plan_info: Optional[List[torch.Tensor]] = None,
    max_qo_len: Optional[int] = None,
    out: Optional[torch.Tensor] = None,
    lse: Optional[torch.Tensor] = None,
    causal: bool = False,
    sm_scale: Optional[float] = None,
    q_scale: Optional[float] = None,
    k_scale: Optional[float] = None,
    v_scale: Optional[float] = None,
    o_scale: Optional[float] = None,
    return_lse: Literal[False] = False,
) -> torch.Tensor: ...


@overload
def fmha_varlen(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    qo_segment_offsets: torch.Tensor,
    kv_segment_offsets: torch.Tensor,
    plan_info: Optional[List[torch.Tensor]] = None,
    max_qo_len: Optional[int] = None,
    out: Optional[torch.Tensor] = None,
    lse: Optional[torch.Tensor] = None,
    causal: bool = False,
    sm_scale: Optional[float] = None,
    q_scale: Optional[float] = None,
    k_scale: Optional[float] = None,
    v_scale: Optional[float] = None,
    o_scale: Optional[float] = None,
    return_lse: Literal[True] = True,
) -> Tuple[torch.Tensor, torch.Tensor]: ...


def fmha_varlen(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    qo_segment_offsets: torch.Tensor,
    kv_segment_offsets: torch.Tensor,
    plan_info: Optional[List[torch.Tensor]] = None,
    max_qo_len: Optional[int] = None,
    out: Optional[torch.Tensor] = None,
    lse: Optional[torch.Tensor] = None,
    causal: bool = False,
    sm_scale: Optional[float] = None,
    q_scale: Optional[float] = None,
    k_scale: Optional[float] = None,
    v_scale: Optional[float] = None,
    o_scale: Optional[float] = None,
    return_lse: bool = False,
) -> Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
    workspace_buffer = _get_cache_buf(
        "fmha_varlen_cutlass_workspace", 32 * 1024 * 1024, q.device
    )
    module = get_fmha_module(
        q.dtype,
        k.dtype,
        v.dtype,
        torch.int32,
        q.shape[2],
        v.shape[2],
        PosEncodingMode.NONE.value,
        False,  # use_sliding_window
        False,  # use_logits_soft_cap
        q.device,
    )

    nnz_qo, num_qo_heads, head_dim_qk = q.shape
    nnz_kv, num_kv_heads, head_dim_vo = v.shape

    mask_mode_code = 1 if causal else 0
    if sm_scale is None:
        sm_scale = 1.0 / math.sqrt(head_dim_qk)
    if q_scale is None:
        q_scale = 1.0
    if k_scale is None:
        k_scale = 1.0
    if v_scale is None:
        v_scale = 1.0
    if o_scale is None:
        o_scale = 1.0

    qo_total_len = nnz_qo
    if max_qo_len is None:
        max_qo_len = torch.max(qo_segment_offsets[1:] - qo_segment_offsets[:-1]).item()

    if plan_info is None:
        plan_info = fmha_varlen_plan(
            module, qo_segment_offsets, kv_segment_offsets, num_qo_heads, causal
        )

    (
        work_indptr,
        qo_tile_indices,
        head_indices,
        batch_indices,
    ) = plan_info

    if out is None:
        # when input dtype is fp8, we need to use bf16 output
        out_dtype = torch.bfloat16 if q.dtype.itemsize == 1 else q.dtype
        out = torch.empty(
            qo_total_len + max(max_qo_len, 128),
            num_qo_heads,
            head_dim_vo,
            device=q.device,
            dtype=out_dtype,
        )[max(max_qo_len, 128) :]

    if lse is None and return_lse:
        lse = torch.empty(
            qo_total_len, num_qo_heads, device=q.device, dtype=torch.float32
        )

    module.run(
        workspace_buffer,
        q,
        k,
        v,
        qo_segment_offsets,
        kv_segment_offsets,
        work_indptr,
        qo_tile_indices,
        head_indices,
        batch_indices,
        out,
        lse,
        mask_mode_code,
        sm_scale,
        q_scale,
        k_scale,
        v_scale,
        o_scale,
        max_qo_len,
    )

    return out, lse


@functools.cache
def get_trtllm_gen_fmha_module():
    mod = gen_trtllm_gen_fmha_module()
    op = mod.build_and_load()
    for library_path in mod.get_library_paths():
        setup_cubin_loader(library_path)
    return op


def trtllm_sage_attention_quantize(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    q_block_size: int = 1,
    k_block_size: int = 16,
    qk_quant_dtype: torch.dtype = torch.int8,
    cum_seq_lens_q: Optional[torch.Tensor] = None,
    cum_seq_lens_kv: Optional[torch.Tensor] = None,
    smooth_k: bool = False,
) -> Union[
    Tuple[
        torch.Tensor,
        torch.Tensor,
        torch.Tensor,
        torch.Tensor,
        torch.Tensor,
        torch.Tensor,
    ],
    Tuple[
        torch.Tensor,
        torch.Tensor,
        torch.Tensor,
        torch.Tensor,
        torch.Tensor,
        torch.Tensor,
        torch.Tensor,
    ],
]:
    """Quantize Q/K/V into the layout consumed by TRTLLM SageAttention.

    Q and K use per-token-block scaling and can be quantized to INT8 or FP8
    E4M3. V is always quantized to FP8 E4M3 with one scale per head channel.
    All inputs use contiguous ``[tokens, heads, head_dim]`` layout.

    Parameters
    ----------
    query, key, value : torch.Tensor
        FP16 or BF16 CUDA tensors. Key and value must have matching token and
        head counts, and all three tensors must have the same head dimension.
    q_block_size, k_block_size : int
        Number of tokens sharing each Q or K scale. Supported values are 1, 4,
        and 16.
    qk_quant_dtype : torch.dtype
        ``torch.int8`` (the SageAttention INT8 path) or
        ``torch.float8_e4m3fn``.
    cum_seq_lens_q, cum_seq_lens_kv : Optional[torch.Tensor]
        Contiguous INT32 CUDA tensors of shape ``[batch_size + 1]`` containing
        cumulative Q and KV sequence lengths. Assumes single-batch input if
        `cum_seq_lens_q` is missing.
    smooth_k : bool
        Whether to perform K-smoothing before quantization for better accuracy.
        NOTE: K-smoothing shifts LSE by ``-sm_scale * (query * k_mean).sum(-1)``
        FlashInfer does not consume `k_mean`, thus it's up to users to shift
        back the LSE if performing ring attention with this option enabled.

    Returns
    -------
    (q_quant, k_quant, v_quant, q_scale, k_scale, v_scale) or
    (q_quant, k_quant, v_quant, q_scale, k_scale, v_scale, k_mean)
        Quantized Q/K/V followed by their FP32 dequantization scales.
        When ``smooth_k=True``, the FP32 K mean is appended. The first six
        outputs can be passed directly to `trtllm_ragged_attention_deepseek`.
    """
    if query.dtype not in (torch.float16, torch.bfloat16):
        raise ValueError(f"query must be float16 or bfloat16, got {query.dtype}")
    if key.dtype != query.dtype or value.dtype != query.dtype:
        raise ValueError("query, key, and value must have the same dtype")
    if query.device.type != "cuda":
        raise ValueError("query, key, and value must be CUDA tensors")
    if key.device != query.device or value.device != query.device:
        raise ValueError("query, key, and value must be on the same CUDA device")
    if query.ndim != 3 or key.ndim != 3 or value.ndim != 3:
        raise ValueError("query, key, and value must be 3D [tokens, heads, head_dim]")
    if query.shape[2] != key.shape[2] or key.shape[2] != value.shape[2]:
        raise ValueError("query, key, and value must have the same head dimension")
    if key.shape[:2] != value.shape[:2]:
        raise ValueError("key and value must have matching token and head counts")
    if query.shape[2] not in (64, 128, 256):
        raise ValueError("head_dim must be 64, 128, or 256")
    if q_block_size not in (1, 4, 16) or k_block_size not in (1, 4, 16):
        raise ValueError("q_block_size and k_block_size must be 1, 4, or 16")
    if qk_quant_dtype not in (torch.int8, torch.float8_e4m3fn):
        raise ValueError("qk_quant_dtype must be torch.int8 or torch.float8_e4m3fn")
    if cum_seq_lens_q is None:
        cum_seq_lens_q = torch.tensor(
            [0, query.shape[0]], dtype=torch.int32, device=query.device
        )
        cum_seq_lens_kv = torch.tensor(
            [0, key.shape[0]], dtype=torch.int32, device=query.device
        )
    elif cum_seq_lens_kv is None:
        cum_seq_lens_kv = cum_seq_lens_q

    batch_size = cum_seq_lens_q.numel() - 1

    query = query.contiguous()
    key = key.contiguous()
    value = value.contiguous()
    q_quant = torch.empty_like(query, dtype=qk_quant_dtype)
    k_quant = torch.empty_like(key, dtype=qk_quant_dtype)
    v_quant = torch.empty_like(value, dtype=torch.float8_e4m3fn)
    q_scale = torch.empty(
        (query.shape[1], ceil_div(query.shape[0], q_block_size) + batch_size - 1),
        dtype=torch.float32,
        device=query.device,
    )
    k_scale = torch.empty(
        (key.shape[1], ceil_div(key.shape[0], k_block_size) + batch_size - 1),
        dtype=torch.float32,
        device=query.device,
    )
    v_scale = torch.empty(
        (value.shape[1], value.shape[2]),
        dtype=torch.float32,
        device=query.device,
    )
    k_mean = (
        torch.empty(
            (key.shape[1], key.shape[2]),
            dtype=torch.float32,
            device=query.device,
        )
        if smooth_k
        else None
    )

    get_trtllm_gen_fmha_module().trtllm_sage_attention_quantize(
        q_quant,
        k_quant,
        v_quant,
        q_scale,
        k_scale,
        v_scale,
        query,
        key,
        value,
        cum_seq_lens_q,
        cum_seq_lens_kv,
        q_block_size,
        k_block_size,
        get_device_sm_count(query.device),
        k_mean,
        smooth_k,
    )
    if smooth_k:
        return q_quant, k_quant, v_quant, q_scale, k_scale, v_scale, k_mean
    return q_quant, k_quant, v_quant, q_scale, k_scale, v_scale


@flashinfer_api(trace=trtllm_ragged_attention_deepseek_trace)
def trtllm_ragged_attention_deepseek(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    workspace_buffer: torch.Tensor,
    seq_lens: torch.Tensor,
    max_q_len: int,
    max_kv_len: int,
    bmm1_scale: Union[float, torch.Tensor],
    bmm2_scale: Union[float, torch.Tensor],
    o_sf_scale: float,
    batch_size: int,
    window_left: int,
    cum_seq_lens_q: torch.Tensor,
    cum_seq_lens_kv: torch.Tensor,
    enable_pdl: bool | None,
    is_causal: bool,
    return_lse: bool,
    attention_sinks: Optional[torch.Tensor] = None,
    skip_softmax_threshold_scale_factor: Optional[float] = None,
    out: Optional[torch.Tensor] = None,
    lse: Optional[torch.Tensor] = None,
    sage_attn_sfs: Tuple[
        Optional[torch.Tensor],
        Optional[torch.Tensor],
        Optional[torch.Tensor],
        Optional[torch.Tensor],
    ] = (None, None, None, None),
    num_elts_per_sage_attn_blk: Tuple[int, int, int, int] = (0, 0, 0, 0),
    backend: str = "trtllm-gen",
    q_seq_lens_cpu: Optional[torch.Tensor] = None,
    kv_seq_lens_cpu: Optional[torch.Tensor] = None,
    use_fp16_softmax: Optional[bool] = None,
    uses_spcompress: Optional[bool] = None,
    skip_all_rows_active_check: bool = True,
) -> Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
    """
    Parameters
    ----------
    query : torch.Tensor
        query tensor with shape [num_tokens, num_heads, head_dim]
    key : torch.Tensor
        key tensor with shape [num_tokens, num_heads, head_dim]
    value : torch.Tensor
        value tensor with shape [num_tokens, num_heads, head_dim]
    workspace_buffer : torch.Tensor
        workspace buffer
    seq_lens : torch.Tensor
        sequence lengths
    max_q_len : int
        max query length
    max_kv_len : int
        max key/value length
    bmm1_scale : Union[float, torch.Tensor]
        scale for bmm1, scale_q * scale_k * 1.0 / (head_dim_qk ** 0.5)
        when using trtllm-gen backend, it can be a torch.Tensor with dtype torch.float32.
    bmm2_scale : Union[float, torch.Tensor]
        scale for bmm2, scale_v
        when using trtllm-gen backend, it can be a torch.Tensor with dtype torch.float32.
    o_sf_scale : float
        scale for output
    batch_size : int
        batch size
    window_left : int
        window left
    cum_seq_lens_q : torch.Tensor
        cumulative sequence lengths for query
    cum_seq_lens_kv : torch.Tensor
        cumulative sequence lengths for key/value
    enable_pdl : bool
        enable pdl
    is_causal : bool
        is causal
    return_lse : bool
        Whether to allocate and return the log-sum-exp tensor in addition to the
        attention output.  When ``True`` the function returns
        ``(out, lse)``; when ``False`` only ``out`` is returned.
    attention_sinks : Optional[torch.Tensor]
        attention sinks
    skip_softmax_threshold_scale_factor : Optional[float]
        threshold scale factor for skipping softmax operations.
        Providing a value for this parameter enables skip-softmax sparsity as described in: https://arxiv.org/abs/2512.12087
        If no value is provided, then standard attention is used.
        Setting the threshold to a higher value generally increases kernel performance at the cost of accuracy degradation.
        The actual threshold value equals the provided threshold_scale_factor divided by the context length.
    out : Optional[torch.Tensor]
        output tensor, if not provided, will be allocated with shape [query.shape[0], query.shape[1], value.shape[2]]
    lse : Optional[torch.Tensor]
        lse tensor, if not provided, will be allocated with shape [query.shape[0], query.shape[1]]
    use_fp16_softmax : Optional[bool]
        Select the trtllm-gen ``Fp16Softmax`` cubin variant (BF16 Q/KV/O only).
        When ``None`` (default) or ``False`` the standard FP32-accumulator softmax cubin is used.
        Setting ``True`` for non-BF16 inputs will fail kernel selection.
    uses_spcompress : Optional[bool]
        Select the trtllm-gen ``Spcomp`` cubin variant (FP8 Q, with FP8 or BF16 output).
        When ``None`` (default) or ``False`` the standard cubin is used.
        Setting ``True`` for non-FP8 Q will fail kernel selection.
    sage_attn_sfs : Tuple[Optional[torch.Tensor], Optional[torch.Tensor], Optional[torch.Tensor], Optional[torch.Tensor]]
        SageAttention scale-factor tensors for the four sub-blocks ``(q_sf, k_sf, p_sf, v_sf)``.
        The outputs from :func:`trtllm_sage_attention_quantize` can be supplied as Q, K, and V scales (with ``p_sf=None``).
        Defaults to ``(None, None, None, None)`` which disables SageAttention.
        Currently only consulted by the ``trtllm-gen`` backend.
    num_elts_per_sage_attn_blk : Tuple[int, int, int, int]
        Per-block element counts for the SageAttention scale-factor tensors,
        matching the order of ``sage_attn_sfs``.  Defaults to ``(0, 0, 0, 0)``,
        which disables SageAttention.  Only consulted when ``sage_attn_sfs``
        contains non-``None`` tensors.
    backend : str
        Attention backend to use. "trtllm-gen" (default) or "cute-dsl".
    q_seq_lens_cpu : Optional[torch.Tensor]
        Optional trusted CPU mirror of the per-row query lengths. When provided
        together with ``kv_seq_lens_cpu``, the Python wrapper can detect empty
        rows (either ``q_len == 0`` or ``kv_len == 0``) without touching the
        device, which keeps the call CUDA-graph-capturable. The ``trtllm-gen``
        backend uses the mirrors to compact empty rows away before the kernel
        launch; the ``cute-dsl`` backend uses them to neutralize the rows its
        kernel skips (``q_len > 0, kv_len == 0`` rows are written as
        ``out = 0`` / ``lse = -inf`` instead of being left uninitialized).
        If omitted on the ``trtllm-gen`` backend with
        ``skip_all_rows_active_check=False``, the wrapper derives lengths
        from the device indptrs and may synchronize; this device-side detection
        is not allowed under CUDA graph capture, so both mirrors are required
        in that case. The default assumes all rows are active. If omitted
        on the ``cute-dsl`` backend, no empty-row handling is performed and
        rows with ``q_len > 0, kv_len == 0`` yield undefined output.
    kv_seq_lens_cpu : Optional[torch.Tensor]
        Optional trusted CPU mirror of the per-row KV lengths. See
        ``q_seq_lens_cpu``.
    skip_all_rows_active_check : bool
        Controls empty-row detection. ``True`` (default) assumes every row has
        positive query and KV lengths and avoids device-to-host synchronization.
        Paired CPU length mirrors take precedence and request checked/compacting
        behavior regardless of this setting. ``False`` without CPU mirrors
        derives row activity from device tensors, which may synchronize outside
        CUDA graph capture and requires CPU mirrors during capture. Only the
        ``trtllm-gen`` backend performs device-side detection when both
        mirrors are absent; on ``cute-dsl`` empty-row handling requires CPU
        mirrors regardless of this setting.

    Returns
    -------
    out: Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]
        output torch.Tensor or Tuple[torch.Tensor, torch.Tensor].
        If return_lse is True, the output will be a tuple of two tensors, the first is the output tensor, the second is the lse tensor.
        If return_lse is False, the output will be a single tensor.
    """
    check_trtllm_gen_sm107_only_feature(
        use_fp16_softmax, "use_fp16_softmax", query.device
    )
    check_trtllm_gen_sm107_only_feature(
        uses_spcompress, "uses_spcompress", query.device
    )
    is_dsr1 = query.shape[2] == 192 and key.shape[2] == 192 and value.shape[2] == 128
    is_smaller_dimensions = (
        query.shape[2] == 128 and key.shape[2] == 128 and value.shape[2] == 128
    )
    is_glm5 = query.shape[2] == 256 and key.shape[2] == 256 and value.shape[2] == 256
    assert is_dsr1 or is_smaller_dimensions or is_glm5, (
        f"Unsupported head dimensions: query={query.shape[2]}, key={key.shape[2]}, value={value.shape[2]}. "
        "Supported: (192, 192, 128) for DeepSeek-R1, (128, 128, 128), or (256, 256, 256) for GLM-5."
    )

    if enable_pdl is None:
        enable_pdl = device_support_pdl(query.device)

    # --- Output allocation (shared by all backends) ---
    if out is None:
        # FP8 inputs produce bfloat16 output by default (TRT-LLM kernels
        # do not support FP8 output for ragged attention)
        if query.dtype in (torch.float8_e4m3fn, torch.float8_e5m2, torch.int8):
            out_dtype = torch.bfloat16
        else:
            out_dtype = query.dtype
        out = torch.empty(
            query.shape[0],
            query.shape[1],
            value.shape[2],
            device=query.device,
            dtype=out_dtype,
        )
    else:
        expected_shape = (query.shape[0], query.shape[1], value.shape[2])
        if tuple(out.shape) != expected_shape:
            raise ValueError(
                f"out must have shape {expected_shape}, got {tuple(out.shape)}"
            )
        if query.dtype in (torch.float8_e4m3fn, torch.float8_e5m2) and out.dtype in (
            torch.float8_e4m3fn,
            torch.float8_e5m2,
        ):
            raise ValueError(
                "FP8 output is not supported for trtllm_ragged_attention_deepseek; "
                "use bfloat16 or float16 for out."
            )

    # --- LSE allocation (shared by all backends) ---
    if return_lse and lse is None:
        lse = torch.empty(
            query.shape[0],
            query.shape[1],
            device=query.device,
            dtype=torch.float32,
        )

    # --- CPU seq-len mirror validation (shared by all backends) ---
    def _validate_cpu_seq_lens(
        lengths: torch.Tensor,
        name: str,
        total_tokens: int,
        max_len: int,
    ) -> int:
        if lengths.device.type != "cpu":
            raise ValueError(f"{name} must be a CPU tensor")
        if lengths.dtype not in (torch.int32, torch.int64):
            raise ValueError(f"{name} must have dtype torch.int32 or torch.int64")
        if lengths.shape != (batch_size,):
            raise ValueError(f"{name} must have shape ({batch_size},)")
        if bool((lengths < 0).any().item()):
            raise ValueError(f"{name} must contain non-negative lengths")

        actual_total = int(lengths.sum().item())
        if actual_total != total_tokens:
            raise ValueError(
                f"{name} sums to {actual_total}, but expected {total_tokens} "
                "tokens from the corresponding ragged tensor"
            )
        if batch_size > 0 and int(lengths.max().item()) > max_len:
            raise ValueError(f"{name} contains a length larger than max_len")
        return actual_total

    q_lens_cpu = None
    kv_lens_cpu = None
    active_rows_cpu = None
    if q_seq_lens_cpu is not None or kv_seq_lens_cpu is not None:
        if q_seq_lens_cpu is None or kv_seq_lens_cpu is None:
            raise ValueError(
                "q_seq_lens_cpu and kv_seq_lens_cpu must be provided together"
            )

        _validate_cpu_seq_lens(
            q_seq_lens_cpu,
            "q_seq_lens_cpu",
            query.shape[0],
            max_q_len,
        )
        kv_total = _validate_cpu_seq_lens(
            kv_seq_lens_cpu,
            "kv_seq_lens_cpu",
            key.shape[0],
            max_kv_len,
        )
        if kv_total != value.shape[0]:
            raise ValueError(
                "kv_seq_lens_cpu must sum to both key and value token counts"
            )

        q_lens_cpu = q_seq_lens_cpu
        kv_lens_cpu = kv_seq_lens_cpu
        active_rows_cpu = (q_lens_cpu > 0) & (kv_lens_cpu > 0)

    if backend == "cute-dsl":
        from .attention.cute_dsl.fmha import cute_dsl_fmha_ragged_prefill

        _SUPPORTED_DTYPES = (torch.float16, torch.bfloat16, torch.float8_e4m3fn)
        assert query.dtype in _SUPPORTED_DTYPES, (
            f"cute-dsl backend only supports {_SUPPORTED_DTYPES}, got {query.dtype}"
        )
        # TODO: support device tensor scales to avoid D2H sync overhead
        assert not isinstance(bmm1_scale, torch.Tensor), (
            "cute-dsl backend does not support device tensor bmm1_scale"
        )
        assert not isinstance(bmm2_scale, torch.Tensor), (
            "cute-dsl backend does not support device tensor bmm2_scale"
        )
        assert sum(num_elts_per_sage_attn_blk) == 0, (
            "cute-dsl backend does not support sage attention scale factors"
        )
        _bmm1 = bmm1_scale
        _bmm2 = bmm2_scale

        # The DSL varlen kernel skips batches whose kv_len == 0 without
        # writing their output rows, and ``out`` defaults to torch.empty.
        # When CPU mirrors are provided, neutralize those rows here
        # (out = 0, lse = -inf) to match the trtllm-gen empty-row
        # semantics. The decisions below read only the CPU mirrors and the
        # fill itself uses only device-resident tensors (``output_size``
        # keeps repeat_interleave from syncing), so this path stays
        # CUDA-graph-capturable.
        should_launch = True
        _is_capturing = (
            query.is_cuda
            and hasattr(torch.cuda, "is_current_stream_capturing")
            and torch.cuda.is_current_stream_capturing()
        )
        if active_rows_cpu is not None:
            if not bool(active_rows_cpu.all().item()):
                if not bool(active_rows_cpu.any().item()):
                    out.zero_()
                    if lse is not None:
                        lse.fill_(-float("inf"))
                    # Skip the launch only outside CUDA graph capture.
                    # Under capture, dropping the launch would leave it
                    # unrecorded, so a later replay with active rows would
                    # find no kernel in the graph. The DSL varlen kernel
                    # is a no-op for kv_len <= 0 rows, so recording it on
                    # an all-empty batch is safe.
                    if not _is_capturing:
                        should_launch = False
                else:
                    q_lens_device = cum_seq_lens_q[1:] - cum_seq_lens_q[:-1]
                    kv_lens_device = cum_seq_lens_kv[1:] - cum_seq_lens_kv[:-1]
                    row_active = (q_lens_device > 0) & (kv_lens_device > 0)
                    token_inactive = ~torch.repeat_interleave(
                        row_active, q_lens_device, output_size=query.shape[0]
                    )
                    out.masked_fill_(token_inactive.view(-1, 1, 1), 0)
                    if lse is not None:
                        lse.masked_fill_(token_inactive.view(-1, 1), -float("inf"))
            elif _is_capturing:
                # All rows are active at capture time, but replay may
                # change device-side seq_lens so that some rows become
                # inactive (kv_len == 0). The DSL kernel would skip those
                # rows without writing their output. Pre-fill neutral
                # values so that any newly-inactive row in a replay gets
                # (out = 0, lse = -inf) rather than stale data. The
                # kernel overwrites active rows, so the fill is harmless
                # for them.
                out.zero_()
                if lse is not None:
                    lse.fill_(-float("inf"))

        # bmm1_scale = scale_q * scale_k * sm_scale (already fused by caller)
        # bmm2_scale = scale_v
        # Pass the fused value as sm_scale with scale_q=scale_k=1.0
        if should_launch:
            cute_dsl_fmha_ragged_prefill(
                q=query,
                k=key,
                v=value,
                o=out,
                qo_indptr=cum_seq_lens_q,
                kv_indptr=cum_seq_lens_kv,
                is_causal=is_causal,
                sm_scale=_bmm1,
                window_left=window_left,
                lse=lse if return_lse else None,
                attention_sinks=attention_sinks,
                scale_q=1.0,
                scale_k=1.0,
                scale_v=_bmm2,
                scale_o=1.0,
                max_qo_len=max_q_len,
                max_kv_len=max_kv_len,
                skip_softmax_threshold_scale_factor=skip_softmax_threshold_scale_factor,
                enable_pdl=enable_pdl,
            )
    else:
        # --- trtllm-gen backend ---
        run_func = get_trtllm_gen_fmha_module().trtllm_ragged_attention
        sm_count = get_device_sm_count(query.device)

        if isinstance(bmm1_scale, torch.Tensor):
            assert bmm1_scale.dtype == torch.float32
            bmm1_scale = bmm1_scale * log2e
        if isinstance(bmm2_scale, torch.Tensor):
            assert bmm2_scale.dtype == torch.float32

        run_out = out
        run_lse = lse
        run_query = query
        run_key = key
        run_value = value
        run_seq_lens = seq_lens
        run_max_q_len = max_q_len
        run_max_kv_len = max_kv_len
        run_batch_size = batch_size
        run_cum_seq_lens_q = cum_seq_lens_q
        run_cum_seq_lens_kv = cum_seq_lens_kv
        q_active_indices = None
        should_launch = True

        q_lens = None
        kv_lens = None
        active_rows = None
        has_inactive_rows = False
        has_active_rows = True

        if active_rows_cpu is not None:
            if not bool(active_rows_cpu.all().item()):
                has_inactive_rows = True
                has_active_rows = bool(active_rows_cpu.any().item())
        elif skip_all_rows_active_check:
            # The default assumes all rows have positive Q and KV lengths.
            # Keep the original tensors and avoid device-to-host row inspection.
            pass
        else:
            # An active row requires q_len > 0 AND kv_len > 0; detecting
            # either kind of empty row from device indptrs needs an
            # ``.item()`` readback, which is illegal during CUDA graph
            # capture. Callers who want compaction inside a captured region
            # must pass q_seq_lens_cpu / kv_seq_lens_cpu; without them the
            # wrapper cannot tell whether any row is empty and refuses to
            # launch rather than risk an undefined empty-row kernel path.
            if (
                query.is_cuda
                and hasattr(torch.cuda, "is_current_stream_capturing")
                and torch.cuda.is_current_stream_capturing()
            ):
                raise ValueError(
                    "q_seq_lens_cpu and kv_seq_lens_cpu must be provided during "
                    "CUDA graph capture so empty rows (q_len == 0 or "
                    "kv_len == 0) can be detected without a device sync"
                )
            q_lens = cum_seq_lens_q[1:] - cum_seq_lens_q[:-1]
            kv_lens = cum_seq_lens_kv[1:] - cum_seq_lens_kv[:-1]
            active_rows = (q_lens > 0) & (kv_lens > 0)
            has_inactive_rows = bool((~active_rows).any().item())
            if has_inactive_rows:
                has_active_rows = bool(active_rows.any().item())

        if has_inactive_rows:
            if isinstance(bmm1_scale, torch.Tensor) or isinstance(
                bmm2_scale, torch.Tensor
            ):
                raise ValueError(
                    "TRTLLM-GEN ragged attention does not support compacting "
                    "empty KV rows when bmm scale tensors are provided."
                )
            if attention_sinks is not None:
                raise ValueError(
                    "TRTLLM-GEN ragged attention does not support compacting "
                    "empty KV rows when attention sinks are provided."
                )
            if any(scale_tensor is not None for scale_tensor in sage_attn_sfs):
                raise ValueError(
                    "TRTLLM-GEN ragged attention does not support compacting "
                    "empty KV rows when SageAttention scale-factor tensors are "
                    "provided."
                )

            if not has_active_rows:
                out.zero_()
                if lse is not None:
                    lse.fill_(-float("inf"))
                should_launch = False
            else:
                if q_lens_cpu is not None:
                    assert kv_lens_cpu is not None
                    assert active_rows_cpu is not None

                    q_active_mask_cpu = torch.repeat_interleave(
                        active_rows_cpu, q_lens_cpu
                    )
                    q_inactive_indices_cpu = torch.nonzero(
                        ~q_active_mask_cpu, as_tuple=False
                    ).flatten()
                    if q_inactive_indices_cpu.numel() > 0:
                        q_inactive_indices = q_inactive_indices_cpu.to(
                            query.device, non_blocking=True
                        )
                        out.index_fill_(0, q_inactive_indices, 0)
                        if lse is not None:
                            lse.index_fill_(0, q_inactive_indices, -float("inf"))

                    active_indices_cpu = torch.nonzero(
                        active_rows_cpu, as_tuple=False
                    ).flatten()
                    kv_active_mask_cpu = torch.repeat_interleave(
                        active_rows_cpu, kv_lens_cpu
                    )
                    q_active_indices_cpu = torch.nonzero(
                        q_active_mask_cpu, as_tuple=False
                    ).flatten()
                    kv_active_indices_cpu = torch.nonzero(
                        kv_active_mask_cpu, as_tuple=False
                    ).flatten()

                    q_active_indices = q_active_indices_cpu.to(
                        query.device, non_blocking=True
                    )
                    kv_active_indices = kv_active_indices_cpu.to(
                        query.device, non_blocking=True
                    )
                    run_query = query.index_select(0, q_active_indices).contiguous()
                    run_key = key.index_select(0, kv_active_indices).contiguous()
                    run_value = value.index_select(0, kv_active_indices).contiguous()

                    run_q_lens_cpu = q_lens_cpu.index_select(0, active_indices_cpu).to(
                        dtype=cum_seq_lens_q.dtype
                    )
                    run_seq_lens_cpu = kv_lens_cpu.index_select(
                        0, active_indices_cpu
                    ).to(dtype=seq_lens.dtype)
                    run_cum_seq_lens_q_cpu = torch.cat(
                        [
                            torch.zeros(1, dtype=cum_seq_lens_q.dtype),
                            torch.cumsum(
                                run_q_lens_cpu, dim=0, dtype=cum_seq_lens_q.dtype
                            ),
                        ],
                        dim=0,
                    )
                    run_cum_seq_lens_kv_cpu = torch.cat(
                        [
                            torch.zeros(1, dtype=cum_seq_lens_kv.dtype),
                            torch.cumsum(
                                run_seq_lens_cpu.to(dtype=cum_seq_lens_kv.dtype),
                                dim=0,
                                dtype=cum_seq_lens_kv.dtype,
                            ),
                        ],
                        dim=0,
                    )

                    run_seq_lens = run_seq_lens_cpu.to(query.device, non_blocking=True)
                    run_cum_seq_lens_q = run_cum_seq_lens_q_cpu.to(
                        query.device, non_blocking=True
                    )
                    run_cum_seq_lens_kv = run_cum_seq_lens_kv_cpu.to(
                        query.device, non_blocking=True
                    )
                    run_max_q_len = int(run_q_lens_cpu.max().item())
                    run_max_kv_len = int(run_seq_lens_cpu.max().item())
                    run_batch_size = int(active_indices_cpu.numel())
                else:
                    if q_lens is None:
                        q_lens = cum_seq_lens_q[1:] - cum_seq_lens_q[:-1]
                    if kv_lens is None:
                        kv_lens = cum_seq_lens_kv[1:] - cum_seq_lens_kv[:-1]
                    assert active_rows is not None

                    q_active_mask = torch.repeat_interleave(active_rows, q_lens)
                    q_inactive_indices = torch.nonzero(
                        ~q_active_mask, as_tuple=False
                    ).flatten()
                    if q_inactive_indices.numel() > 0:
                        out.index_fill_(0, q_inactive_indices, 0)
                        if lse is not None:
                            lse.index_fill_(0, q_inactive_indices, -float("inf"))

                    active_indices = torch.nonzero(
                        active_rows, as_tuple=False
                    ).flatten()
                    kv_active_mask = torch.repeat_interleave(active_rows, kv_lens)
                    kv_active_indices = torch.nonzero(
                        kv_active_mask, as_tuple=False
                    ).flatten()
                    q_active_indices = torch.nonzero(
                        q_active_mask, as_tuple=False
                    ).flatten()

                    run_query = query.index_select(0, q_active_indices).contiguous()
                    run_key = key.index_select(0, kv_active_indices).contiguous()
                    run_value = value.index_select(0, kv_active_indices).contiguous()
                    run_seq_lens = kv_lens.index_select(0, active_indices).contiguous()
                    run_q_lens = q_lens.index_select(0, active_indices).contiguous()
                    run_cum_seq_lens_q = torch.cat(
                        [
                            torch.zeros(
                                1, device=query.device, dtype=cum_seq_lens_q.dtype
                            ),
                            torch.cumsum(run_q_lens, dim=0, dtype=cum_seq_lens_q.dtype),
                        ],
                        dim=0,
                    )
                    run_cum_seq_lens_kv = torch.cat(
                        [
                            torch.zeros(
                                1, device=query.device, dtype=cum_seq_lens_kv.dtype
                            ),
                            torch.cumsum(
                                run_seq_lens, dim=0, dtype=cum_seq_lens_kv.dtype
                            ),
                        ],
                        dim=0,
                    )
                    run_max_q_len = int(run_q_lens.max().item())
                    run_max_kv_len = int(run_seq_lens.max().item())
                    run_batch_size = int(active_indices.numel())
                run_out = torch.empty(
                    run_query.shape[0],
                    query.shape[1],
                    value.shape[2],
                    device=query.device,
                    dtype=out.dtype,
                )
                run_lse = (
                    torch.empty(
                        run_query.shape[0],
                        query.shape[1],
                        device=query.device,
                        dtype=torch.float32,
                    )
                    if lse is not None
                    else None
                )

        workspace_size = workspace_buffer.numel() * workspace_buffer.element_size()
        sage_attn_sfs_q, sage_attn_sfs_k, sage_attn_sfs_p, sage_attn_sfs_v = (
            sage_attn_sfs
        )
        num_elts_sage_q, num_elts_sage_k, num_elts_sage_p, num_elts_sage_v = (
            num_elts_per_sage_attn_blk
        )
        if should_launch:
            run_func(
                run_out,
                run_query,
                run_key,
                run_value,
                workspace_buffer,
                run_seq_lens,
                run_max_q_len,
                run_max_kv_len,
                bmm1_scale,
                bmm2_scale,
                o_sf_scale,
                run_batch_size,
                window_left,
                run_cum_seq_lens_q,
                run_cum_seq_lens_kv,
                sm_count,
                enable_pdl,
                is_causal,
                workspace_size,
                attention_sinks,
                skip_softmax_threshold_scale_factor,
                run_lse,
                use_fp16_softmax,
                uses_spcompress,
                sage_attn_sfs_q,
                sage_attn_sfs_k,
                sage_attn_sfs_p,
                sage_attn_sfs_v,
                num_elts_sage_q,
                num_elts_sage_k,
                num_elts_sage_p,
                num_elts_sage_v,
            )
            if q_active_indices is not None:
                out.index_copy_(0, q_active_indices, run_out)
                if lse is not None:
                    assert run_lse is not None
                    lse.index_copy_(0, q_active_indices, run_lse)

    if return_lse:
        assert lse is not None, (
            "lse assumed not None beyond this point when return_lse is True"
        )
        return out, lse
    else:
        return out


@flashinfer_api(trace=trtllm_batch_context_trace)
def trtllm_batch_context_with_kv_cache(
    query: torch.Tensor,
    kv_cache: Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]],
    workspace_buffer: torch.Tensor,
    block_tables: torch.Tensor,
    seq_lens: torch.Tensor,
    max_q_len: int,
    max_kv_len: int,
    bmm1_scale: Union[float, torch.Tensor],
    bmm2_scale: Union[float, torch.Tensor],
    batch_size: int,
    cum_seq_lens_q: torch.Tensor,
    cum_seq_lens_kv: torch.Tensor,
    window_left: int = -1,
    out: Optional[Union[torch.Tensor, FP4Tensor]] = None,
    out_dtype: Optional[Union[torch.dtype, str]] = None,
    o_sf_scale: Optional[float] = None,
    o_sf_vec_size: Optional[int] = None,
    kv_layout: str = "HND",
    enable_pdl: Optional[bool] = None,
    sinks: Optional[List[torch.Tensor]] = None,
    kv_cache_sf: Optional[
        Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]
    ] = None,
    skip_softmax_threshold_scale_factor: Optional[float] = None,
    uses_shared_paged_kv_idx: bool = True,
    causal: bool = True,
    lse: Optional[torch.Tensor] = None,
    return_lse: bool = False,
    multi_ctas_kv_counter_buffer: Optional[torch.Tensor] = None,
    use_fp16_softmax: Optional[bool] = None,
    uses_spcompress: Optional[bool] = None,
    backend: str = "trtllm-gen",
) -> Union[
    torch.Tensor, FP4Tensor, Tuple[Union[torch.Tensor, FP4Tensor], torch.Tensor]
]:
    """
    Parameters
    ----------
    query : torch.Tensor
        query tensor with shape [num_tokens, num_heads, head_dim]
    kv_cache : Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]
        If kv_cache is a single tensor, it should be a tensor with shape [num_pages, 1 or 2, num_kv_heads, page_size, head_dim] if :attr:`kv_layout` is "HND",
        or [num_pages, 1 or 2, page_size, num_kv_heads, head_dim] if :attr:`kv_layout` is "NHD".
        If kv_cache is a tuple of two tensors, it should be a tuple of two tensors with shape [num_pages, num_kv_heads, page_size, head_dim] if :attr:`kv_layout` is "HND",
        or [num_pages, page_size, num_kv_heads, head_dim] if :attr:`kv_layout` is "NHD".
        The first tensor is the key cache, the second tensor is the value cache.

        **Contiguity requirements (trtllm-gen backend):**

        - The ``head_dim`` (last dim) **must** have stride 1. This is a TMA hardware constraint
        - The head and batch/page dims can have arbitrary strides.
    workspace_buffer : torch.Tensor
        Workspace used for trtllm-gen softmax stats/scratch.
    block_tables : torch.Tensor
        Page table of kv cache.
        When ``uses_shared_paged_kv_idx`` is True (default): shape ``[batch_size, max_num_pages_per_seq]``.
        When ``uses_shared_paged_kv_idx`` is False: shape ``[batch_size, 2, max_num_pages_per_seq]``
        where dim 1 distinguishes K (0) and V (1) page indices.
    seq_lens : torch.Tensor
        A uint32 1D tensor indicating the kv sequence length of each prompt. shape: ``[batch_size]``
    max_q_len : int
        max sequence length for query
    max_kv_len : int
        max sequence length for kv_cache
    bmm1_scale : Union[float, torch.Tensor]
        fused scale for bmm1 input.
        when using trtllm-gen backend, it can be a torch.Tensor with dtype torch.float32.
    bmm2_scale : Union[float, torch.Tensor]
        fused scale for bmm2 input.
        when using trtllm-gen backend, it can be a torch.Tensor with dtype torch.float32.
    batch_size : int
        batch size
    cum_seq_lens_q : torch.Tensor
        cumulative sequence length for query. shape: ``[batch_size + 1]``
    cum_seq_lens_kv : torch.Tensor
        cumulative sequence length for kv_cache. shape: ``[batch_size + 1]``
    window_left : int = -1
        The left (inclusive) window size for the attention window, when set to ``-1``, the window
        size will be set to the full length of the sequence. Defaults to ``-1``.
    out : Optional[Union[torch.Tensor, FP4Tensor]] = None
        output tensor, if not provided, will be allocated with ``out_dtype``, if ``out_dtype`` is not provided, will use the type of ``query``.
    out_dtype : Optional[Union[torch.dtype, str]] = None
        output dtype, if not provided, will use the type of ``out``. For nvfp4, use string ``nvfp4``.
    o_sf_scale : Optional[float] = None
        scale for nvfp4 output tensor scale factor.
    o_sf_vec_size : Optional[int] = None
        vector size for nvfp4 output tensor scale factor.
    enable_pdl : Optional[bool] = None
        Whether to enable Programmatic Dependent Launch (PDL). See https://docs.nvidia.com/cuda/cuda-c-programming-guide/#programmatic-dependent-launch-and-synchronization
        Defaults to ``None``, which means it will be enabled if the device supports PDL.
    kv_layout : str = "HND"
        Layout of kv-cache, can be "HND" or "NHD", default is "HND".
        For the trtllm-gen backend with NVFP4 KV cache, using ``NHD`` will trigger an
        automatic transpose and ``.contiguous()`` copy of both the KV data and block scale
        tensors to convert them to HND layout. This incurs extra memory allocation and
        data copy overhead. Use ``HND`` for better performance.
    sinks : Optional[List[torch.Tensor]] = None
        additional value per head in the denominator of the softmax.
    kv_cache_sf : Optional[Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]] = None
        Per-block scale factors for NVFP4 KV cache. Accepts the same formats as
        ``kv_cache``:

        * a tuple ``(k_scales, v_scales)`` of 4-D tensors, each following
          :attr:`kv_layout`: ``[num_pages, num_kv_heads, page_size, head_dim // 16]`` for
          HND, or ``[num_pages, page_size, num_kv_heads, head_dim // 16]`` for NHD.
        * a single 5-D tensor with shape ``[num_pages, 2, ...]`` matching the layout of
          ``kv_cache``, split on dim 1 to yield k (index 0) and v (index 1) scales.

        Both tensors have dtype ``torch.float8_e4m3fn``. ``k_scales`` uses a linear
        (row-major) layout, while ``v_scales`` must use TRT-LLM's 4-token interleaved
        layout within each ``[page_size, head_dim // 16]`` tile. Use
        :func:`flashinfer.fp4_quantization.nvfp4_quantize_paged_kv_cache` to produce
        correctly formatted scale factors.

        When :attr:`kv_layout` is ``NHD``, scale tensors are transposed to HND internally
        (incurring a ``.contiguous()`` copy). Use ``HND`` for better performance.

        **Contiguity requirements (trtllm-gen backend):**

        - The last two dims (``page_size``, ``head_dim // 16``) **must** be contiguous
          (i.e., ``stride[-1] == 1`` and ``stride[-2] == head_dim // 16``). This is because
          the kernel reshapes them into ``(16, page_size * head_dim / 16 / 16)`` to satisfy
          TMA's 16-byte box width minimum.
        - The head and batch/page dims can have arbitrary strides.
    skip_softmax_threshold_scale_factor: Optional[float] = None
        threshold scale factor for skipping softmax operations.
        Providing a value for this parameter enables skip-softmax sparsity as described in: https://arxiv.org/abs/2512.12087
        If no value is provided, then standard attention is used.
        Setting the threshold to a higher value generally increases kernel performance at the cost of accuracy degradation.
        The actual threshold value equals the provided threshold_scale_factor divided by the context length.
    uses_shared_paged_kv_idx : bool = True
        Whether the K and V page indices are shared as a unified index.
        True (default) uses vLLM/FlashInfer layout with a 2D page table.
        False uses TRT-LLM layout with a 3D page table ``[batch_size, 2, max_num_pages_per_seq]``.
    use_fp16_softmax : Optional[bool] = None
        Select the ``…Fp16Softmax…`` cubin variant (FP16 softmax accumulator).
        Currently only shipped for BF16 Q/KV/O kernels.
    uses_spcompress : Optional[bool] = None
        Select the ``…Spcomp…`` cubin variant (sparse compression).
        Currently only shipped for FP8 Q kernels.
    causal : bool = True
        Whether to apply a causal mask. Set to ``False`` to request dense / bidirectional
        attention. For the TRTLLM-gen paged context path, non-causal currently requires
        ``window_left == -1``.
    lse : Optional[torch.Tensor] = None
        Optional pre-allocated buffer for Log-Sum-Exp values. Must have shape
        ``[num_tokens, num_qo_heads]`` with dtype ``torch.float32``. If provided,
        the tensor is filled regardless of :attr:`return_lse`. If ``return_lse`` is
        True and this is None, a buffer will be allocated.
    return_lse : bool = False
        Whether to return Log-Sum-Exp values. When True, returns ``(out, lse)``.
    multi_ctas_kv_counter_buffer : Optional[torch.Tensor] = None
        Optional separate trtllm-gen multi-CTA KV counter buffer. If not provided,
        FlashInfer creates a fresh zeroed internal buffer. When provided, it must be
        zero-initialized at allocation (e.g. via ``torch.zeros``); the kernel
        self-resets the counters after each launch, so it does not need to be
        re-zeroed between calls.
    backend : str = "trtllm-gen"
        The implementation backend, either ``trtllm-gen`` or ``cake``. ``cake``
        selects the separately versioned Cake FMHA product. The default remains
        the conventional TRTLLM implementation.
    Returns
    -------
    out: Union[torch.Tensor, FP4Tensor]
        output torch.Tensor or FP4Tensor.
    lse : torch.Tensor, optional
        Only returned when ``return_lse`` is True. Shape
        ``[num_tokens, num_qo_heads]`` with dtype ``torch.float32``.
    """

    check_trtllm_gen_sm107_only_feature(
        use_fp16_softmax, "use_fp16_softmax", query.device
    )
    check_trtllm_gen_sm107_only_feature(
        uses_spcompress, "uses_spcompress", query.device
    )
    if enable_pdl is None:
        enable_pdl = device_support_pdl(query.device)
    if backend not in ("trtllm-gen", "cake"):
        raise ValueError(
            "trtllm_batch_context_with_kv_cache backend must be 'trtllm-gen' or 'cake'"
        )
    if not causal and window_left >= 0:
        raise NotImplementedError(
            "Sliding-window non-causal attention is not supported for trtllm-gen paged KV cache. "
            "Use window_left=-1 for dense bidirectional attention."
        )

    if isinstance(kv_cache, tuple):
        k_cache, v_cache = kv_cache
    else:
        if kv_cache.shape[1] == 1:
            k_cache, v_cache = kv_cache, kv_cache
        else:
            assert kv_cache.shape[1] == 2, (
                "When kv_cache is a single tensor, the second dimension must be 1 or 2"
            )
            # NOTE(Zihao): unbind transforms [num_pages, 2, ...] to ([num_pages, ...], [num_pages, ...])
            # it doesn't change underlying storage
            k_cache, v_cache = kv_cache.unbind(dim=1)

    if k_cache.dtype == torch.uint8 or v_cache.dtype == torch.uint8:
        if kv_cache_sf is None:
            raise ValueError("kv_cache_sf must be provided for NVFP4 KV cache.")
    key_block_scales, value_block_scales = (
        _unpack_paged_kv_cache(kv_cache_sf, kv_layout)
        if kv_cache_sf is not None
        else (None, None)
    )

    # Convert NHD layout to HND if necessary
    if kv_layout == "NHD":
        k_cache = k_cache.transpose(-3, -2)
        v_cache = v_cache.transpose(-3, -2)
        if key_block_scales is not None:
            print(
                "[WARNING] NVFP4 KV cache with NHD layout will be converted to HND, "
                "incurring extra transpose and contiguous copy overhead. "
                "Use kv_layout='HND' for better performance."
            )
            k_cache = k_cache.contiguous()
            v_cache = v_cache.contiguous()
            key_block_scales = key_block_scales.transpose(-3, -2).contiguous()
            value_block_scales = value_block_scales.transpose(-3, -2).contiguous()

    if backend != "cake":
        run_func = get_trtllm_gen_fmha_module().trtllm_paged_attention_context
    sm_count = get_device_sm_count(query.device)

    if out_dtype == "nvfp4" or (out_dtype is None and isinstance(out, FP4Tensor)):
        assert query.dtype == torch.float8_e4m3fn, (
            "query must be fp8 when out_dtype is nvfp4."
        )
        assert o_sf_scale is not None
        assert o_sf_vec_size in [None, 16], "only o_sf_vec_size = 16 is supported"
        o_sf_vec_size = o_sf_vec_size or 16

        fp4_out_shape = query.shape[:-1] + (ceil_div(query.shape[-1], 2),)

        if isinstance(out, FP4Tensor):
            fp4_out_scale_shape = (
                out.scale.shape[0],
                round_up(query.shape[1] * query.shape[2] // o_sf_vec_size, 4),
            )
            out_scale_factor = out.scale
            o_sf_start_index = out.scale_start_index
            out = out.data
            # out_dtype may be None
            out_dtype = out_dtype or "nvfp4"
        elif out is None:
            fp4_out_scale_shape = (
                round_up(query.shape[0], 128),
                round_up(query.shape[1] * query.shape[2] // o_sf_vec_size, 4),
            )
            out_scale_factor = torch.empty(
                fp4_out_scale_shape, dtype=torch.float8_e4m3fn, device=query.device
            )
            o_sf_start_index = 0
            out = torch.empty(fp4_out_shape, dtype=torch.uint8, device=query.device)
        else:
            raise ValueError(f"Invalid out: {out}")

        assert out_dtype == "nvfp4"
        assert isinstance(out, torch.Tensor)

        # Use uint8 as the container dtype to compliant with next fp4 gemm.
        check_shape_dtype_device(out, fp4_out_shape, torch.uint8, query.device, "out")

        check_shape_dtype_device(
            out_scale_factor,
            fp4_out_scale_shape,
            torch.float8_e4m3fn,
            query.device,
            "out_scale_factor",
        )

        # Check o_sf_start_index is valid
        if (
            o_sf_start_index < 0
            or o_sf_start_index + out.shape[0] > out_scale_factor.shape[0]
        ):
            raise ValueError(
                f"o_sf_start_index is out of the valid range of out_scale_factor. "
                f"o_sf_start_index={o_sf_start_index}, out.shape[0]={out.shape[0]}, "
                f"out_scale_factor.shape[0]={out_scale_factor.shape[0]}"
            )

    elif isinstance(out_dtype, torch.dtype) or out_dtype is None:
        assert o_sf_scale is None
        assert o_sf_vec_size is None
        out_scale_factor = None
        o_sf_start_index = 0
        if out_dtype is None:
            out_dtype = out.dtype if out is not None else query.dtype
        out = out if out is not None else torch.empty_like(query, dtype=out_dtype)
        if out_dtype not in (query.dtype, torch.float16, torch.bfloat16):
            raise ValueError(f"Unsupported out_dtype: {out_dtype}")
        check_shape_dtype_device(out, query.shape, out_dtype, query.device, "out")
    else:
        raise ValueError(f"Invalid out_dtype: {out_dtype}")

    if isinstance(bmm1_scale, torch.Tensor):
        assert bmm1_scale.dtype == torch.float32
        bmm1_scale = bmm1_scale * log2e
    if isinstance(bmm2_scale, torch.Tensor):
        assert bmm2_scale.dtype == torch.float32
    _check_block_tables_shape(block_tables, uses_shared_paged_kv_idx)
    workspace_size = workspace_buffer.numel() * workspace_buffer.element_size()

    num_qo_heads = query.size(1)
    multi_ctas_kv_counter_buffer = _resolve_trtllm_gen_multi_ctas_kv_counter_buffer(
        multi_ctas_kv_counter_buffer,
        batch_size,
        num_qo_heads,
        sm_count,
        query.device,
    )
    lse_shape = (query.size(0), num_qo_heads)
    if lse is not None:
        check_shape_dtype_device(lse, lse_shape, torch.float32, query.device, "lse")
        lse_stride_tokens = lse.stride(0)
        lse_stride_heads = lse.stride(1)
    elif return_lse:
        lse = torch.empty(lse_shape, dtype=torch.float32, device=query.device)
        lse_stride_tokens = lse.stride(0)
        lse_stride_heads = lse.stride(1)
    else:
        lse_stride_tokens = 0
        lse_stride_heads = 0

    if backend == "cake":
        from .cake_fmha import (
            get_cake_fmha_context_module,
            select_cake_fmha_context_route,
        )

        cake_route = select_cake_fmha_context_route(
            query.device,
            query=query,
            key_cache=k_cache,
            value_cache=v_cache,
            out=out,
            block_tables=block_tables,
            seq_lens=seq_lens,
            batch_size=batch_size,
            max_q_len=max_q_len,
            max_kv_len=max_kv_len,
            window_left=window_left,
            bmm1_scale=bmm1_scale,
            bmm2_scale=bmm2_scale,
            sinks=sinks,
            uses_shared_paged_kv_idx=uses_shared_paged_kv_idx,
            cum_seq_lens_q=cum_seq_lens_q,
            cum_seq_lens_kv=cum_seq_lens_kv,
            key_block_scales=key_block_scales,
            value_block_scales=value_block_scales,
            skip_softmax_threshold_scale_factor=(skip_softmax_threshold_scale_factor),
            is_causal=causal,
            lse=lse,
            kv_layout=kv_layout,
            workspace_buffer=workspace_buffer,
        )
        if skip_softmax_threshold_scale_factor == 1e-30:
            # The pinned public matrix uses 1e-30 as a numerically inert
            # skip-softmax probe. Both exact routes and compat_v1 consume the
            # disabled form at the FFI boundary.
            skip_softmax_threshold_scale_factor = None
        # All context adapters consume host scalar scales. Device scalar
        # values are resolved only after exact route selection, preserving
        # their public value while converting bmm1 back from log2 form.
        if isinstance(bmm1_scale, torch.Tensor):
            bmm1_scale = float(bmm1_scale.item()) / log2e
        if isinstance(bmm2_scale, torch.Tensor):
            bmm2_scale = float(bmm2_scale.item())
        run_func = get_cake_fmha_context_module(
            query.device, cake_route
        ).cake_paged_attention_context

    run_args = [
        out,
        out_scale_factor,
        query,
        k_cache,
        v_cache,
        workspace_buffer,
        multi_ctas_kv_counter_buffer,
        block_tables,
        seq_lens,
        max_q_len,
        max_kv_len,
        bmm1_scale,
        bmm2_scale,
        o_sf_scale or -1.0,
        o_sf_vec_size or -1,
        o_sf_start_index,
        batch_size,
        window_left,
        cum_seq_lens_q,
        cum_seq_lens_kv,
        sm_count,
        enable_pdl,
        workspace_size,
        sinks,
        key_block_scales,
        value_block_scales,
        skip_softmax_threshold_scale_factor,
        uses_shared_paged_kv_idx,
        use_fp16_softmax,
        uses_spcompress,
        causal,
        lse,
    ]
    if backend != "cake":
        run_args.append(1.0)  # lse_scale
    run_args.extend((lse_stride_tokens, lse_stride_heads))
    run_func(*run_args)
    result_out = (
        out
        if out_dtype != "nvfp4"
        else FP4Tensor(out, out_scale_factor, o_sf_start_index, query.shape)
    )
    if return_lse:
        return result_out, lse
    return result_out


@functools.cache
def get_trtllm_fmha_v2_sm120_module():
    return gen_trtllm_fmha_v2_sm120_module().build_and_load()


def _fmha_v2_prefill_sm120_run(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    out: torch.Tensor,
    num_heads: int,
    head_dim: int,
    seq_len: int,
    scale_softmax: float,
    scale_bmm1: Optional[float],
    scale_bmm2: Optional[float],
    causal: bool,
    return_lse: bool,
    lse: Optional[torch.Tensor],
    scale_bmm1_d: Optional[torch.Tensor],
    scale_bmm2_d: Optional[torch.Tensor],
) -> Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
    module = get_trtllm_fmha_v2_sm120_module()
    is_e4m3 = query.dtype == torch.float8_e4m3fn
    is_bf16_output = out.dtype == torch.bfloat16
    scale_softmax = (
        scale_softmax if scale_softmax is not None else 1.0 if is_e4m3 else 0.0
    )
    scale_bmm1 = scale_bmm1 if scale_bmm1 is not None else 1.0
    scale_bmm2 = scale_bmm2 if scale_bmm2 is not None else 1.0
    for name, device_scale in (
        ("scale_bmm1_d", scale_bmm1_d),
        ("scale_bmm2_d", scale_bmm2_d),
    ):
        if not is_e4m3 and device_scale is not None:
            raise ValueError(f"{name} is only valid for FP8 E4M3 input.")
        if device_scale is not None and (
            device_scale.shape != (1,)
            or device_scale.dtype != torch.float32
            or device_scale.device != query.device
            or not device_scale.is_contiguous()
        ):
            raise ValueError(
                f"{name} must be a contiguous FP32 CUDA tensor with shape [1] "
                "on the query device."
            )
    module.run(
        query,
        key,
        value,
        out,
        lse,
        scale_bmm1_d,
        scale_bmm2_d,
        num_heads,
        head_dim,
        seq_len,
        scale_softmax,
        scale_bmm1,
        scale_bmm2,
        causal,
        is_e4m3,
        is_bf16_output,
    )
    if return_lse:
        return out, lse
    return out


@flashinfer_api(trace=fmha_v2_prefill_sm120_trace)
def fmha_v2_prefill_sm120(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    out: torch.Tensor,
    num_heads: int,
    head_dim: int,
    seq_len: int,
    scale_softmax: float,
    scale_bmm1: Optional[float] = None,
    scale_bmm2: Optional[float] = None,
    causal: bool = True,
    return_lse: bool = False,
    lse: Optional[torch.Tensor] = None,
    scale_bmm1_d: Optional[torch.Tensor] = None,
    scale_bmm2_d: Optional[torch.Tensor] = None,
) -> Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
    """Run SM120 FMHA v2 with contiguous, separate Q/K/V tensors.

    Supports FP8 E4M3 standard MHA self-attention with equal Q/K/V head counts
    and head dimensions of 64 or 128, and BF16 output. GQA and MQA are not
    supported by this entry point. ``scale_bmm1`` combines the Q and K
    dequantization scales with the attention scale; ``scale_bmm2`` is the V
    dequantization scale. Set ``causal=False`` for dense / bidirectional
    attention. Q/K/V/O use fixed-shape ``[batch, seq_len, heads, head_dim]``
    storage, so every batch item has the same sequence length. Use
    :func:`trtllm_fmha_v2_prefill` for ragged inputs.
    FP8 calls may pass ``scale_bmm1_d`` and ``scale_bmm2_d`` as persistent
    one-element FP32 CUDA model weights. ``scale_bmm1_d`` replaces
    ``scale_bmm1`` and must contain the full fused
    ``q_scale * k_scale / sqrt(head_dim)`` value; ``scale_bmm2_d`` replaces
    ``scale_bmm2`` and contains the V dequantization scale. If either is
    omitted, the kernel uses the corresponding host-encoded scale.

    This entry point is validated for SM120 and SM121.

    Parameters
    ----------
    query, key, value : torch.Tensor
        Contiguous FP8 E4M3 Q, K, and V tensors in BSHD layout.
    out : torch.Tensor
        Caller-owned contiguous BF16 output tensor in BSHD layout.
    num_heads, head_dim, seq_len : int
        Fixed attention geometry shared by every batch item.
    scale_softmax : float
        Softmax scale passed to the FMHA kernel.
    scale_bmm1, scale_bmm2 : float, optional
        Host-encoded QK and V dequantization scales.
    causal : bool
        Apply bottom-right causal masking when true.
    return_lse : bool
        Return the log-sum-exp tensor together with ``out``.
    lse : torch.Tensor, optional
        Caller-owned contiguous FP32 ``[B, S, H, 2]`` LSE tensor.
    scale_bmm1_d, scale_bmm2_d : torch.Tensor, optional
        Persistent one-element FP32 CUDA scale tensors overriding host scales.
    """
    if not is_sm12x_supported(query.device) or get_compute_capability(
        query.device
    ) not in ((12, 0), (12, 1)):
        raise ValueError("fmha_v2_prefill_sm120 is only supported on SM120/SM121 GPUs.")
    if query.ndim != 4 or key.ndim != 4 or value.ndim != 4 or out.ndim != 4:
        raise ValueError("query, key, value, and out must be 4D BSHD tensors.")
    if query.dtype != torch.float8_e4m3fn:
        raise ValueError("standard SM120 self-attention requires FP8 E4M3 input.")
    if key.dtype != query.dtype or value.dtype != query.dtype:
        raise ValueError("query, key, and value must have the same dtype.")
    if not all(t.device == query.device for t in (key, value, out)):
        raise ValueError("query, key, value, and out must be on the same device.")
    expected_prefix = (query.shape[0], seq_len, num_heads)
    if (
        query.shape[:3] != expected_prefix
        or key.shape[:3] != expected_prefix
        or value.shape[:3] != expected_prefix
        or out.shape[:3] != expected_prefix
    ):
        raise ValueError("tensor shapes must match batch, seq_len, and num_heads.")
    if (
        head_dim not in (64, 128)
        or query.shape[3] != head_dim
        or key.shape[3] != head_dim
    ):
        raise ValueError(
            "standard SM120 self-attention requires Q/K head_dim=64 or 128."
        )
    if value.shape[3] != head_dim or out.shape[3] != head_dim:
        raise ValueError(
            "standard SM120 self-attention requires V/O head_dim to match Q/K."
        )
    if out.dtype != torch.bfloat16:
        raise ValueError("standard SM120 self-attention requires BF16 output.")
    if not all(t.is_contiguous() for t in (query, key, value, out)):
        raise ValueError("query, key, value, and out must be contiguous.")
    if return_lse and lse is None:
        raise ValueError("lse must be provided when return_lse=True.")
    if lse is not None and (
        lse.shape != (*expected_prefix, 2)
        or lse.dtype != torch.float32
        or lse.device != query.device
        or not lse.is_contiguous()
    ):
        raise ValueError("lse must be a contiguous FP32 [B, S, H, 2] tensor.")
    return _fmha_v2_prefill_sm120_run(
        query,
        key,
        value,
        out,
        num_heads,
        head_dim,
        seq_len,
        scale_softmax,
        scale_bmm1,
        scale_bmm2,
        causal,
        return_lse,
        lse,
        scale_bmm1_d,
        scale_bmm2_d,
    )


@flashinfer_api(trace=fmha_v2_prefill_deepseek_trace)
def fmha_v2_prefill_deepseek(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    out: torch.Tensor,
    num_heads: int,
    head_dim: int,
    seq_len: int,
    scale_softmax: float,
    scale_bmm1: Optional[float] = None,
    scale_bmm2: Optional[float] = None,
    return_lse: bool = False,
    lse: Optional[torch.Tensor] = None,
    scale_bmm1_d: Optional[torch.Tensor] = None,
    scale_bmm2_d: Optional[torch.Tensor] = None,
) -> Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
    """
    Parameters
    ----------
    query : torch.Tensor
        query tensor with shape [batch_size, seq_len, num_heads, head_dim]
    key : torch.Tensor
        key tensor with shape [batch_size, seq_len, num_heads, head_dim]
    value : torch.Tensor
        value tensor with shape [batch_size, seq_len, num_heads, head_dim]
    out : torch.Tensor
        output tensor with shape [batch_size, seq_len, num_heads, head_dim]
    return_lse : bool
        whether to return the log-sum-exp of attention output
    num_heads : int
        number of heads
    head_dim : int
        head dimension
    seq_len : int
        sequence length
    scale_softmax : float
        scale for softmax
    scale_bmm1 : Optional[float]
        scale for bmm1
    scale_bmm2 : Optional[float]
        scale for bmm2
    lse : Optional[torch.Tensor]
        log-sum-exp of attention output
    scale_bmm1_d : Optional[torch.Tensor]
        Optional persistent one-element FP32 CUDA model weight containing the
        FP8 QK scale. The host ``scale_bmm1`` value is used when omitted.
    scale_bmm2_d : Optional[torch.Tensor]
        Optional persistent one-element FP32 CUDA model weight containing the
        FP8 V dequantization scale. The host ``scale_bmm2`` value is used when
        this is omitted.
    Returns
    -------
    out: Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]
        output torch.Tensor or Tuple[torch.Tensor, torch.Tensor].
        If return_lse is True, the output will be a tuple of two tensors, the first is the output tensor, the second is the lse tensor.
        If return_lse is False, the output will be a single tensor.
    """
    if not is_sm12x_supported(query.device):
        raise ValueError("fmha_v2_prefill_deepseek is only supported on SM12x GPUs.")
    if query.shape[1] != seq_len:
        raise ValueError("query sequence length must match seq_len.")
    if return_lse and lse is None:
        raise ValueError("lse must be provided when return_lse=True.")
    assert query.shape[3] == 192 and key.shape[3] == 192 and value.shape[3] == 128, (
        "currently only support deepseek r1 192 query and 128 value"
    )
    return _fmha_v2_prefill_sm120_run(
        query,
        key,
        value,
        out,
        num_heads,
        head_dim,
        seq_len,
        scale_softmax,
        scale_bmm1,
        scale_bmm2,
        causal=True,
        return_lse=return_lse,
        lse=lse,
        scale_bmm1_d=scale_bmm1_d,
        scale_bmm2_d=scale_bmm2_d,
    )


@functools.cache
def get_trtllm_fmha_v2_module(
    input_layout: str, input_dtype: torch.dtype, output_dtype: torch.dtype = None
):
    return gen_fmha_v2_module(input_layout, input_dtype, output_dtype).build_and_load()


def _check_paged_kv_non_interleaved(
    k_cache: torch.Tensor, v_cache: torch.Tensor, block_tables: Optional[torch.Tensor]
) -> None:
    """Validate the separate-K/V paged input form.

    The kernel addresses every block relative to ``k_cache``'s base pointer
    with strides derived from shapes (never from tensor strides), so the
    caller must supply contiguous same-shape caches whose V storage sits at a
    positive block-aligned offset from K (one allocation), plus pre-expanded
    ``[B, 2, M]`` block offsets whose V rows account for that offset (e.g.
    ``page_idx + delta_blocks``).
    """
    if block_tables is None or block_tables.dim() != 3 or block_tables.shape[1] != 2:
        raise ValueError(
            "Non-interleaved paged KV (separate k_cache/v_cache tensors) requires "
            "pre-expanded block_tables of shape [B, 2, M] with independent K and V "
            f"block offsets; got {None if block_tables is None else tuple(block_tables.shape)}."
        )
    if (
        k_cache.dim() != 4
        or k_cache.shape != v_cache.shape
        or k_cache.dtype != v_cache.dtype
    ):
        raise ValueError(
            "Non-interleaved paged KV expects 4D k_cache/v_cache with identical shape "
            f"and dtype; got {tuple(k_cache.shape)}/{k_cache.dtype} vs "
            f"{tuple(v_cache.shape)}/{v_cache.dtype}."
        )
    if not (k_cache.is_contiguous() and v_cache.is_contiguous()):
        raise ValueError(
            "Non-interleaved paged KV requires contiguous k_cache/v_cache: the kernel "
            "derives strides from shapes, not tensor strides."
        )
    block_bytes = k_cache[0].numel() * k_cache.element_size()
    delta_bytes = v_cache.data_ptr() - k_cache.data_ptr()
    if delta_bytes <= 0 or delta_bytes % block_bytes != 0:
        raise ValueError(
            "Non-interleaved paged KV requires V stored at a positive block-aligned "
            f"offset from K in one allocation (v_ptr - k_ptr = {delta_bytes} "
            f"bytes, block = {block_bytes} bytes). Pass a stacked [pages, 2, ...]"
            "tensor instead of independently allocated K and V."
        )


def _check_paged_block_tables(block_tables: Optional[torch.Tensor]) -> None:
    if block_tables is not None and block_tables.dtype != torch.int32:
        raise ValueError(f"block_tables must be int32, got {block_tables.dtype}.")


@flashinfer_api(trace=trtllm_fmha_v2_prefill_trace)
def trtllm_fmha_v2_prefill(
    qkv: Union[
        torch.Tensor,
        Tuple[torch.Tensor, torch.Tensor],
        Tuple[torch.Tensor, torch.Tensor, torch.Tensor],
    ],
    input_layout: str,
    workspace_buffer: torch.Tensor,
    seq_lens: torch.Tensor,
    max_q_len: int,
    max_kv_len: int,
    bmm1_scale: float,
    bmm2_scale: float,
    batch_size: int,
    cum_seq_lens_q: torch.Tensor,
    cum_seq_lens_kv: torch.Tensor,
    block_tables: Optional[torch.Tensor] = None,
    out: Optional[torch.Tensor] = None,
    out_dtype: Optional[Union[torch.dtype, str]] = None,
    sinks: Optional[List[torch.Tensor]] = None,
    pos_encoding_mode: str = None,
    logits_soft_cap_scale: Optional[float] = None,
    mask_mode: str = "causal",
    window_left: int = -1,
    chunked_attention_size: int = 0,
    save_softmax_stats: bool = False,
    skip_softmax_threshold_scale_factor: float = 0,
) -> Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
    r"""TRT-LLM FMHAv2 prefill attention.

    Parameters
    ----------
    qkv
        Query/key/value input; expected format is determined by :attr:`input_layout`.
    input_layout
        Specifies the layout of the query/key/value tensors:
        - ``PACKED_QKV``: ``qkv`` is a single tensor of shape
          ``[num_tokens, 3, num_heads, head_dim]``.
        - ``CONTIGUOUS_Q_KV``: ``qkv`` is ``(Q, KV)`` where Q has shape
          ``[num_tokens, num_heads, head_dim]`` and KV has shape
          ``[num_tokens, 2, num_kv_heads, head_dim]``
          (``KV[:, 0, ...]`` is key, ``KV[:, 1, ...]`` is value).
        - ``Q_PAGED_KV_HND``: ``qkv`` is ``(Q, paged_KV)`` where Q has shape
          ``[num_tokens, num_heads, head_dim]`` and paged_KV has shape
          ``[num_pages, 2, num_kv_heads, page_size, head_dim]``
          (``paged_KV[:, 0, ...]`` is key cache, ``paged_KV[:, 1, ...]`` is value cache).
        - ``Q_PAGED_KV_NHD``: same as ``Q_PAGED_KV_HND`` but paged_KV shape is
          ``[num_pages, 2, page_size, num_kv_heads, head_dim]``.

          For both paged layouts, ``paged_KV`` may instead be a tuple
          ``(k_cache, v_cache)`` of separate 4D tensors (non-interleaved). This
          requires pre-expanded ``block_tables`` of shape ``[B, 2, M]`` holding
          independent K and V block offsets relative to ``k_cache``'s base
          pointer (K and V must live in one allocation at block-aligned
          positions).
        - ``SEPARATE_Q_K_V``: ``qkv`` is ``(Q, K, V)`` where Q has shape
          ``[num_tokens, num_heads, head_dim]`` and K, V have shape
          ``[num_tokens, num_kv_heads, head_dim]``.
    workspace_buffer
        The workspace buffer used for trtllm-gen softmax stats/scratch.
    seq_lens
        The KV sequence length of each request, shape: ``[batch_size]``.
    max_q_len
        The maximum sequence length for query.
    max_kv_len
        The maximum sequence length for KV cache.
    bmm1_scale
        The fused scale for BMM1 (QK^T) computation.
    bmm2_scale
        The fused scale for BMM2 (softmax(QK^T) * V) computation.
    batch_size
        The batch size.
    cum_seq_lens_q
        The cumulative sequence lengths for query, shape: ``[batch_size + 1]``.
    cum_seq_lens_kv
        The cumulative sequence lengths for KV cache, shape: ``[batch_size + 1]``.
    block_tables
        The page table mapping each sequence to its KV cache pages. Required
        for the paged KV layouts. Its expected shape depends on the form of
        the paged KV data tensor passed in ``qkv``
        - Stacked pool (single 5D ``paged_KV`` tensor): shape
          ``[batch_size, max_num_pages_per_seq]`` of logical page indices,
          each shared by K and V of that page.
        - Separate ``(k_cache, v_cache)`` tensors: pre-expanded shape
          ``[batch_size, 2, max_num_pages_per_seq]``, where ``[:, 0, :]``
          holds K block offsets and ``[:, 1, :]`` holds V block offsets,
          both relative to ``k_cache``'s base pointer in units of blocks.
    out
        The output tensor. If not provided, will be allocated with ``out_dtype``.
        If ``out_dtype`` is also not provided, will use the dtype of query.
    out_dtype
        The output dtype. If not provided, will use the dtype of ``out`` or query.
    sinks
        Additional value per head in the denominator of the softmax.
    pos_encoding_mode
        The position encoding mode, could be ``alibi``. Defaults to ``None``.
    logits_soft_cap_scale
        The logits soft cap scale. Defaults to ``None``, which means no soft cap.
    mask_mode
        The mask mode, could be ``causal``, ``sliding_window``, or ``chunked``.
        Defaults to ``causal``.
    window_left
        The left (inclusive) window size for the attention window, when set to ``-1``,
        the window size will be set to the full length of the sequence. Defaults to ``-1``.
        Only effective when :attr:`mask_mode` is ``sliding_window``.
    chunked_attention_size
        The chunked attention size. Defaults to ``0``, which means no chunked attention.
        Only effective when :attr:`mask_mode` is ``chunked``. Must be a power of 2.
        Chunked-causal masking is implemented only by the warp-specialized SM90
        (Hopper) kernels; it is **not supported on SM120 (Blackwell)**, where the
        tiled kernels honor sliding-window causal (``window_left``) only.
    save_softmax_stats
        Whether to save the softmax statistics. Defaults to ``False``.
    skip_softmax_threshold_scale_factor
        The factor of skip-softmax (Sparse Attention),
        Skip softmax and BMM2 when exp(local_max - global_max) < threshold,
        where threshold = skip_softmax_threshold_scale_factor / seqlen.
        Defaults to ``0`` (disabled).
    Returns
    -------
        If :attr:`save_softmax_stats` is ``False``, the attention output tensor.
        If :attr:`save_softmax_stats` is ``True``, a tuple of two tensors:
        * The attention output tensor.
        * The softmax statistics tensor (LSE).
    """

    if input_layout == "PACKED_QKV":
        assert isinstance(qkv, torch.Tensor)
        if qkv.dim() != 4 or qkv.shape[1] != 3:
            raise ValueError(
                f"PACKED_QKV expects shape [tokens, 3, num_heads, head_dim], got {tuple(qkv.shape)}"
            )
        query = qkv
        k_cache, v_cache = qkv, qkv  # placeholders
    elif input_layout == "CONTIGUOUS_Q_KV":
        assert isinstance(qkv, tuple)
        query, kv_cache = qkv[0], qkv[1]
        if kv_cache.dim() != 4 or kv_cache.shape[1] != 2:
            raise ValueError(
                f"CONTIGUOUS_Q_KV expects KV shape [tokens, 2, num_kv_heads, head_dim], got {tuple(kv_cache.shape)}"
            )
        k_cache = kv_cache
        v_cache = kv_cache  # placeholder (not used for this layout)
    elif input_layout in ("Q_PAGED_KV_NHD", "Q_PAGED_KV_HND"):
        assert isinstance(qkv, tuple)
        query, paged_kv = qkv[0], qkv[1]
        _check_paged_block_tables(block_tables)
        if block_tables is None:
            # The kernel dereferences the block-offsets pointer unconditionally
            # for paged layouts; there is no contiguous fallback.
            raise ValueError(
                f"block_tables is required for the {input_layout} input layout."
            )
        if block_tables.shape[0] != batch_size:
            raise ValueError(
                f"block_tables batch dimension ({block_tables.shape[0]}) does "
                f"not match batch_size ({batch_size})."
            )
        if isinstance(paged_kv, tuple):
            # Requires pre-expanded [B, 2, M] block_tables so the kernel can
            # address V's blocks relative to K's base pointer.
            k_cache, v_cache = paged_kv
            _check_paged_kv_non_interleaved(k_cache, v_cache, block_tables)
        else:
            if paged_kv.dim() != 5 or paged_kv.shape[1] != 2:
                raise ValueError(
                    f"{input_layout} expects paged_KV shape [pages, 2, ...] "
                    "(page_size/num_kv_heads per layout order), got "
                    f"{tuple(paged_kv.shape)}"
                )
            if block_tables is not None and block_tables.dim() != 2:
                raise ValueError(
                    "Stacked paged_KV uses shared [B, M] block_tables; got "
                    f"{tuple(block_tables.shape)}. Pre-expanded [B, 2, M] "
                    "offsets are only valid with separate (k_cache, v_cache)."
                )
            k_cache, v_cache = paged_kv.unbind(dim=1)
    elif input_layout == "SEPARATE_Q_K_V":
        assert isinstance(qkv, tuple)
        query, k_cache, v_cache = qkv[0], qkv[1], qkv[2]
        if hasattr(torch, "float8_e4m3fn") and query.dtype == torch.float8_e4m3fn:
            raise ValueError(
                "FP8 (e4m3) is not supported for the SEPARATE_Q_K_V input layout. "
                "Use PACKED_QKV, CONTIGUOUS_Q_KV, or Q_PAGED_KV layout instead."
            )
        if logits_soft_cap_scale is not None and logits_soft_cap_scale > 0:
            raise ValueError(
                "Logits soft capping is not supported for the SEPARATE_Q_K_V input layout. "
                "Use PACKED_QKV, CONTIGUOUS_Q_KV, or Q_PAGED_KV layout instead."
            )
    else:
        raise ValueError(
            f"Unsupported input_layout: {input_layout!r}. Expected one of: "
            "PACKED_QKV, CONTIGUOUS_Q_KV, Q_PAGED_KV_HND, Q_PAGED_KV_NHD, SEPARATE_Q_K_V."
        )

    if input_layout == "PACKED_QKV":
        # Packed QKV: query is [tokens, 3, H, D]
        num_qo_heads = query.shape[2]
        page_size = 0  # Not applicable for packed layouts
        head_dim_v = query.shape[3]  # Assume same as head_dim_qk
    elif input_layout in ("Q_PAGED_KV_NHD", "Q_PAGED_KV_HND"):
        # Q is 3D: [tokens, H, D]
        num_qo_heads = query.shape[1]
        # Paged KV NHD: [num_pages, page_size, H_kv, D]
        # Paged KV HND: [num_pages, H_kv, page_size, D]
        page_size = k_cache.shape[1 if "NHD" in input_layout else 2]
        head_dim_v = v_cache.shape[3]
    elif input_layout == "CONTIGUOUS_Q_KV":
        # Q is 3D: [tokens, H, D], KV is 4D: [tokens, 2, H_kv, D]
        # k_cache holds the combined KV tensor
        num_qo_heads = query.shape[1]
        page_size = 0  # Not applicable for non-paged layouts
        head_dim_v = k_cache.shape[3]  # D from KV tensor
    else:
        # SEPARATE_Q_K_V: all 3D ragged [tokens, H, D]
        num_qo_heads = query.shape[1]
        page_size = 0  # Not applicable for non-paged layouts
        head_dim_v = v_cache.shape[2]

    uses_sliding_window = window_left is not None and window_left >= 0
    uses_chunked = chunked_attention_size is not None and chunked_attention_size > 0
    is_non_causal = mask_mode is not None and mask_mode.lower() == "padding"

    if (uses_sliding_window or uses_chunked) and is_non_causal:
        feature = "Sliding window" if uses_sliding_window else "Chunked"
        raise ValueError(
            f"{feature} attention requires causal masking. "
            f"The underlying kernel only supports SLIDING_OR_CHUNKED_CAUSAL mode. "
        )

    # Chunked-causal masking is only implemented by the warp-specialized (SM90)
    # kernels. The non-warp-specialized "tiled" kernels used on SM120 honor
    # ``sliding_window_size`` only and silently ignore ``chunked_attention_size``,
    # so reject chunked attention here rather than returning wrong results.
    # Sliding-window causal (``window_left``) IS supported on SM120.
    if uses_chunked and is_sm12x_supported(query.device):
        raise ValueError(
            "Chunked-causal attention (chunked_attention_size > 0) is not "
            "supported for FMHAv2 on SM120 (Blackwell). The SM120 tiled kernels "
            "implement sliding-window causal only. Use window_left for "
            "sliding-window masking, or run chunked attention on SM90 (Hopper)."
        )

    # Determine output dtype
    if out is not None:
        o_dtype = out.dtype
    elif out_dtype is not None:
        o_dtype = canonicalize_torch_dtype(out_dtype)
    else:
        o_dtype = query.dtype

    # Allocate output tensor if not provided
    # Use head_dim_v (actual value) not head_dim_vo (0 means "same as head_dim_qk")
    if out is None:
        out = torch.empty(
            (query.shape[0], num_qo_heads, head_dim_v),
            dtype=o_dtype,
            device=query.device,
        )

    is_e4m3 = (
        query.dtype == torch.float8_e4m3fn if hasattr(torch, "float8_e4m3fn") else False
    )
    if is_e4m3:
        if is_sm12x_supported(query.device):
            raise ValueError(
                "FP8 (e4m3) is not yet supported for FMHAv2 on SM120 (Blackwell). "
                "Use fp16 or bf16 instead."
            )
    # Always pass 1.0: the C++ auto-detect (scale_softmax == 0.0) handles FP16/INT8/E4M3
    # but has no branch for BF16, where 0.0 would zero out the softmax output.
    scale_softmax = 1.0
    softcapping_scale = (
        logits_soft_cap_scale if logits_soft_cap_scale is not None else 0.0
    )

    module = get_trtllm_fmha_v2_module(
        input_layout,
        query.dtype,
        o_dtype if query.dtype == torch.float8_e4m3fn else None,
    )

    # Allocate LSE tensor if saving softmax stats
    # Kernel writes in ragged (flat
    # ) format: [total_q_tokens, num_qo_heads, 2]
    # total_q_tokens == query.shape[0] for all ragged layouts
    lse = None
    if save_softmax_stats:
        lse = torch.empty(
            (query.shape[0], num_qo_heads, 2),
            dtype=torch.float32,
            device=query.device,
        )

    module.run(
        query,  # Q tensor
        k_cache,  # K tensor
        v_cache,  # V tensor
        out,  # Output tensor
        workspace_buffer,  # Workspace buffer
        workspace_buffer.numel()
        * workspace_buffer.element_size(),  # Workspace buffer size in bytes
        block_tables,
        page_size,
        seq_lens,  # Sequence length for kv_cache
        cum_seq_lens_q,  # Cumulative sequence length for query
        cum_seq_lens_kv,  # Cumulative sequence length for kv_cache
        input_layout.lower(),  # Input layout
        max_q_len,  # Max sequence length for query
        max_kv_len,  # Max sequence length for kv_cache
        batch_size,  # Batch size
        mask_mode.lower(),  # Attention mask type
        scale_softmax,  # Softmax scale
        bmm1_scale,  # BMM1 scale
        bmm2_scale,  # BMM2 scale (host float; encoded by C++ set_alpha)
        window_left,  # Window left
        chunked_attention_size,  # Chunked attention size
        pos_encoding_mode is not None
        and pos_encoding_mode.lower() == "alibi",  # Alibi mode
        softcapping_scale,  # Softcapping scale (0.0 = disabled)
        skip_softmax_threshold_scale_factor,  # threshold_scale_factor for skip-softmax (0.0 = disable)
        lse,  # Optional LSE tensor (None if not saving softmax stats)
        sinks,  # Optional sinks tensor
    )

    if save_softmax_stats:
        return out, lse
    else:
        return out


@flashinfer_experimental_api
def prepare_nvfp4_attention(q, k, v, out, *, backend="cake"):
    """Prepare NVFP4 attention from BF16 [B,H,S,128] tensors.

    The experimental Cake backend requires SM103 and noncausal S divisible
    by 512. ``q``, ``k`` and ``v`` may have any strides; ``out`` is contiguous.
    Preparation quantizes Q/K/V to block-scaled E2M1 and returns an
    NVFP4AttentionRunner. Calling the runner executes QK, softmax and PV
    attention and writes the caller-owned BF16 output without CUDA allocation.
    Prepare a new runner after changing input values or bindings. CUDA Graph
    ownership remains with the caller.
    """
    if backend != "cake":
        raise ValueError("NVFP4 attention currently supports backend='cake'")
    from .experimental.nvfp4_attention.cake_backend import (
        prepare_nvfp4_attention as prepare,
    )

    return prepare(q, k, v, out, backend="cake")


@flashinfer_experimental_api(feature="MiniMax-H3 packed-varlen BF16 attention")
def minimax_h3_varlen_attention(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    cu_seqlens: torch.Tensor,
    *,
    softmax_scale: Optional[float] = None,
    out: Optional[torch.Tensor] = None,
    cu_seqlens_host: Optional[Sequence[int]] = None,
    backend: str = "cake",
) -> torch.Tensor:
    r"""Noncausal packed-varlen BF16 attention over THD tensors (SM100/SM103).

    The experimental Cake backend runs one persistent 2-CTA-cluster tcgen05
    kernel (``kind::f16`` QK and PV, FP32 softmax and accumulation) over
    packed ``[T, H, 128]`` tensors: for every segment ``[a, b)`` of
    ``cu_seqlens`` and every head ``h``,
    ``out[a:b, h] = softmax(query[a:b, h] @ key[a:b, h]^T * softmax_scale) @ value[a:b, h]``
    (flashinfer-ai/flashinfer#4532, candidate 3A).

    Parameters
    ----------
    query, key, value : torch.Tensor
        BF16 ``[T, H, 128]`` packed THD tensors on one CUDA device.  Any
        token-major view with ``stride(2) == 1``, a head stride ``stride(1)``
        of at least 128 elements, a token stride ``stride(0)`` of at least
        ``H * stride(1)`` elements (both multiples of 8 elements = 16 bytes)
        and a 16-byte-aligned data pointer is consumed in place; the
        kernel's tensor maps and ragged-tail path take the strides as
        arguments.  This covers the engine's column chunks of the fused QKV
        projection ``[T, 3 * H * 128]`` (strides ``(3 * H * 128, 128, 1)``)
        and the kind slices of the Cake pre-attention pack ``[T, H, 3, 128]``
        (strides ``(H * 384, 384, 1)``), as well as contiguous tensors.
    cu_seqlens : torch.Tensor
        int32 ``[B + 1]`` segment bounds on the same device with
        ``cu_seqlens[0] == 0``, non-decreasing entries and ``cu_seqlens[B] == T``.
        Segment lengths are arbitrary (including 0 and below one tile).
    softmax_scale : Optional[float]
        Defaults to ``1 / sqrt(128)``.
    out : Optional[torch.Tensor]
        Optional caller-owned contiguous BF16 ``[T, H, 128]`` output.
    cu_seqlens_host : Optional[Sequence[int]]
        Host copy of ``cu_seqlens``; when omitted the values are read back
        from the device once to build the segment plan.
    backend : str
        Only ``"cake"`` is supported.

    Returns
    -------
    torch.Tensor
        The contiguous BF16 ``[T, H, 128]`` output (``out`` when given).  For
        repeated launches or CUDA Graph capture use
        ``flashinfer.experimental.minimax_h3_varlen_attention.cake_backend.prepare_minimax_h3_varlen_attention``,
        whose runner launches with no allocation or synchronization.  See
        ``flashinfer/experimental/minimax_h3_varlen_attention/README.md``.
    """
    if backend != "cake":
        raise ValueError(
            "MiniMax-H3 varlen attention currently supports backend='cake'"
        )
    from .experimental.minimax_h3_varlen_attention.cake_backend import (
        minimax_h3_varlen_attention as run,
    )

    return run(
        query,
        key,
        value,
        cu_seqlens,
        softmax_scale=softmax_scale,
        out=out,
        cu_seqlens_host=cu_seqlens_host,
        backend="cake",
    )


@flashinfer_experimental_api(feature="MiniMax-H3 packed-varlen NVFP4 attention")
def minimax_h3_varlen_nvfp4_attention(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    cu_seqlens: torch.Tensor,
    *,
    pv_mode: str = "fp8",
    softmax_scale: Optional[float] = None,
    out: Optional[torch.Tensor] = None,
    cu_seqlens_host: Optional[Sequence[int]] = None,
    backend: str = "cake",
) -> torch.Tensor:
    r"""Noncausal packed-varlen attention with NVFP4 QK over THD tensors (SM100/SM103).

    The experimental Cake backend quantizes ``query``/``key`` (and ``value``)
    in-pipeline into a head-major, per-segment 128-token-padded packed layout
    and runs one persistent 2-CTA-cluster tcgen05 kernel: QK is
    ``kind::mxf4nvf4`` (E2M1 x E2M1 with UE4M3 block-16 scales); PV is either
    ``kind::f8f6f4`` (``pv_mode="fp8"``: E4M3 P and dense E4M3 V with one
    per-tensor scale) or ``kind::mxf4nvf4`` (``pv_mode="fp4"``: E2M1 P anchored
    at the score-tile maximum and E2M1 V^T with per-16-token scales).  Softmax
    and accumulation are FP32; the output is BF16 (flashinfer-ai/flashinfer#4532,
    candidate 3C).  The complete call, including quantization, is the timed
    boundary; the prepared runner exposes ``quantize()`` and ``attention()``
    for separate timing.

    Parameters
    ----------
    query, key, value : torch.Tensor
        Contiguous BF16 ``[T, H, 128]`` packed THD tensors on one CUDA device.
    cu_seqlens : torch.Tensor
        int32 ``[B + 1]`` segment bounds on the same device with
        ``cu_seqlens[0] == 0``, non-decreasing entries and ``cu_seqlens[B] == T``.
    pv_mode : str
        ``"fp8"`` (default, lower error) or ``"fp4"`` (fastest for long
        segments).
    softmax_scale : Optional[float]
        Defaults to ``1 / sqrt(128)``.
    out : Optional[torch.Tensor]
        Optional caller-owned BF16 ``[T, H, 128]`` output.
    cu_seqlens_host : Optional[Sequence[int]]
        Host copy of ``cu_seqlens``; when omitted the values are read back
        from the device once to build the segment plan.
    backend : str
        Only ``"cake"`` is supported.

    Returns
    -------
    torch.Tensor
        The BF16 ``[T, H, 128]`` output (``out`` when given).  Validated
        tolerance against an FP32 reference is ``atol=1.0, rtol=0.1``.  For
        repeated launches or CUDA Graph capture use
        ``flashinfer.experimental.minimax_h3_varlen_attention.cake_backend.prepare_minimax_h3_varlen_nvfp4_attention``.
        See ``flashinfer/experimental/minimax_h3_varlen_attention/README.md``.
    """
    if backend != "cake":
        raise ValueError(
            "MiniMax-H3 varlen NVFP4 attention currently supports backend='cake'"
        )
    from .experimental.minimax_h3_varlen_attention.cake_backend import (
        minimax_h3_varlen_nvfp4_attention as run,
    )

    return run(
        query,
        key,
        value,
        cu_seqlens,
        pv_mode=pv_mode,
        softmax_scale=softmax_scale,
        out=out,
        cu_seqlens_host=cu_seqlens_host,
        backend="cake",
    )
