"""
Copyright (c) 2025 by FlashInfer team.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

"""
Gated Delta Rule Decode - API Layer
====================================

This file provides the public API for gated delta rule decode operations.
Kernel implementations are in flashinfer/gdn_kernels/.

APIs:
- gated_delta_rule_decode_pretranspose: V-major state layout [B, HV, V, K], T=1
- gated_delta_rule_decode: K-major state layout [B, HV, K, V], T=1
- gated_delta_rule_mtp: Multi-token processing (T > 1) for speculative decoding
- gated_delta_rule_replayssm_commit: Commit the accepted ReplaySSM prefix
"""

import functools
import os
from typing import Literal, Optional, Tuple

import torch

from .jit.core import logger
from .utils import get_compute_capability

try:
    from .jit import cake_gdn as _cake_gdn

    _CAKE_GDN_AVAILABLE = True
except (ImportError, RuntimeError):
    _cake_gdn = None
    _CAKE_GDN_AVAILABLE = False

try:
    from .api_logging import flashinfer_api
    from .trace.templates.gdn import (
        gated_delta_rule_decode_trace,
        gdn_mtp_trace,
        gdn_replayssm_commit_trace,
    )

    _FLASHINFER_AVAILABLE = True
except ImportError:
    _FLASHINFER_AVAILABLE = False
    gated_delta_rule_decode_trace = None  # type: ignore[assignment]
    gdn_mtp_trace = None  # type: ignore[assignment]
    gdn_replayssm_commit_trace = None  # type: ignore[assignment]

    # Fallback decorator for standalone usage (accepts trace= kwarg)
    def flashinfer_api(func=None, *, trace=None):  # type: ignore[misc]
        if func is None:
            return lambda f: f
        return func


# GDN decode BF16 state kernels - optional backend
try:
    from .gdn_kernels.gdn_decode_bf16_state import (
        gated_delta_rule as _gated_delta_rule_bf16_state,
        gated_delta_rule_mtp as _gated_delta_rule_bf16_state_mtp,
    )

    _GDN_DECODE_BF16_STATE_AVAILABLE = True
except (ImportError, RuntimeError):
    _GDN_DECODE_BF16_STATE_AVAILABLE = False
    _gated_delta_rule_bf16_state = None
    _gated_delta_rule_bf16_state_mtp = None

# Rubin (SM107) T=1 BF16 state kernel - optional backend
try:
    from .gdn_kernels.gdn_decode_bf16_state_rubin import (
        gated_delta_rule_t1_rubin as _gated_delta_rule_t1_rubin,
    )

    _GDN_DECODE_BF16_STATE_RUBIN_AVAILABLE = True
except (ImportError, RuntimeError):
    _GDN_DECODE_BF16_STATE_RUBIN_AVAILABLE = False
    _gated_delta_rule_t1_rubin = None


@functools.cache
def _ugpu_streams(device_index: int):
    """One green-context stream per locality domain of ``device_index`` and its SM count.

    Cached; the first uGPU call creates them, so make one eager call before CUDA graph capture.
    """
    from .green_ctx import split_device_green_ctx_by_locality_domain

    streams, resources = split_device_green_ctx_by_locality_domain(
        torch.device("cuda", device_index)
    )
    return streams, [int(r.sm.smCount) for r in resources]


# Eager calls below this many (batch x value-head) states are host-bound: the per-die fork / join
# costs more host time than the die-local traffic saves, so they run the two halves back to back
# on the current stream (each over the whole GPU). Under CUDA graph capture the per-die streams
# are always used: replay has no host cost.
_UGPU_EAGER_MIN_STATES = 8192


@flashinfer_api
def ugpu_state_pool(
    pool_size: int,
    num_v_heads: int,
    head_size: int = 128,
    device: Optional[torch.device] = None,
) -> torch.Tensor:
    r"""Allocate a bfloat16 GDN state pool for uGPU localization on Rubin.

    Returns an uninitialized pool of shape ``[pool_size, HV, 2, V // 2, K]``
    (``V = K = head_size``): element ``[s, h, t, r, k]`` is element ``[s, h, t * V // 2 + r,
    k]`` of the usual ``[pool_size, HV, V, K]`` pool. Half ``t`` of every state lives in
    locality domain (die) ``t``'s memory. Pass it as ``initial_state`` to
    :func:`gated_delta_rule_decode_pretranspose`: on Rubin a T=1 call then runs half ``t`` of
    every state on die ``t``'s SMs, so no state byte crosses the die-to-die link, whatever the
    batch order and slot indices. That is for CUDA-graph captured decode (make one eager call
    before capture); eager calls with ``B * HV < 8192`` are host-bound and run both halves
    back to back on the current stream.

    The pool comes from :func:`flashinfer.green_ctx.empty_per_locality_domain`, outside
    PyTorch's caching allocator.

    Args:
        pool_size: Number of state slots.
        num_v_heads: Number of value heads (HV).
        head_size: K = V (128).
        device: CUDA device with two locality domains (default: the current device).
    """
    from .green_ctx import empty_per_locality_domain

    device = torch.device(device) if device is not None else torch.device("cuda")
    parts = empty_per_locality_domain(
        (pool_size, num_v_heads, head_size // 2, head_size), torch.bfloat16, device
    )
    assert parts.shape[0] == 2, "ugpu_state_pool needs exactly two locality domains"
    return parts.permute(1, 2, 0, 3, 4)


def _run_rubin_t1_ugpu(
    pool: torch.Tensor, v: torch.Tensor, output: torch.Tensor, **kw
) -> torch.Tensor:
    """uGPU localization: half t of every state (pool[:, :, t]) on locality domain t's SMs,
    as two launches of the Rubin T=1 kernel forked from and joined back to the current stream.
    Each launch is the same kernel on V/2 value rows (rows are independent), so the result is
    bitwise equal to one launch over the full pool. Small eager calls run the two launches
    back to back on the current stream instead (see ``_UGPU_EAGER_MIN_STATES``)."""
    half = v.shape[3] // 2
    # int32 slot indices once for both launches
    for name in ("initial_state_indices", "output_state_indices"):
        if kw.get(name) is not None and kw[name].dtype != torch.int32:
            kw[name] = kw[name].to(torch.int32)
    with torch.cuda.device(v.device):  # streams and events of v's device
        streams, sm_counts = _ugpu_streams(v.device.index)
        if (
            v.shape[0] * v.shape[2] < _UGPU_EAGER_MIN_STATES
            and not torch.cuda.is_current_stream_capturing()
        ):
            for domain in range(2):
                _gated_delta_rule_t1_rubin(
                    initial_state_source=pool.select(2, domain),
                    v=v.narrow(3, domain * half, half),
                    output=output.narrow(3, domain * half, half),
                    **kw,
                )
            return output
        main = torch.cuda.current_stream()
        fork = torch.cuda.Event()
        fork.record(main)
        joins = []
        for domain in range(2):
            stream = streams[domain]
            stream.wait_event(fork)
            _gated_delta_rule_t1_rubin(
                initial_state_source=pool.select(2, domain),
                v=v.narrow(3, domain * half, half),
                output=output.narrow(3, domain * half, half),
                # L2 prefetch distance for this domain's share of the SMs
                pf_dist=sm_counts[domain] * 25 // 3,
                stream=stream,
                **kw,
            )
            done = torch.cuda.Event()
            done.record(stream)
            joins.append(done)
        for done in joins:
            main.wait_event(done)
    return output


# Pretranspose decode kernel (V-major state, T=1)
try:
    from .gdn_kernels.gdn_decode_pretranspose import run_pretranspose_decode

    _PRETRANSPOSE_AVAILABLE = True
except (ImportError, RuntimeError):
    _PRETRANSPOSE_AVAILABLE = False
    run_pretranspose_decode = None

# Nontranspose decode kernel (K-major state, T=1)
try:
    from .gdn_kernels.gdn_decode_nontranspose import (
        run_nontranspose_decode,
        TILE_V_NT,
    )

    _NONTRANSPOSE_AVAILABLE = True
except (ImportError, RuntimeError):
    _NONTRANSPOSE_AVAILABLE = False
    run_nontranspose_decode = None
    TILE_V_NT = 32  # fallback for assertions

# MTP kernel (T > 1, speculative decoding verification)
try:
    from .gdn_kernels.gdn_decode_mtp import (
        run_mtp_decode,
        get_tile_v_mtp,
        get_vec_size_mtp,
        get_mtp_config,
    )

    _MTP_AVAILABLE = True
except (ImportError, RuntimeError):
    _MTP_AVAILABLE = False
    run_mtp_decode = None
    get_tile_v_mtp = None
    get_vec_size_mtp = None
    get_mtp_config = None

# Constants for V-divisibility validation
TILE_V = 8  # pretranspose tile size


# Per-call device-side slot validation for the Cake GDN decode adapters. Each
# ``torch._assert_async`` chain below expands to five elementwise kernels, a
# device-to-device copy and a ~10 us ``_assert_async_cuda_kernel``; the two
# calls per decode add ~40 us of GPU time (and ~0.4 ms of eager launch span)
# around a 5 us kernel, which made every ``backend="cake_gdn"`` decode row slower
# than the CuTe path through the public API even under CUDA-graph replay. The
# CuTe decode kernels trust caller-provided slots, so the Cake adapters now do
# the same by default; set ``FLASHINFER_CAKE_GDN_VALIDATE_SLOTS=1`` to restore
# the asynchronous fail-closed check (used by the invalid-slot tests).
_CAKE_GDN_VALIDATE_SLOTS = (
    os.environ.get("FLASHINFER_CAKE_GDN_VALIDATE_SLOTS", "0") == "1"
)


def _cake_gdn_assert_state_slots(
    indices: torch.Tensor, pool_size: int, *, name: str, allow_minus_one: bool
) -> None:
    """Validate CUDA-resident state slots without a host synchronization.

    Only active when ``FLASHINFER_CAKE_GDN_VALIDATE_SLOTS=1``; see the note above.
    """

    if not _CAKE_GDN_VALIDATE_SLOTS:
        return
    in_pool = (indices >= 0) & (indices < pool_size)
    valid = ((indices == -1) | in_pool) if allow_minus_one else in_pool
    torch._assert_async(
        valid.all(),
        f"{name} must contain "
        + ("-1 or " if allow_minus_one else "")
        + f"slots in [0, {pool_size})",
    )


def _run_cake_gdn_decode_pretranspose(
    *,
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    state_pool: torch.Tensor,
    A_log: torch.Tensor,
    a: torch.Tensor,
    dt_bias: torch.Tensor,
    b: torch.Tensor,
    scale: float,
    use_qk_l2norm: bool,
    output: Optional[torch.Tensor],
    initial_state_indices: torch.Tensor,
    output_state_indices: Optional[torch.Tensor],
    intermediate_states_buffer: Optional[torch.Tensor],
    disable_state_update: bool,
) -> torch.Tensor:
    """Launch one exact manifest-backed GDN non-CP decode row or fail closed."""

    if not _CAKE_GDN_AVAILABLE or _cake_gdn is None:
        raise RuntimeError("the source-only Cake GDN backend is not installed")
    if q.device.type != "cuda":
        raise _cake_gdn.CakeGDNUnsupportedError("Cake GDN requires CUDA tensors")
    if q.dtype != torch.bfloat16:
        raise _cake_gdn.CakeGDNUnsupportedError("GDN non-CP decode requires BF16 I/O")
    if (
        k.dtype != torch.bfloat16
        or v.dtype != torch.bfloat16
        or a.dtype != torch.bfloat16
        or b.dtype != torch.bfloat16
        or A_log.dtype != torch.float32
        or dt_bias.dtype != torch.float32
    ):
        raise _cake_gdn.CakeGDNUnsupportedError(
            "GDN non-CP decode requires BF16 Q/K/V/gates and FP32 A_log/dt_bias"
        )
    if state_pool.dtype not in (torch.bfloat16, torch.float32):
        raise _cake_gdn.CakeGDNUnsupportedError(
            "GDN non-CP decode requires BF16 or FP32 state"
        )
    batch_size, seq_len, num_q_heads, head_size = q.shape
    num_v_heads, value_size = int(v.shape[2]), int(v.shape[3])
    if (
        k.shape != q.shape
        or v.shape != (batch_size, seq_len, num_v_heads, value_size)
        or head_size != 128
        or value_size != 128
        or a.shape != (batch_size, seq_len, num_v_heads)
        or b.shape != (batch_size, seq_len, num_v_heads)
        or A_log.shape != (num_v_heads,)
        or dt_bias.shape != (num_v_heads,)
    ):
        raise _cake_gdn.CakeGDNUnsupportedError(
            "GDN non-CP decode requires exact [B,T,H,128] Q/K, [B,T,HV,128] V, "
            "and [B,T,HV] gate shapes"
        )
    tensors = (q, k, v, state_pool, A_log, a, dt_bias, b, initial_state_indices)
    if any(tensor.device != q.device for tensor in tensors):
        raise _cake_gdn.CakeGDNUnsupportedError(
            "GDN non-CP decode requires all tensors on one CUDA device"
        )
    if (
        initial_state_indices.shape != (batch_size,)
        or not initial_state_indices.is_contiguous()
    ):
        raise _cake_gdn.CakeGDNUnsupportedError(
            "GDN non-CP decode requires contiguous [B] state indices"
        )
    if int(state_pool.shape[0]) <= 0 or state_pool.shape[1:] != (
        num_v_heads,
        128,
        128,
    ):
        raise _cake_gdn.CakeGDNUnsupportedError(
            "GDN non-CP decode requires a [pool, HV, 128, 128] state pool"
        )
    if state_pool.dtype == torch.bfloat16 and state_pool.stride()[1:] != (
        128 * 128,
        128,
        1,
    ):
        raise _cake_gdn.CakeGDNUnsupportedError(
            "GDN non-CP BF16 decode requires packed inner state dimensions"
        )
    if (
        state_pool.dtype == torch.float32
        and seq_len == 1
        and not all(
            tensor.is_contiguous()
            for tensor in (q, k, v, state_pool, A_log, a, dt_bias, b)
        )
    ):
        raise _cake_gdn.CakeGDNUnsupportedError(
            "GDN non-CP FP32 T=1 decode requires contiguous inputs and state"
        )
    if initial_state_indices.dtype != torch.int32:
        raise _cake_gdn.CakeGDNUnsupportedError(
            "GDN non-CP decode requires int32 state indices"
        )
    write_indices = (
        initial_state_indices if output_state_indices is None else output_state_indices
    )
    if write_indices.dtype != torch.int32:
        raise _cake_gdn.CakeGDNUnsupportedError(
            "GDN non-CP decode requires int32 output state indices"
        )
    if write_indices.shape != (batch_size,) or not write_indices.is_contiguous():
        raise _cake_gdn.CakeGDNUnsupportedError(
            "GDN non-CP decode requires contiguous [B] output state indices"
        )
    if write_indices.device != q.device:
        raise _cake_gdn.CakeGDNUnsupportedError(
            "GDN non-CP decode requires output state indices on the input CUDA device"
        )
    if output is None:
        output = torch.empty(
            (q.shape[0], q.shape[1], v.shape[2], v.shape[3]),
            dtype=torch.bfloat16,
            device=q.device,
        )
    elif output.dtype != torch.bfloat16 or not output.is_contiguous():
        raise _cake_gdn.CakeGDNUnsupportedError(
            "GDN non-CP decode requires a contiguous BF16 output"
        )
    if output.device != q.device:
        raise _cake_gdn.CakeGDNUnsupportedError(
            "GDN non-CP decode requires output on the input CUDA device"
        )
    if intermediate_states_buffer is not None:
        if (
            intermediate_states_buffer.dtype != state_pool.dtype
            or not intermediate_states_buffer.is_contiguous()
            or intermediate_states_buffer.ndim != 5
            or intermediate_states_buffer.shape[0] != q.shape[0]
            or intermediate_states_buffer.shape[1] < q.shape[1]
            or intermediate_states_buffer.device != q.device
        ):
            raise _cake_gdn.CakeGDNUnsupportedError(
                "GDN non-CP checkpoint buffer must be contiguous [B, >=T, HV, V, K] "
                "with the state dtype"
            )
        cache_steps = int(intermediate_states_buffer.shape[1])
    else:
        cache_steps = 0
    pool_size = int(state_pool.shape[0])
    _cake_gdn_assert_state_slots(
        initial_state_indices,
        pool_size,
        name="GDN non-CP decode initial_state_indices",
        allow_minus_one=True,
    )
    _cake_gdn_assert_state_slots(
        write_indices,
        pool_size,
        name="GDN non-CP decode output_state_indices",
        allow_minus_one=True,
    )
    strided_inputs = not all(tensor.is_contiguous() for tensor in (q, k, v, a, b))
    major, minor = torch.cuda.get_device_capability(q.device)
    arch = _cake_gdn.arch_for_compute_capability(major, minor)
    route = _cake_gdn.select_cake_gdn_decode_variant(
        arch=arch,
        batch_size=int(q.shape[0]),
        io_dtype="bfloat16",
        state_dtype=("bfloat16" if state_pool.dtype == torch.bfloat16 else "float32"),
        head_size=int(q.shape[3]),
        layout="pretranspose",
        num_k_heads=int(k.shape[2]),
        num_q_heads=int(q.shape[2]),
        num_v_heads=int(v.shape[2]),
        scale=scale,
        seq_len=int(q.shape[1]),
        use_qk_l2norm=use_qk_l2norm,
        strided_inputs=strided_inputs,
        disable_state_update=disable_state_update,
        cache_intermediate_states=intermediate_states_buffer is not None,
        cache_steps=cache_steps,
    )
    entry = _cake_gdn.load_cake_gdn_kernel(route.variant_name, arch)
    batch_size, seq_len = int(q.shape[0]), int(q.shape[1])
    num_v_heads = int(v.shape[2])
    if state_pool.dtype == torch.bfloat16:
        state_heads = batch_size * num_v_heads
        tile_v = (
            16
            if route.route_id.endswith(".tile16_fullwarp")
            else 128
            if state_heads >= 1024
            else 64
            if state_heads >= 512
            else 32
        )
        entry(
            q,
            k,
            v,
            state_pool,
            A_log,
            a,
            dt_bias,
            b,
            output,
            intermediate_states_buffer
            if intermediate_states_buffer is not None
            else output,
            initial_state_indices,
            write_indices,
            batch_size * num_v_heads * (128 // tile_v),
            1,
            1,
        )
    elif seq_len == 1:
        entry(
            q,
            k,
            v,
            state_pool,
            A_log,
            a,
            dt_bias,
            b,
            output,
            initial_state_indices,
            write_indices,
            batch_size * num_v_heads * 8,
            1,
            1,
        )
    else:
        if intermediate_states_buffer is None:
            raise _cake_gdn.CakeGDNUnsupportedError(
                "GDN non-CP FP32 MTP requires a caller-owned checkpoint buffer"
            )
        args = [
            q,
            k,
            v,
            state_pool,
            A_log,
            a,
            dt_bias,
            b,
            output,
            intermediate_states_buffer,
            initial_state_indices,
        ]
        if seq_len == 4:
            args.append(write_indices)
        grid_scale = 512 if seq_len == 2 else 256 if batch_size == 4 else 64
        entry(*args, batch_size * grid_scale, 1, 1)
    return output


def _run_cake_gdn_decode_nontranspose(
    *,
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    state: torch.Tensor,
    A_log: torch.Tensor,
    a: torch.Tensor,
    dt_bias: torch.Tensor,
    b: torch.Tensor,
    scale: float,
    output: torch.Tensor,
    use_qk_l2norm: bool,
) -> torch.Tensor:
    """Launch one exact manifest-backed GDN non-CP nontranspose T=1 row."""

    if not _CAKE_GDN_AVAILABLE or _cake_gdn is None:
        raise RuntimeError("the source-only Cake GDN backend is not installed")
    batch_size, seq_len, num_q_heads, head_size = q.shape
    num_v_heads, value_size = int(v.shape[2]), int(v.shape[3])
    tensors = (q, k, v, state, A_log, a, dt_bias, b, output)
    if q.device.type != "cuda" or any(tensor.device != q.device for tensor in tensors):
        raise _cake_gdn.CakeGDNUnsupportedError(
            "GDN non-CP nontranspose decode requires one CUDA device"
        )
    if (
        q.dtype != torch.bfloat16
        or k.dtype != torch.bfloat16
        or v.dtype != torch.bfloat16
        or a.dtype != torch.bfloat16
        or b.dtype != torch.bfloat16
        or state.dtype != torch.float32
        or A_log.dtype != torch.float32
        or dt_bias.dtype != torch.float32
        or output.dtype != torch.bfloat16
    ):
        raise _cake_gdn.CakeGDNUnsupportedError(
            "GDN non-CP nontranspose decode requires BF16 I/O/gates and FP32 state/decay"
        )
    if (
        seq_len != 1
        or head_size != 128
        or value_size != 128
        or k.shape != q.shape
        or v.shape != (batch_size, 1, num_v_heads, 128)
        or state.shape != (batch_size, num_v_heads, 128, 128)
        or a.shape != (batch_size, 1, num_v_heads)
        or b.shape != (batch_size, 1, num_v_heads)
        or A_log.shape != (num_v_heads,)
        or dt_bias.shape != (num_v_heads,)
        or output.shape != (batch_size, 1, num_v_heads, 128)
        or not all(tensor.is_contiguous() for tensor in tensors)
    ):
        raise _cake_gdn.CakeGDNUnsupportedError(
            "GDN non-CP nontranspose decode requires exact contiguous T=1 tensors"
        )
    major, minor = torch.cuda.get_device_capability(q.device)
    arch = _cake_gdn.arch_for_compute_capability(major, minor)
    route = _cake_gdn.select_cake_gdn_decode_variant(
        arch=arch,
        batch_size=int(batch_size),
        io_dtype="bfloat16",
        state_dtype="float32",
        head_size=128,
        layout="nontranspose",
        num_k_heads=int(k.shape[2]),
        num_q_heads=int(num_q_heads),
        num_v_heads=int(num_v_heads),
        scale=scale,
        seq_len=1,
        use_qk_l2norm=use_qk_l2norm,
    )
    entry = _cake_gdn.load_cake_gdn_kernel(route.variant_name, arch)
    blocks_per_state = 8 if batch_size < 32 else 1
    entry(
        q,
        k,
        v,
        state,
        A_log,
        a,
        dt_bias,
        b,
        output,
        batch_size * num_v_heads * blocks_per_state,
        1,
        1,
    )
    return output


# ============================================================================
# API: Pretranspose Decode (V-major / K-last state layout)
# ============================================================================


@flashinfer_api(trace=gated_delta_rule_decode_trace)
def gated_delta_rule_decode_pretranspose(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    state: Optional[torch.Tensor],
    A_log: torch.Tensor,
    a: torch.Tensor,
    dt_bias: torch.Tensor,
    b: torch.Tensor,
    scale: Optional[float] = None,
    output: Optional[torch.Tensor] = None,
    use_qk_l2norm: bool = True,
    initial_state: Optional[torch.Tensor] = None,
    initial_state_indices: Optional[torch.Tensor] = None,
    output_state_indices: Optional[torch.Tensor] = None,
    intermediate_states_buffer: Optional[torch.Tensor] = None,
    disable_state_update: bool = False,
    backend: Literal["auto", "flashinfer", "cake_gdn", "rubin"] = "auto",
) -> Tuple[torch.Tensor, torch.Tensor]:
    r"""Gated Delta Rule Decode kernel for single-token generation.

    Implements the decode phase of gated delta rule linear attention,
    processing one token at a time and updating the recurrent state.

    Parameters
    ----------
    q : torch.Tensor
        Current query of shape ``[B, 1, H, K]``.  Must be float16/bfloat16.
    k : torch.Tensor
        Current key of shape ``[B, 1, H, K]``.  Must be float16/bfloat16.
    v : torch.Tensor
        Current value of shape ``[B, 1, HV, V]``.  Must be float16/bfloat16.
    state : torch.Tensor, optional
        Current state of shape ``[B, HV, V, K]`` (v-major / K-last layout).
        Float32: legacy kernel (T=1 only).  Bfloat16: BF16 state backend
        (T=1 or MTP for T>1) when K=V=128.  Updated in-place.  Pass ``None``
        when using ``initial_state`` / ``initial_state_indices`` instead.
    A_log : torch.Tensor
        Log decay parameter of shape ``[HV]``.  Must be float32.
    a : torch.Tensor
        Input-dependent decay of shape ``[B, 1, HV]``.  Must be
        float16/bfloat16.
    dt_bias : torch.Tensor
        Decay bias of shape ``[HV]``.  Must be bfloat16 or float32.
    b : torch.Tensor
        Update gate (beta) input of shape ``[B, 1, HV]``.  Must be
        float16/bfloat16.
    scale : float, optional
        Scale factor for queries.  If ``None``, defaults to
        ``1 / sqrt(K)``.
    output : torch.Tensor, optional
        Pre-allocated output tensor of shape ``[B, 1, HV, V]``.  Allocated
        automatically when ``None``.
    use_qk_l2norm : bool
        Whether to apply L2 normalization to q and k.  Default: ``True``.
    initial_state : torch.Tensor, optional
        State pool of shape ``[pool_size, HV, V, K]`` (K-last /
        K-contiguous, same layout as the per-batch ``state`` argument), or a
        uGPU-localized pool ``[pool_size, HV, 2, V // 2, K]`` from
        :func:`ugpu_state_pool` (Rubin, T=1): each die then updates the half of
        every state that lives in its own memory, on its own SMs.
        When provided, the kernel gathers directly from the pool using
        ``initial_state_indices`` and writes updates back in-place,
        eliminating the caller-side gather/scatter overhead.  Requires
        bfloat16 state with K=V=128 (bf16 fast path).
    initial_state_indices : torch.Tensor, optional
        Per-batch indices of shape ``[B]`` (int32 or int64) mapping each
        batch entry to its slot in ``initial_state``.  Required when
        ``initial_state`` is provided.
    output_state_indices : torch.Tensor, optional
        Per-batch indices of shape ``[B]`` (int32 or int64) specifying
        where to write the updated state for each batch entry in the pool.
        Requires ``initial_state`` to be provided.  If ``None``, the kernel
        writes the updated state back to the same slot it read from (i.e.
        ``initial_state_indices``).
    intermediate_states_buffer : torch.Tensor, optional
        Caller-owned checkpoint buffer of shape ``[B, >=T, HV, V, K]``.
        Supported only for ``T > 1``; its dtype must match the state dtype.
    disable_state_update : bool
        Skip final-state writeback for verify calls. Supported only for
        ``T > 1``. Default: ``False``.
    backend : {"auto", "flashinfer", "cake_gdn", "rubin"}
        ``auto`` selects GDN non-CP only for an exact frozen manifest row and
        otherwise uses the existing FlashInfer implementation; on Rubin
        (compute capability 10.7) its T=1 bf16-state calls with
        ``B * HV >= 512`` use the Rubin-tuned kernel, which gives the same
        bits as the generic kernel there. ``flashinfer`` always uses the
        generic FlashInfer kernels. Explicit ``cake_gdn`` requests fail
        closed when the contract is unsupported. ``rubin`` forces the
        Rubin-tuned T=1 kernel and raises ``ValueError`` on other GPUs or
        outside T=1, bfloat16 state and K=V=128.

        **Padding / inactive sequences**: set the index to ``-1`` for any
        batch entry that should be treated as padding.  The two backends
        handle ``-1`` differently:

        - **bf16 fast path** (bfloat16 state, K=V=128): ``-1`` is redirected
          to ``initial_state[0]``, which acts as a sacrificial *null
          buffer*.  The kernel reads from and writes back to slot 0; the
          output for that batch entry is computed but **undefined** (caller
          should not use it).  The caller must therefore allocate the pool
          with an extra leading slot (``pool_size = num_real_slots + 1``)
          and keep real slots at indices ``1..pool_size-1``.
        - **float32 legacy path** (T=1): ``-1`` entries are skipped
          entirely; neither the state pool nor the output are touched for
          that batch entry; the output slot is written as **zero**.

    Returns
    -------
    Tuple[torch.Tensor, torch.Tensor]
        ``(output, state_or_initial_state)`` where ``output`` has shape
        ``[B, 1, HV, V]`` and the second element is the updated state
        (mutated in place).

    Notes
    -----
    - Requires SM90+ (Hopper, Blackwell, etc.).
    - State is always updated in-place; the pool path writes directly into
      ``initial_state`` memory (no separate scatter step needed).
    - State layout is v-major (K-last): ``[B, HV, V, K]``.  When state is
      bfloat16 and ``K = V = 128``, the BF16 state kernel is used (T=1 or
      MTP for T>1); the pool+indices path routes through the MTP kernel.
      On SM107 (Rubin), T=1 with ``B * HV >= 512`` uses the Rubin-tuned
      kernel (``gdn_kernels/gdn_decode_bf16_state_rubin.py``) under
      ``backend="auto"``. With a pool from :func:`ugpu_state_pool` every
      T=1 call on Rubin runs each half of every state on its own die (two
      per-die launches on green-context streams). This targets CUDA-graph
      captured decode (capturable after one eager call); eager calls with
      ``B * HV < 8192`` are host-bound and run the two halves back to back
      on the current stream instead.
    - Pool+indices (``initial_state`` / ``initial_state_indices``) are
      supported on both the bf16 fast path (K=V=128) and the float32 legacy
      path (T=1).  Both paths support ``-1`` padding indices (see
      ``initial_state_indices`` above for per-backend semantics).
    - Legacy path (float32 state, T=1): ``K`` and ``V`` must each be
      ``>= 128``, and ``V`` must be a multiple of 8 (the pretranspose tile
      size ``TILE_V``).
    """
    # Validate input shapes
    B, T, H, K = q.shape
    _, _, HV, V = v.shape

    if T == 1 and intermediate_states_buffer is not None:
        raise ValueError("intermediate_states_buffer is supported only for T > 1")
    if T == 1 and disable_state_update:
        raise ValueError("disable_state_update is supported only for T > 1")

    use_pool = initial_state is not None
    assert use_pool == (initial_state_indices is not None), (
        "initial_state and initial_state_indices must be provided together"
    )
    if output_state_indices is not None:
        assert use_pool, (
            "output_state_indices can only be used with initial_state (pool mode)"
        )
        assert output_state_indices.shape == (B,), (
            f"Expected output_state_indices shape [{B}], "
            f"got {output_state_indices.shape}"
        )
        assert output_state_indices.dtype in (torch.int32, torch.int64), (
            f"output_state_indices must be int32 or int64, "
            f"got {output_state_indices.dtype}"
        )

    ugpu_pool = use_pool and initial_state.dim() == 5
    if ugpu_pool:
        pool_size = initial_state.shape[0]
        if (
            initial_state.shape != (pool_size, HV, 2, V // 2, K)
            or initial_state.stride(-1) != 1
        ):
            raise ValueError(
                "a 5-D initial_state must be a uGPU pool [pool_size, HV, 2, V // 2, K] "
                f"(ugpu_state_pool), got shape {tuple(initial_state.shape)}"
            )
        if backend not in ("auto", "rubin"):
            raise ValueError(
                f'a uGPU pool needs backend "auto" or "rubin", got {backend!r}'
            )
        backend = "rubin"
    elif use_pool:
        pool_size = initial_state.shape[0]
        assert initial_state.shape == (pool_size, HV, V, K), (
            f"Expected initial_state shape [pool_size={pool_size}, HV={HV}, V={V}, K={K}], "
            f"got {initial_state.shape}"
        )
        assert initial_state.stride(-1) == 1, (
            "initial_state must be K-contiguous (stride[-1] == 1) for pretranspose decode, "
            f"got stride={initial_state.stride()}"
        )
    else:
        assert state is not None, "Either state or initial_state must be provided"
        # Validate state shape (K-last: [B, HV, V, K])
        assert state.shape == (B, HV, V, K), (
            f"Expected state shape [B={B}, HV={HV}, V={V}, K={K}], got {state.shape}"
        )

    # Backend: BF16 state kernel when bf16 state, K=V=128
    state_dtype = initial_state.dtype if use_pool else state.dtype
    if backend not in ("auto", "flashinfer", "cake_gdn", "rubin"):
        raise ValueError(f"unsupported GDN backend: {backend!r}")
    if backend == "rubin":
        if not _GDN_DECODE_BF16_STATE_RUBIN_AVAILABLE:
            raise RuntimeError("the Rubin GDN decode kernel failed to import")
        if get_compute_capability(q.device) != (10, 7):
            raise ValueError(
                'backend="rubin" needs compute capability 10.7 (Rubin), got '
                f"{get_compute_capability(q.device)}"
            )
        if not (T == 1 and state_dtype == torch.bfloat16 and K == 128 and V == 128):
            raise ValueError(
                'backend="rubin" supports T=1 with bfloat16 state and K=V=128, got '
                f"T={T}, state dtype {state_dtype}, K={K}, V={V}"
            )
    if backend not in ("flashinfer", "rubin"):
        if not _CAKE_GDN_AVAILABLE or _cake_gdn is None:
            if backend == "cake_gdn":
                raise RuntimeError("the source-only Cake GDN backend is not installed")
        elif not use_pool:
            if backend == "cake_gdn":
                raise _cake_gdn.CakeGDNUnsupportedError(
                    "GDN non-CP pretranspose decode requires an indexed state pool"
                )
        else:
            try:
                cake_gdn_output = _run_cake_gdn_decode_pretranspose(
                    q=q,
                    k=k,
                    v=v,
                    state_pool=initial_state,
                    A_log=A_log,
                    a=a,
                    dt_bias=dt_bias,
                    b=b,
                    scale=K**-0.5 if scale is None else scale,
                    use_qk_l2norm=use_qk_l2norm,
                    output=output,
                    initial_state_indices=initial_state_indices,
                    output_state_indices=output_state_indices,
                    intermediate_states_buffer=intermediate_states_buffer,
                    disable_state_update=disable_state_update,
                )
                return cake_gdn_output, initial_state
            except _cake_gdn.CakeGDNUnsupportedError:
                if backend == "cake_gdn":
                    raise
    use_bf16_state = (
        _GDN_DECODE_BF16_STATE_AVAILABLE
        and state_dtype == torch.bfloat16
        and K == 128
        and V == 128
    )
    if use_bf16_state:
        assert q.dtype in (torch.float16, torch.bfloat16), (
            f"q must be float16/bfloat16, got {q.dtype}"
        )
        assert A_log.dtype == torch.float32, f"A_log must be float32, got {A_log.dtype}"
        assert dt_bias.dtype in (torch.bfloat16, torch.float32), (
            f"dt_bias must be bfloat16 or float32, got {dt_bias.dtype}"
        )
        if use_pool:
            assert initial_state_indices.dtype in (torch.int32, torch.int64), (
                f"initial_state_indices must be int32 or int64, "
                f"got {initial_state_indices.dtype}"
            )
        scale_val = K**-0.5 if scale is None else scale
        # The BF16 path is pool-only. When the caller uses non-pool semantics
        # (passes ``state`` instead of ``initial_state``), treat ``state`` as
        # a pool of size B and synthesize sequential indices arange(B).
        if use_pool:
            bf16_pool = initial_state
            bf16_indices = initial_state_indices
        else:
            bf16_pool = state
            bf16_indices = torch.arange(B, dtype=torch.int32, device=q.device)
        # Forward user's `output=` straight into the kernel when its dtype
        # matches what the kernel writes (bf16). This avoids a redundant
        # device-to-device `output.copy_()` after every call.
        target_dtype = output.dtype if output is not None else q.dtype
        forward_output = (
            output if (output is not None and output.dtype == torch.bfloat16) else None
        )
        # Rubin (SM107): the Rubin-tuned T=1 kernel. It keeps the whole state tile in
        # flight with fewer instructions and is bitwise equal to the generic T=1
        # wide_vec kernel, which the generic dispatcher uses from B * HV >= 512.
        use_rubin = backend == "rubin" or (
            backend == "auto"
            and T == 1
            and B * HV >= 512
            and _GDN_DECODE_BF16_STATE_RUBIN_AVAILABLE
            and get_compute_capability(q.device) == (10, 7)
        )
        if ugpu_pool:
            out = _run_rubin_t1_ugpu(
                bf16_pool,
                v,
                forward_output
                if forward_output is not None
                else torch.empty(B, 1, HV, V, device=q.device, dtype=torch.bfloat16),
                A_log=A_log,
                a=a,
                dt_bias=dt_bias,
                softplus_beta=1.0,
                softplus_threshold=20.0,
                q=q,
                k=k,
                b=b,
                initial_state_indices=bf16_indices,
                output_state_indices=(
                    None
                    if output_state_indices is initial_state_indices
                    else output_state_indices
                ),
                use_qk_l2norm_in_kernel=use_qk_l2norm,
                scale=scale_val,
            )
        elif use_rubin:
            out = _gated_delta_rule_t1_rubin(
                A_log=A_log,
                a=a,
                dt_bias=dt_bias,
                softplus_beta=1.0,
                softplus_threshold=20.0,
                q=q,
                k=k,
                v=v,
                b=b,
                initial_state_source=bf16_pool,
                initial_state_indices=bf16_indices,
                output_state_indices=output_state_indices,
                use_qk_l2norm_in_kernel=use_qk_l2norm,
                scale=scale_val,
                output=forward_output,
            )
        elif T == 1:
            out = _gated_delta_rule_bf16_state(
                A_log=A_log,
                a=a,
                dt_bias=dt_bias,
                softplus_beta=1.0,
                softplus_threshold=20.0,
                q=q,
                k=k,
                v=v,
                b=b,
                initial_state_source=bf16_pool,
                initial_state_indices=bf16_indices,
                output_state_indices=output_state_indices,
                use_qk_l2norm_in_kernel=use_qk_l2norm,
                scale=scale_val,
                output=forward_output,
            )
        else:
            # MTP kernel for T>1 (supports pool+indices and intermediate caching)
            out = _gated_delta_rule_bf16_state_mtp(
                A_log=A_log,
                a=a,
                dt_bias=dt_bias,
                softplus_beta=1.0,
                softplus_threshold=20.0,
                q=q,
                k=k,
                v=v,
                b=b,
                initial_state_source=bf16_pool,
                initial_state_indices=bf16_indices,
                output_state_indices=output_state_indices,
                use_qk_l2norm_in_kernel=use_qk_l2norm,
                scale=scale_val,
                output=forward_output,
                intermediate_states_buffer=intermediate_states_buffer,
                disable_state_update=disable_state_update,
            )
        if forward_output is not None:
            # Kernel wrote directly into the user's buffer.
            output = forward_output
        elif output is None:
            # The kernel writes bf16 regardless of `q.dtype`; keep the documented
            # "result follows q.dtype" contract for fp16 callers.
            output = out if out.dtype == target_dtype else out.to(target_dtype)
        else:
            # User wants a non-bf16 dtype; cast on the way back.
            output.copy_(out.to(target_dtype))
        return_state = initial_state if use_pool else state
        return output, return_state

    # Legacy path: float32 state (T=1 via run_pretranspose_decode; T>1 routes
    # through gated_delta_rule_mtp when a pool is provided).
    use_pool_indexing = initial_state_indices is not None

    if use_pool:
        assert initial_state.dtype == torch.float32, (
            f"initial_state must be float32 for legacy path, got {initial_state.dtype}"
        )
    else:
        assert state is not None, "Either state or initial_state must be provided"
        assert state.dtype == torch.float32, f"state must be float32, got {state.dtype}"

    # Route fp32 + T>1 through the MTP kernel (supports separate read/write
    # indices via output_state_indices). Direct-state (non-pool) callers must
    # still use T=1 — wrapping a per-batch state as a pool of size B is the
    # caller's responsibility if they want T>1.
    if T > 1:
        assert use_pool, (
            f"fp32 state with T={T} > 1 requires pool mode (pass initial_state "
            f"and initial_state_indices instead of state)."
        )
        out, return_state = gated_delta_rule_mtp(
            q=q,
            k=k,
            v=v,
            initial_state=initial_state,
            initial_state_indices=initial_state_indices,
            A_log=A_log,
            a=a,
            dt_bias=dt_bias,
            b=b,
            scale=scale,
            output=output,
            intermediate_states_buffer=intermediate_states_buffer,
            disable_state_update=disable_state_update,
            use_qk_l2norm=use_qk_l2norm,
            output_state_indices=output_state_indices,
        )
        return out, return_state

    assert T == 1, f"Decode only supports T=1, got T={T}"

    # Validate K and V constraints
    assert K >= 128, f"K must be at least 128, got K={K}"
    assert V >= 128, f"V must be at least 128, got V={V}"
    assert V % TILE_V == 0, (
        f"V must be divisible by {TILE_V} to prevent out-of-bounds access, got V={V}"
    )

    # Validate dtypes
    assert q.dtype in (torch.float16, torch.bfloat16), (
        f"q must be float16/bfloat16, got {q.dtype}"
    )
    assert A_log.dtype == torch.float32, f"A_log must be float32, got {A_log.dtype}"
    assert dt_bias.dtype in (torch.bfloat16, torch.float32), (
        f"dt_bias must be bfloat16 or float32, got {dt_bias.dtype}"
    )
    if use_pool:
        assert initial_state_indices.dtype in (torch.int32, torch.int64), (
            f"initial_state_indices must be int32 or int64, "
            f"got {initial_state_indices.dtype}"
        )

    # Set default scale
    if scale is None:
        scale = K**-0.5

    # Allocate output if not provided
    # Note: kernel outputs bfloat16, we'll convert to q.dtype if needed
    output_provided = output is not None
    target_dtype = output.dtype if output_provided else q.dtype

    if output is None:
        # Kernel outputs bfloat16, allocate in that dtype first
        output = torch.zeros((B, T, HV, V), dtype=torch.bfloat16, device=q.device)

    # Build h0_source for kernel.
    # - pool path: keep original [pool_size, HV, V, K] view so non-contiguous
    #   page-strided pools are supported.
    # - direct path: flatten to [B*HV, V, K].
    if use_pool:
        pool_size = initial_state.shape[0]
        h0_source = initial_state
        return_state = initial_state
    else:
        pool_size = B
        h0_source = state.reshape(pool_size * HV, V, K)
        return_state = state

    # Execute kernel
    run_pretranspose_decode(
        h0_source,
        A_log,
        a,
        dt_bias,
        q,
        k,
        v,
        b,
        output,
        B,
        T,
        H,
        HV,
        K,
        V,
        scale,
        use_qk_l2norm,
        use_pool_indexing=use_pool_indexing,
        initial_state_indices=initial_state_indices,
        output_state_indices=output_state_indices,
    )

    # Copy state back only if not using pool and state was not contiguous
    # (if contiguous, reshape returns a view and kernel updated state in-place)
    # Pool path: kernel writes directly into initial_state via pool indices
    if not use_pool and not state.is_contiguous():
        state.copy_(h0_source.reshape(B, HV, V, K))

    # Convert output to target dtype if needed (kernel outputs bfloat16)
    if output.dtype != target_dtype:
        output = output.to(target_dtype)

    return output, return_state


# ============================================================================
# API: Nontranspose Decode (K-major state layout, recommended)
# ============================================================================


@flashinfer_api(trace=gated_delta_rule_decode_trace)
def gated_delta_rule_decode(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    state: torch.Tensor,
    A_log: torch.Tensor,
    a: torch.Tensor,
    dt_bias: torch.Tensor,
    b: torch.Tensor,
    scale: Optional[float] = None,
    output: Optional[torch.Tensor] = None,
    use_qk_l2norm: bool = True,
    backend: Literal["auto", "flashinfer", "cake_gdn"] = "auto",
) -> Tuple[torch.Tensor, torch.Tensor]:
    r"""Gated Delta Rule Decode kernel (K-major layout, no transpose needed).

    Implements the decode phase of gated delta rule linear attention,
    processing one token at a time and updating the recurrent state.  This
    variant uses K-major state layout ``[B, HV, K, V]`` (no transposition).

    Parameters
    ----------
    q : torch.Tensor
        Current query of shape ``[B, 1, H, K]``.  Must be float16/bfloat16.
    k : torch.Tensor
        Current key of shape ``[B, 1, H, K]``.  Must be float16/bfloat16.
    v : torch.Tensor
        Current value of shape ``[B, 1, HV, V]``.  Must be float16/bfloat16.
    state : torch.Tensor
        Current state of shape ``[B, HV, K, V]`` (k-major layout).  Must be
        float32.  Updated in-place.
    A_log : torch.Tensor
        Log decay parameter of shape ``[HV]``.  Must be float32.
    a : torch.Tensor
        Input-dependent decay of shape ``[B, 1, HV]``.  Must be
        float16/bfloat16.
    dt_bias : torch.Tensor
        Decay bias of shape ``[HV]``.  Must be bfloat16 or float32.
    b : torch.Tensor
        Update gate (beta) input of shape ``[B, 1, HV]``.  Must be
        float16/bfloat16.
    scale : float, optional
        Scale factor for queries.  If ``None``, defaults to ``1 /
        sqrt(K)``.
    output : torch.Tensor, optional
        Pre-allocated output tensor of shape ``[B, 1, HV, V]``.  Allocated
        automatically when ``None``.
    use_qk_l2norm : bool
        Whether to apply L2 normalization to q and k.  Default: ``True``.
    backend : {"auto", "flashinfer", "cake_gdn"}
        ``auto`` selects GDN non-CP only for an exact frozen manifest row;
        explicit ``cake_gdn`` requests fail closed.

    Returns
    -------
    Tuple[torch.Tensor, torch.Tensor]
        ``(output, state)`` where ``output`` has shape ``[B, 1, HV, V]``
        and ``state`` has shape ``[B, HV, K, V]`` (updated in-place).

    Notes
    -----
    - Requires SM90 (Hopper) architecture.
    - State is updated in-place.
    - ``K`` and ``V`` must each be ``>= 128``.  ``V`` must be a multiple
      of 32 (``TILE_V_NT``): the launcher conservatively asserts the
      large-batch tile size to cover both code paths, even though the
      small-batch kernel could in principle accept ``V % 16 == 0``
      (``TILE_V_SMALL_NT``).
    - State layout is k-major: ``[B, HV, K, V]`` (no transpose needed).
    """
    # Validate input shapes
    B, T, H, K = q.shape
    assert T == 1, f"Decode only supports T=1, got T={T}"
    _, _, HV, V = v.shape

    # Validate state shape
    assert state.shape == (B, HV, K, V), (
        f"Expected state shape [B={B}, HV={HV}, K={K}, V={V}], got {state.shape}"
    )

    # Validate K and V constraints
    assert K >= 128, f"K must be at least 128, got K={K}"
    assert V >= 128, f"V must be at least 128, got V={V}"
    # V must be divisible by tile size to prevent out-of-bounds access
    # For small batch: TILE_V_SMALL_NT=16, for large batch: TILE_V_NT=32
    # Use the more restrictive constraint (32) to cover both cases
    assert V % TILE_V_NT == 0, (
        f"V must be divisible by {TILE_V_NT} to prevent out-of-bounds access, got V={V}"
    )

    # Validate dtypes
    assert q.dtype in (torch.float16, torch.bfloat16), (
        f"q must be float16/bfloat16, got {q.dtype}"
    )
    assert state.dtype == torch.float32, f"state must be float32, got {state.dtype}"
    assert A_log.dtype == torch.float32, f"A_log must be float32, got {A_log.dtype}"
    assert dt_bias.dtype in (torch.bfloat16, torch.float32), (
        f"dt_bias must be bfloat16 or float32, got {dt_bias.dtype}"
    )

    # Set default scale
    if scale is None:
        scale = K**-0.5

    # Allocate output if not provided
    output_provided = output is not None
    target_dtype = output.dtype if output_provided else q.dtype

    if output is None:
        # Kernel outputs bfloat16, allocate in that dtype first
        output = torch.zeros((B, T, HV, V), dtype=torch.bfloat16, device=q.device)

    if backend not in ("auto", "flashinfer", "cake_gdn"):
        raise ValueError(f"unsupported GDN backend: {backend!r}")
    if backend != "flashinfer":
        if not _CAKE_GDN_AVAILABLE or _cake_gdn is None:
            if backend == "cake_gdn":
                raise RuntimeError("the source-only Cake GDN backend is not installed")
        else:
            try:
                cake_gdn_output = _run_cake_gdn_decode_nontranspose(
                    q=q,
                    k=k,
                    v=v,
                    state=state,
                    A_log=A_log,
                    a=a,
                    dt_bias=dt_bias,
                    b=b,
                    scale=scale,
                    output=output,
                    use_qk_l2norm=use_qk_l2norm,
                )
                return cake_gdn_output, state
            except _cake_gdn.CakeGDNUnsupportedError:
                if backend == "cake_gdn":
                    raise

    # State is in K-major layout [B, HV, K, V]
    # Flatten to [B*HV, K, V] to ensure proper alignment for SIMT async copy
    # This avoids alignment issues when B=1 (zero strides cause alignment failures)
    state_contiguous = state.contiguous()
    h0_source = state_contiguous.view(B * HV, K, V)

    # Execute kernel
    run_nontranspose_decode(
        h0_source,
        A_log,
        a,
        dt_bias,
        q,
        k,
        v,
        b,
        output,
        B,
        T,
        H,
        HV,
        K,
        V,
        scale,
        use_qk_l2norm,
    )

    # Copy state back only if state was not contiguous
    # (if contiguous, state_contiguous is state itself, so kernel updated state in-place)
    if state_contiguous.data_ptr() != state.data_ptr():
        state.copy_(state_contiguous)

    # Convert output to target dtype if needed (kernel outputs bfloat16)
    if output.dtype != target_dtype:
        output = output.to(target_dtype)

    return output, state


# ============================================================================
# API: MTP Decode (Multiple Token Processing, T > 1)
# ============================================================================


@flashinfer_api(trace=gdn_mtp_trace)
def gated_delta_rule_mtp(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    initial_state: torch.Tensor,
    initial_state_indices: torch.Tensor,
    A_log: torch.Tensor,
    a: torch.Tensor,
    dt_bias: torch.Tensor,
    b: torch.Tensor,
    scale: Optional[float] = None,
    output: Optional[torch.Tensor] = None,
    intermediate_states_buffer: Optional[torch.Tensor] = None,
    ssm_state_indices: Optional[torch.Tensor] = None,
    disable_state_update: Optional[bool] = None,
    use_qk_l2norm: bool = True,
    output_state_indices: Optional[torch.Tensor] = None,
    cache_replayssm: bool = False,
    replayssm_rawv: Optional[torch.Tensor] = None,
    replayssm_rawk: Optional[torch.Tensor] = None,
    replayssm_g: Optional[torch.Tensor] = None,
    replayssm_beta: Optional[torch.Tensor] = None,
) -> Tuple[torch.Tensor, torch.Tensor]:
    r"""Gated Delta Rule MTP kernel (Multiple Token Processing).

    Processes multiple tokens (``T > 1``) per call, typically used for
    speculative decoding verification.  Supports intermediate state caching
    for potential rollback scenarios.

    Parameters
    ----------
    q : torch.Tensor
        Query tensor of shape ``[B, T, H, K]``.
    k : torch.Tensor
        Key tensor of shape ``[B, T, H, K]``.
    v : torch.Tensor
        Value tensor of shape ``[B, T, HV, V]``.
    initial_state : torch.Tensor
        Initial state pool of shape ``[pool_size, HV, V, K]`` (K-last
        layout). **Must be float32** — this standalone MTP entry point
        does not support the BF16 fast path; for a BF16 K=V=128 state
        pool, call :func:`gated_delta_rule_decode_pretranspose` instead
        (which dispatches into the BF16 MTP kernel when ``T > 1``).
        When contiguous the kernel reads/writes the pool in-place via the
        free 4D→3D reshape view; a non-contiguous pool is dispatched
        through the native 4D ``use_pool_indexing=True`` path and the
        kernel writes the strided pool in place without densification.
    initial_state_indices : torch.Tensor
        Read indices mapping each batch to its slot in ``initial_state``,
        shape ``[B]``. Negative entries are treated as padding — the
        kernel skips both the read and the writeback for that batch and
        the output slot is left as the caller-allocated value (zero when
        ``output`` is ``None``).
    A_log : torch.Tensor
        Log decay parameter of shape ``[HV]``.
    a : torch.Tensor
        Input-dependent decay of shape ``[B, T, HV]``.
    dt_bias : torch.Tensor
        Decay bias of shape ``[HV]``.
    b : torch.Tensor
        Update gate input of shape ``[B, T, HV]``.
    scale : float, optional
        Scaling factor for queries.  If ``None``, uses ``1 / sqrt(K)``.
    output : torch.Tensor, optional
        Pre-allocated output tensor of shape ``[B, T, HV, V]``.
    intermediate_states_buffer : torch.Tensor, optional
        Buffer for caching intermediate states, shape ``[B, T, HV, V, K]``
        (first dim is indexed per-batch, not per-pool-slot — buffer must
        be at least ``B`` rows and contiguous; must be float32 when
        provided). When ``None``, intermediate states are not cached.
        Mutually exclusive with ``ssm_state_indices``.
    ssm_state_indices : torch.Tensor, optional
        Per-token pool scatter indices of shape ``[B, T]`` and dtype
        ``torch.int32``.  When provided, the kernel writes each intermediate
        hidden state ``h_{t+1}`` directly to
        ``initial_state[ssm_state_indices[i, t]]`` instead of accumulating
        into a dense ``intermediate_states_buffer``.  Useful for FLA-style
        speculative-decoding flows where each draft token needs its own pool
        slot.  Constraints: ``T >= 2``, ``disable_state_update=False``,
        mutually exclusive with ``intermediate_states_buffer``.
        Default: ``None``.
    disable_state_update : bool, optional
        If ``True``, the initial state is not updated.  Currently defaults
        to ``True``; pass this argument explicitly to silence the
        deprecation warning - the default will change to ``False`` in
        FlashInfer 0.8.0.

        .. deprecated::
            The implicit default of ``True`` is deprecated and will change
            to ``False`` in version 0.8.0.  Pass
            ``disable_state_update=True`` or ``disable_state_update=False``
            explicitly to silence the warning.
    use_qk_l2norm : bool
        Whether to apply L2 normalization to q and k.  Default: ``True``.
    output_state_indices : torch.Tensor, optional
        Write indices of shape ``[B]`` (int32 or int64) specifying the
        destination pool slot for each batch's updated state.  Defaults
        to ``initial_state_indices`` (read and write target the same
        slot).  Negative entries skip the writeback for that batch
        (the read still runs).
    cache_replayssm : bool
        SM100/SM103 only, FP32 checkpoint, K=V=128, T>=3.
        Persist only the fold-every-commit ReplaySSM raw input window instead
        of full intermediate hidden-state snapshots. Requires frozen-state
        verify mode (``disable_state_update=True``), no
        ``intermediate_states_buffer`` or ``ssm_state_indices``, and all four
        ``replayssm_*`` buffers. Live ``initial_state_indices`` must be unique
        and in range. Negative indices leave output and cache rows untouched.
        Windows are indexed by pool slot, overwritten on every verify, and
        consumed once by :func:`gated_delta_rule_replayssm_commit` before the
        next verify. FP16 inputs are converted to BF16 before caching, as in
        the existing MTP kernel. All tensor base addresses must be 16-byte
        aligned for vectorized loads and TMA. Default: ``False``.

        The tcgen05 TF32 specialization requires T=4..8, B=1..256, a
        contiguous checkpoint, BF16 output, int32 indices, Q/K normalization,
        and even HV/H. Other supported SM100 cases use the FP32 MTP fallback.
        TF32 changes reduction precision; outputs need not be bitwise equal
        to the fallback.
    replayssm_rawv : torch.Tensor, optional
        BF16 raw V window of shape ``[pool_size, HV, T, V]``.
    replayssm_rawk : torch.Tensor, optional
        BF16 pre-normalization K window of shape ``[pool_size, H, T, K]``.
    replayssm_g : torch.Tensor, optional
        FP32 log-decay window of shape ``[pool_size, HV, T]``.
    replayssm_beta : torch.Tensor, optional
        FP32 sigmoid-beta window of shape ``[pool_size, HV, T]``.

    Returns
    -------
    Tuple[torch.Tensor, torch.Tensor]
        ``(output, initial_state)`` where ``output`` has shape
        ``[B, T, HV, V]`` and ``initial_state`` is the updated state
        (unchanged when ``disable_state_update=True``).

    Notes
    -----
    - Standard MTP requires SM90 or later; ReplaySSM requires SM100/SM103.
    - Supports ``T > 1`` (multiple token processing).
    - State layout is K-last: ``[pool_size, HV, V, K]``.
    - Optimized for speculative decoding verification scenarios.
    """
    # Handle deprecation of disable_state_update default value
    if disable_state_update is None:
        logger.warning_once(
            "gated_delta_rule_mtp(): the 'disable_state_update' parameter currently "
            "defaults to True, but this default will change to False in FlashInfer "
            "0.8.0. Please pass disable_state_update=True or "
            "disable_state_update=False explicitly to suppress this warning."
        )
        disable_state_update = True

    # Validate input shapes
    B, T, H, K = q.shape
    _, _, HV, V = v.shape
    pool_size = initial_state.shape[0]

    # Dynamic TILE_V and vec_size selection based on batch size and sequence length
    tile_v = get_tile_v_mtp(B, T, num_v_heads=HV, v_dim=V)
    vec_size = get_vec_size_mtp(B, T)

    # Validate state shape
    assert initial_state.shape == (pool_size, HV, V, K), (
        f"Expected initial_state shape [pool_size={pool_size}, HV={HV}, V={V}, K={K}], got {initial_state.shape}"
    )

    # Validate K and V constraints
    assert K >= 128, f"K must be at least 128, got K={K}"
    assert V >= 128, f"V must be at least 128, got V={V}"
    assert V % tile_v == 0, (
        f"V must be divisible by {tile_v} to prevent out-of-bounds access, got V={V}"
    )

    # Validate dtypes
    assert q.dtype in (torch.float16, torch.bfloat16), (
        f"q must be float16/bfloat16, got {q.dtype}"
    )
    assert initial_state.dtype == torch.float32, (
        f"initial_state must be float32, got {initial_state.dtype}"
    )
    assert A_log.dtype == torch.float32, f"A_log must be float32, got {A_log.dtype}"
    assert dt_bias.dtype in (torch.bfloat16, torch.float32), (
        f"dt_bias must be bfloat16 or float32, got {dt_bias.dtype}"
    )
    assert initial_state_indices.dtype in (torch.int32, torch.int64), (
        f"initial_state_indices must be int32 or int64, "
        f"got {initial_state_indices.dtype}"
    )

    # Validate output indices shape/dtype
    if output_state_indices is not None:
        assert output_state_indices.shape == (B,), (
            f"Expected output_state_indices shape [{B}], "
            f"got {output_state_indices.shape}"
        )
        assert output_state_indices.dtype in (torch.int32, torch.int64), (
            f"output_state_indices must be int32 or int64, "
            f"got {output_state_indices.dtype}"
        )

    # Set default scale
    if scale is None:
        scale = K**-0.5

    # Allocate output if not provided
    output_provided = output is not None
    target_dtype = output.dtype if output_provided else q.dtype

    if output is None:
        output = torch.zeros((B, T, HV, V), dtype=torch.bfloat16, device=q.device)

    # Build h0_source for the kernel.
    # - Contiguous 4D pool: `.reshape()` returns a free 3D view, kernel takes
    #   the flat-mode `use_pool_indexing=False` path (existing fast path).
    # - Non-contiguous 4D pool (e.g., vLLM page-strided SSM pool): pass the
    #   4D tensor through unchanged and tell the kernel to use 4D indexing,
    #   `use_pool_indexing=True`. The kernel reads/writes via the native
    #   `[pool, HV, V, K]` layout — no densification copy.
    pool_use_pool_indexing = not initial_state.is_contiguous()
    if pool_use_pool_indexing:
        h0_source = initial_state
    else:
        h0_source = initial_state.reshape(pool_size * HV, V, K)

    # Handle intermediate states. The kernel indexes the buffer by batch (i_n),
    # not by pool slot — see `flat_idx = i_n * T * HV + i_t * HV + i_hv` inside
    # the kernel. So the buffer's first dim MUST be at least B, and the buffer
    # MUST be contiguous so the reshape returns a free view. We make both
    # contracts explicit here to fail loudly on caller mistakes (the pre-existing
    # code silently did out-of-bounds writes when buffer.shape[0] < B).
    cache_intermediate_states = intermediate_states_buffer is not None
    if cache_intermediate_states:
        buffer_size = intermediate_states_buffer.shape[0]
        cache_steps = intermediate_states_buffer.shape[1]

        assert buffer_size >= B, (
            f"intermediate_states_buffer first dim ({buffer_size}) must be "
            f"at least B={B}: the kernel indexes it by batch (i_n in [0, B)), "
            f"so a smaller buffer causes out-of-bounds writes."
        )
        assert cache_steps >= T, (
            f"intermediate_states_buffer second dimension (cache_steps={cache_steps}) "
            f"must be at least T={T} to prevent out-of-bounds indexing"
        )
        assert intermediate_states_buffer.dtype == torch.float32, (
            f"intermediate_states_buffer must be float32, "
            f"got {intermediate_states_buffer.dtype}"
        )
        assert intermediate_states_buffer.is_contiguous(), (
            "intermediate_states_buffer must be contiguous so the kernel writes "
            "land in the caller-owned tensor (reshape would otherwise materialize "
            "a throwaway copy)."
        )

        intermediate_states = intermediate_states_buffer.view(
            buffer_size * cache_steps * HV, V, K
        )
    else:
        cache_steps = T
        # This argument is compile-time dead when intermediate-state caching is
        # disabled.  Reuse an existing tensor so the ReplaySSM tcgen fast path
        # does not enqueue a tiny cudaMemset before every verify launch; the
        # generic path replaces it with its shape-compatible cached dummy.
        intermediate_states = initial_state

    # FLA-style per-token pool scatter. When provided, the kernel writes each
    # h_{t+1} directly to initial_state[ssm_state_indices[i, t]] instead of
    # to a dense intermediate_states_buffer. same_pool semantics only — the
    # final-state writeback to initial_state_indices[i] is skipped to avoid
    # clobbering h_0 (the per-token scatter at t=T-1 already wrote h_T to
    # its assigned pool slot). Caller pre-allocates B*T fresh slots from
    # the free-list and sizes the pool for at least B*(T+1) slots.
    per_token_pool_scatter = ssm_state_indices is not None
    if per_token_pool_scatter:
        assert intermediate_states_buffer is None, (
            "ssm_state_indices and intermediate_states_buffer are mutually exclusive"
        )
        assert not disable_state_update, (
            "ssm_state_indices requires state writes; disable_state_update must be False"
        )
        assert T >= 2, f"ssm_state_indices requires T >= 2 (got T={T})"
        assert ssm_state_indices.shape == (B, T), (
            f"ssm_state_indices must have shape [B={B}, T={T}], "
            f"got {tuple(ssm_state_indices.shape)}"
        )
        assert ssm_state_indices.dtype == torch.int32, (
            f"ssm_state_indices must be int32, got {ssm_state_indices.dtype}"
        )
        assert ssm_state_indices.device == q.device, (
            f"ssm_state_indices device {ssm_state_indices.device} != q device {q.device}"
        )

    replayssm_buffers = (
        replayssm_rawv,
        replayssm_rawk,
        replayssm_g,
        replayssm_beta,
    )
    if cache_replayssm:
        from .gdn_kernels.device_target import gdn_device_target

        if gdn_device_target(q.device).major != 10:
            raise ValueError("ReplaySSM caching currently requires SM100/SM103")
        assert disable_state_update, (
            "ReplaySSM verify must leave the checkpoint frozen "
            "(disable_state_update=True)"
        )
        assert intermediate_states_buffer is None, (
            "ReplaySSM replaces full intermediate-state snapshots"
        )
        assert ssm_state_indices is None, (
            "ReplaySSM and per-token state scatter are mutually exclusive"
        )
        assert pool_size > 0, "ReplaySSM requires at least one checkpoint slot"
        assert k.shape == q.shape and v.shape[:2] == (B, T), (
            "ReplaySSM Q/K/V shapes must agree"
        )
        assert a.shape == b.shape == (B, T, HV), "ReplaySSM a/b must be [B,T,HV]"
        assert A_log.shape == dt_bias.shape == (HV,), (
            "ReplaySSM gate parameters must be [HV]"
        )
        assert all(
            t.device == q.device
            for t in (
                k,
                v,
                a,
                b,
                A_log,
                dt_bias,
                initial_state,
                initial_state_indices,
                output,
            )
        ), "ReplaySSM tensors must be on the query device"
        assert K == V == 128, "ReplaySSM requires K=V=128"
        assert H > 0 and HV > 0 and HV % H == 0, "ReplaySSM requires HV divisible by H"
        assert initial_state_indices.shape == (B,), "initial_state_indices must be [B]"
        assert T >= 3, f"ReplaySSM caching requires T >= 3, got T={T}"
        assert all(t is not None for t in replayssm_buffers), (
            "cache_replayssm=True requires replayssm_rawv/rawk/g/beta"
        )
        expected_replayssm = (
            ((pool_size, HV, T, V), torch.bfloat16, "replayssm_rawv"),
            ((pool_size, H, T, K), torch.bfloat16, "replayssm_rawk"),
            ((pool_size, HV, T), torch.float32, "replayssm_g"),
            ((pool_size, HV, T), torch.float32, "replayssm_beta"),
        )
        for tensor, (shape, dtype, name) in zip(
            replayssm_buffers, expected_replayssm, strict=True
        ):
            assert tensor is not None
            assert tensor.shape == shape, (
                f"{name} must have shape {list(shape)}, got {tuple(tensor.shape)}"
            )
            assert tensor.dtype == dtype, (
                f"{name} must have dtype {dtype}, got {tensor.dtype}"
            )
            assert tensor.device == q.device, (
                f"{name} device {tensor.device} != q device {q.device}"
            )
            assert tensor.is_contiguous(), (
                f"{name} must be a contiguous per-layer ReplaySSM view"
            )
        # Contiguous views may still start at an unaligned storage offset.
        for name, tensor in (
            ("q", q),
            ("k", k),
            ("v", v),
            ("a", a),
            ("b", b),
            ("A_log", A_log),
            ("dt_bias", dt_bias),
            ("initial_state", initial_state),
            ("initial_state_indices", initial_state_indices),
            ("output_state_indices", output_state_indices),
            ("output", output),
            ("replayssm_rawv", replayssm_rawv),
            ("replayssm_rawk", replayssm_rawk),
            ("replayssm_g", replayssm_g),
            ("replayssm_beta", replayssm_beta),
        ):
            if tensor is not None and tensor.data_ptr() % 16:
                raise ValueError(f"{name} must have a 16-byte aligned base address")
    else:
        assert all(t is None for t in replayssm_buffers), (
            "replayssm_* buffers require cache_replayssm=True"
        )

    # Execute kernel
    run_mtp_decode(
        h0_source,
        intermediate_states,
        A_log,
        a,
        dt_bias,
        q,
        k,
        v,
        b,
        output,
        initial_state_indices,
        B,
        T,
        H,
        HV,
        K,
        V,
        pool_size,
        cache_steps,
        tile_v,
        vec_size,
        scale,
        use_qk_l2norm,
        disable_state_update,
        cache_intermediate_states,
        ssm_state_indices=ssm_state_indices,
        output_state_indices=output_state_indices,
        use_pool_indexing=pool_use_pool_indexing,
        cache_replayssm=cache_replayssm,
        replayssm_rawv=replayssm_rawv,
        replayssm_rawk=replayssm_rawk,
        replayssm_g=replayssm_g,
        replayssm_beta=replayssm_beta,
    )

    # No post-kernel scatter step: the contiguity assert above guarantees
    # `intermediate_states` is a view of `intermediate_states_buffer`, and the
    # `use_pool_indexing=True` path makes the kernel write the strided pool
    # in place. Writes are visible to the caller directly.

    # Convert output to target dtype if needed
    if output.dtype != target_dtype:
        output = output.to(target_dtype)

    return output, initial_state


@flashinfer_api(trace=gdn_replayssm_commit_trace)
def gated_delta_rule_replayssm_commit(
    checkpoint_state: torch.Tensor,
    rawv_cache: torch.Tensor,
    rawk_cache: torch.Tensor,
    g_cache: torch.Tensor,
    beta_cache: torch.Tensor,
    state_indices: torch.Tensor,
    accept_lens: torch.Tensor,
    *,
    track_state_indices: Optional[torch.Tensor] = None,
    track_steps: Optional[torch.Tensor] = None,
    use_qk_l2norm: bool = True,
    null_block_id: int = -1,
    backend: Literal["auto", "simt", "tcgen05"] = "auto",
) -> None:
    """Commit an accepted ReplaySSM prefix into all layers' checkpoints.

    Call :func:`gated_delta_rule_mtp` with ``cache_replayssm=True`` for each
    layer first. Verify leaves checkpoints frozen. After acceptance is known,
    call this function once, then overwrite the windows during the next verify.
    The cache is not shifted or cleared; unaccepted tokens are discarded.

    Parameters
    ----------
    checkpoint_state : torch.Tensor
        Contiguous FP32 ``[layers, slots, HV, 128, 128]`` state, K-last.
        Updated in place. All tensors must be on the same SM100/SM103 device.
    rawv_cache : torch.Tensor
        Contiguous BF16 ``[layers, slots, HV, T, 128]`` raw V windows.
    rawk_cache : torch.Tensor
        Contiguous BF16 ``[layers, slots, H, T, 128]`` pre-normalization K.
    g_cache : torch.Tensor
        Contiguous FP32 ``[layers, slots, HV, T]`` log-decay windows.
    beta_cache : torch.Tensor
        Contiguous FP32 ``[layers, slots, HV, T]`` sigmoid-beta windows.
    state_indices : torch.Tensor
        Contiguous int32 ``[B]`` pool slots. Live slots must be unique and
        in range. Slots <= ``null_block_id`` are ignored.
    accept_lens : torch.Tensor
        Contiguous int32 ``[B]`` accepted token counts in [0, T]. Zero is a
        no-op, including for optional track writes.
    track_state_indices : torch.Tensor, optional
        Contiguous int32 ``[B]`` destinations for an additional checkpoint.
        Live track slots must be in range, mutually distinct, and disjoint
        from every live ``state_indices`` slot. Paired with ``track_steps``.
    track_steps : torch.Tensor, optional
        Contiguous int32 ``[B]`` zero-based token indices to save. A step
        outside the accepted prefix leaves the destination unchanged.
    use_qk_l2norm : bool
        Normalize cached K with epsilon 1e-6. Must match verify. Default True.
    null_block_id : int
        Largest reserved/invalid slot; must be >= -1. Default -1.

    backend : {"auto", "simt", "tcgen05"}
        Without tracking and with normalized K, auto selects TF32 tcgen05
        for T=8, or T=6/7 when B>1 and ``layers * B * HV >= 256``. Otherwise it uses
        FP32 SIMT. Shorter accepted prefixes may favor explicit ``simt``;
        auto does not read accepted lengths back to the host.
        Explicit ``tcgen05`` supports normalized T=4..8 without tracking.
        Use ``simt`` to retain FP32 contractions.

    Notes
    -----
    Index values, accepted lengths and non-aliasing are caller contracts;
    they are not read back to the host. All tensor base addresses must be
    16-byte aligned for vectorized loads and TMA. Contiguous storage-offset
    views must also satisfy this alignment. Warm up before CUDA graph capture.
    """
    from .gdn_kernels.gdn_replayssm_spec_fold import (
        commit_gdn_replayssm_fold_all_layers,
    )

    if rawk_cache.ndim != 5:
        raise ValueError("rawk_cache must be [layers, slots, H, T, K]")
    commit_gdn_replayssm_fold_all_layers(
        checkpoint_state,
        rawv_cache,
        rawk_cache,
        g_cache,
        beta_cache,
        state_indices,
        accept_lens,
        rawk_cache.shape[3],
        rawk_cache.shape[2],
        track_state_indices=track_state_indices,
        track_steps=track_steps,
        use_qk_l2norm_in_kernel=use_qk_l2norm,
        null_block_id=null_block_id,
        backend=backend,
    )
