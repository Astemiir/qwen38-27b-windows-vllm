"""
Copyright (c) 2023-2026 by FlashInfer team.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import functools
import math
import os
import warnings
from types import SimpleNamespace
from typing import Any, List, Literal, Optional, Tuple, Union, overload

import torch

from .api_logging import flashinfer_api, flashinfer_experimental_api
from .trace.templates.attention import (
    gqa_paged_decode_trace,
    gqa_paged_decode_plan_trace,
    single_decode_with_kv_cache_trace,
    trtllm_batch_decode_trace_dispatch,
    xqa_batch_decode_trace,
)

## NOTE: MLA functions have been moved to mla.py, but we keep the aliases here for backward compatibility.
from .mla import (
    trtllm_batch_decode_sparse_mla_dsv4 as trtllm_batch_decode_sparse_mla_dsv4,
    trtllm_batch_decode_with_kv_cache_mla as trtllm_batch_decode_with_kv_cache_mla,
    xqa_batch_decode_with_kv_cache_mla as xqa_batch_decode_with_kv_cache_mla,
)
from .xqa import xqa, xqa_mla as xqa_mla
from .cudnn import cudnn_batch_decode_with_kv_cache as cudnn_batch_decode_with_kv_cache
from .cudnn.decode import CUDNN_AVAILABLE as _CUDNN_GRAPH_AVAILABLE
from .cudnn.utils import (
    cudnn_frontend_frost_runtime_available,
    cudnn_frontend_leads_short_caches,
    cudnn_frontend_serves_frost_decode,
)
from .cudnn.decode import CudnnDecodeGraph, prepare_cudnn_batch_decode
from .jit import (
    gen_batch_decode_module,
    gen_customize_batch_decode_module,
    gen_customize_batch_prefill_module,
    gen_single_decode_module,
    get_batch_decode_uri,
    get_batch_prefill_uri,
    get_single_decode_uri,
    setup_cubin_loader,
    gen_trtllm_gen_fmha_module,
)
from .page import get_seq_lens
from .prefill import (
    get_batch_prefill_jit_module,
    get_batch_prefill_module,
    get_single_prefill_module,
)
from .utils import (
    log2e,
    FP4Tensor,
    MaskMode,
    PosEncodingMode,
    TensorLayout,
    _check_block_tables_shape,
    _check_cached_qkv_data_type,
    _check_kv_layout,
    _check_pos_encoding_mode,
    _check_workspace_buffer_alignment,
    check_shape_dtype_device,
    get_alibi_slopes,
    _get_cache_alibi_slopes_buf,
    _get_trtllm_gen_multi_ctas_kv_counter_buffer,
    _resolve_trtllm_gen_multi_ctas_kv_counter_buffer,
    get_trtllm_gen_multi_ctas_kv_counter_bytes,
    _get_range_buf,
    _unpack_paged_kv_cache,
    canonicalize_torch_dtype,
    determine_attention_backend,
    device_support_pdl,
    get_device_sm_count,
    is_float8,
    register_custom_op,
    register_fake_op,
    ceil_div,
    round_up,
    get_compute_capability,
    SINGLE_KERNEL_TMP_SIZE,
    prepare_jit_additional_args,
)


_BATCH_DECODE_PLAN_LEGACY_POS_ARGS = (
    "pos_encoding_mode",
    "window_left",
    "logits_soft_cap",
    "q_data_type",
    "kv_data_type",
    "o_data_type",
    "data_type",
    "sm_scale",
    "rope_scale",
    "rope_theta",
    "non_blocking",
    "block_tables",
    "seq_lens",
    "fixed_split_size",
    "disable_split_kv",
    "q_len_per_req",
)


def _merge_deprecated_plan_kwargs(
    api_name: str,
    deprecated_positional_args: Tuple[Any, ...],
    legacy_positional_names: Tuple[str, ...],
    kwargs: dict[str, Any],
) -> dict[str, Any]:
    if len(deprecated_positional_args) > len(legacy_positional_names):
        raise TypeError(
            f"{api_name}.plan() accepts at most {len(legacy_positional_names)} "
            "deprecated optional positional arguments after page_size; got "
            f"{len(deprecated_positional_args)}"
        )

    merged_kwargs = dict(kwargs)
    for name, value in zip(
        legacy_positional_names, deprecated_positional_args, strict=False
    ):
        if name in merged_kwargs:
            raise TypeError(
                f"{api_name}.plan() got multiple values for argument {name!r}"
            )
        merged_kwargs[name] = value
    return merged_kwargs


def _warn_deprecated_plan_positional_args(api_name: str) -> None:
    warnings.warn(
        f"Passing optional arguments to {api_name}.plan() positionally is "
        "deprecated; pass them as keyword arguments instead. Scheduled for "
        "removal in a future release.",
        DeprecationWarning,
        stacklevel=3,
    )


_PRIMS_TS_Q_TOKEN_KV_BLOCK_SPARSE_LAZY_EXPORTS = frozenset(
    {
        "QTokenKvBlockSparsePagedTSWrapper",
        "get_q_token_kv_block_sparse_workspace_size",
        "q_token_kv_block_sparse_attention_with_paged_kv_cache",
    }
)
_PRIMS_TS_LAZY_EXPORTS = (
    frozenset(
        {
            "PrimsTSBatchDecodePlan",
            "get_prims_ts_batch_decode_workspace_size",
            "make_q_token_kv_block_sparse_qo_indptr",
            "prepare_prims_ts_batch_decode_with_kv_cache",
            "suggest_q_token_kv_block_sparse_group_size",
            "validate_q_token_kv_block_sparse_group_size",
        }
    )
    | _PRIMS_TS_Q_TOKEN_KV_BLOCK_SPARSE_LAZY_EXPORTS
)


def __getattr__(name: str):
    """Resolve PrimTS decode APIs without loading their runtime at import."""

    if name in _PRIMS_TS_LAZY_EXPORTS:
        if name in _PRIMS_TS_Q_TOKEN_KV_BLOCK_SPARSE_LAZY_EXPORTS:
            from .attention.prims_ts import q_token_kv_block_sparse_metadata

            value = getattr(q_token_kv_block_sparse_metadata, name)
        else:
            from .attention.prims_ts import decode

            value = getattr(decode, name)
        globals()[name] = value
        return value
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__():
    return sorted(set(globals()) | _PRIMS_TS_LAZY_EXPORTS)


@flashinfer_experimental_api(feature="SM110 GQA decode")
def sm110_gqa_decode(
    q: torch.Tensor,
    kv: torch.Tensor,
    sequence_lengths: torch.Tensor,
    *,
    out: Optional[torch.Tensor] = None,
    q_scale: float = 1.0,
) -> torch.Tensor:
    r"""Decode one token with the exact-SM110 FP16 GQA specialization.

    Parameters
    ----------
    q : torch.Tensor
        Contiguous FP16 query tensor with shape ``[batch, 32, 128]``.
    kv : torch.Tensor
        Contiguous FP16 stacked KV tensor with shape
        ``[batch, 2, 8, capacity, 128]``. Index 0 contains K and index 1
        contains V.
    sequence_lengths : torch.Tensor
        Contiguous CUDA int32 tensor with shape ``[batch]``. Each entry selects
        the valid KV prefix for that request and must be in ``[1, capacity]``.
    out : Optional[torch.Tensor]
        Optional caller-owned contiguous FP16 output with the same shape and
        device as ``q``. It must not alias ``q``.
    q_scale : float
        Additional query scale applied before the standard ``1 / sqrt(128)``
        attention scale.

    Returns
    -------
    torch.Tensor
        The decoded output in ``out`` when supplied, otherwise a newly
        allocated tensor.
    """

    from .experimental.sm110_gqa_decode import decode

    return decode(
        q,
        kv,
        sequence_lengths,
        out=out,
        q_scale=q_scale,
    )


@flashinfer_experimental_api(feature="Prepared SM110 GQA decode")
def prepare_sm110_gqa_decode(
    inputs: dict[str, Any], num_splits: Optional[int] = None
) -> dict[str, Any]:
    r"""Prepare repeated FP16 GQA decode launches on an exact SM110 GPU.

    Parameters
    ----------
    inputs : dict[str, Any]
        Contiguous CUDA tensors ``Q`` [B,32,128], ``KV`` [B,2,8,capacity,128],
        caller-owned ``O`` [B,32,128] (all FP16), and int32
        ``sequence_lengths`` [B]. All tensors must share one CUDA device and
        ``O`` must not alias any input storage. Optional ``q_scale`` defaults
        to 1.0 and must be finite and positive.
    num_splits : Optional[int]
        ``None`` selects the prepared shape specialization. Above capacity 64,
        ``1`` selects the original long kernel. B=1 with capacity 1024 or 4096
        also supports its fixed split count of ``10``. Above capacity 64,
        other split choices are rejected. Capacities up to 64 always use the
        original short kernel; accepted explicit counts are 1, 2, 4, 8, 10, 16.

    Returns
    -------
    dict[str, Any]
        Opaque prepared state owning tensor references and any workspace.
        Pass it to :func:`launch_sm110_gqa_decode_prepared` without modifying it.

    Notes
    -----
    This opt-in interface separates allocation and JIT compilation from
    sustained decode. Default specializations cover B=4/capacity=256 and
    B=1/capacity=1024 or 4096; other shapes use the original kernels.
    Every sequence length must remain in ``[1, capacity]`` at every launch.
    GPU length values may change between launches; preparation does not read
    them back to the host. The caller is responsible for this precondition.
    Prepare and warm up before CUDA Graph capture. Retain the prepared state
    until all asynchronous work completes and captured Graphs are retired.
    """
    from .experimental.sm110_gqa_decode import prepare_for_launch

    return prepare_for_launch(inputs, num_splits=num_splits)


@flashinfer_experimental_api(feature="Balanced paged GQA decode")
def prepare_balanced_batch_decode_with_kv_cache(
    query: torch.Tensor,
    kv_cache: Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]],
    block_tables: torch.Tensor,
    seq_lens: torch.Tensor,
    workspace_buffer: torch.Tensor,
    *,
    sm_scale: Optional[float] = None,
    q_len_per_req: int = 1,
    out: Optional[torch.Tensor] = None,
    kv_layout: str = "HND",
    backend: str = "cake",
):
    r"""Prepare on-device load-balanced BF16 paged GQA decode (SM100/SM103).

    The experimental Cake backend serves ragged paged decode batches with one
    persistent launch whose work plan is derived on the GPU from ``seq_lens``:
    long requests are split across CTAs and short ones packed, with no host
    planning, no request permutation and no per-length CUDA Graph variants
    (the kernel-owned scheduler requested in flashinfer-ai/flashinfer#4832).

    Parameters
    ----------
    query : torch.Tensor
        BF16 ``[batch * q_len_per_req, num_q_heads, 128]``; request ``b`` owns
        rows ``[b * q_len_per_req, (b + 1) * q_len_per_req)`` and query head
        ``h`` attends to KV head ``h // 8`` (exactly eight query heads per KV
        head).
    kv_cache : Tuple[torch.Tensor, torch.Tensor]
        ``(k_cache, v_cache)``, each BF16 ``[num_pages, num_kv_heads, 16, 128]``
        (``HND`` pages of 16 tokens).
    block_tables : torch.Tensor
        int32 ``[batch, max_pages]`` page ids per request.  A width that is a
        multiple of eight pages is read in place; other widths are copied
        into a padded table inside ``workspace_buffer`` at preparation.
    seq_lens : torch.Tensor
        int32 ``[batch]`` KV lengths including the ``q_len_per_req`` new
        tokens.  Read on device at every launch.
    workspace_buffer : torch.Tensor
        Caller-owned CUDA bytes of at least
        :func:`flashinfer.experimental.balanced_gqa_decode.cake_backend.balanced_gqa_decode_workspace_size`;
        the split partials and the kernel's self-resetting counters live here,
        so the region must not be shared with other work between launches.
    sm_scale : Optional[float]
        Softmax scale; defaults to ``1 / sqrt(128)``.
    q_len_per_req : int
        Query tokens per request (speculative / MTP verify).  Row ``j`` of a
        request attends causally to its first ``seq_len - (q_len_per_req - 1 - j)``
        KV positions.
    out : Optional[torch.Tensor]
        Optional caller-owned BF16 ``[batch * q_len_per_req, num_q_heads, 128]``.
    kv_layout : str
        Only ``"HND"`` is supported.
    backend : str
        Only ``"cake"`` is supported.

    Returns
    -------
    BalancedGQADecodeRunner
        Calling it launches the decode on the current stream with no CUDA
        allocation or host synchronization and returns ``out``.  CUDA Graph
        capture belongs to the caller; a captured runner replays correctly
        for any lengths later written into ``seq_lens``.  See
        ``flashinfer/experimental/balanced_gqa_decode/README.md``.
    """
    if backend != "cake":
        raise ValueError("balanced GQA decode currently supports backend='cake'")
    from .experimental.balanced_gqa_decode.cake_backend import (
        prepare_balanced_batch_decode_with_kv_cache as prepare,
    )

    return prepare(
        query,
        kv_cache,
        block_tables,
        seq_lens,
        workspace_buffer,
        sm_scale=sm_scale,
        q_len_per_req=q_len_per_req,
        out=out,
        kv_layout=kv_layout,
        backend="cake",
    )


@flashinfer_experimental_api(feature="Prepared SM110 GQA decode launch")
def launch_sm110_gqa_decode_prepared(prepared: dict[str, Any]) -> torch.Tensor:
    r"""Launch prepared decode on the current PyTorch stream and return its O.

    ``prepared`` is the unmodified result of :func:`prepare_sm110_gqa_decode`.
    Its tensors and workspace must remain alive through asynchronous launches
    and CUDA Graph replays. GPU sequence lengths may change within the valid
    range, while shapes, storage, and query scale remain fixed.

    Concurrent invocations require independent prepared objects and output/
    workspace storage. A prepared object can be reused on ordered streams,
    including event-ordered stream handoffs. No allocations or host reads of
    sequence lengths occur in this launch path.
    """
    from .experimental.sm110_gqa_decode import launch_prepared

    return launch_prepared(prepared)


@functools.cache
def get_single_decode_module(*args):
    uri = get_single_decode_uri(*args)
    module = gen_single_decode_module(*args).build_and_load()
    run_func = module.run

    # torch library for single_decode_with_kv_cache

    @register_custom_op(f"flashinfer::{uri}_run", mutates_args=("tmp", "o"))
    def run_single_decode(
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        tmp: torch.Tensor,
        o: torch.Tensor,
        maybe_lse: Optional[torch.Tensor],
        alibi_slopes: Optional[torch.Tensor],
        kv_layout_code: int,
        window_left: int,
        logits_soft_cap: float,
        sm_scale: float,
        rope_scale: float,
        rope_theta: float,
    ) -> None:
        run_func(
            q,
            k,
            v,
            tmp,
            o,
            maybe_lse,
            kv_layout_code,
            window_left,
            alibi_slopes,
            logits_soft_cap,
            sm_scale,
            1.0 / rope_scale,  # rope_rcp_scale
            1.0 / rope_theta,  # rope_rcp_theta
        )

    @register_fake_op(f"flashinfer::{uri}_run")
    def _fake_run_single_decode(
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        tmp: torch.Tensor,
        o: torch.Tensor,
        maybe_lse: Optional[torch.Tensor],
        alibi_slopes: Optional[torch.Tensor],
        kv_layout_code: int,
        window_left: int,
        logits_soft_cap: float,
        sm_scale: float,
        rope_scale: float,
        rope_theta: float,
    ) -> None:
        pass

    # Register the module.
    return SimpleNamespace(run=run_single_decode)


@functools.cache
def get_batch_decode_jit_module(module_name: str, jit_module: Any):
    plan_func = jit_module.plan
    workspace_size_func = getattr(jit_module, "workspace_size", None)
    run_func = jit_module.run

    @register_custom_op(
        f"flashinfer::{module_name}_run",
        mutates_args=(
            "float_workspace_buffer",
            "int_workspace_buffer",
            "paged_k_cache",
            "paged_v_cache",
            "o",
            "maybe_lse",
        ),
    )
    def run_batch_decode(
        float_workspace_buffer: torch.Tensor,
        int_workspace_buffer: torch.Tensor,
        plan_info_vec: List[int],
        q: torch.Tensor,
        paged_k_cache: Optional[torch.Tensor],
        paged_v_cache: Optional[torch.Tensor],
        paged_kv_indptr: torch.Tensor,
        paged_kv_indices: torch.Tensor,
        paged_kv_last_page_len: torch.Tensor,
        o: torch.Tensor,
        maybe_lse: Optional[torch.Tensor],
        kv_layout_code: int,
        window_left: int,
        enable_pdl: bool,
        *args,
    ) -> None:
        run_func(
            float_workspace_buffer,
            int_workspace_buffer,
            plan_info_vec,
            q,
            paged_k_cache,
            paged_v_cache,
            paged_kv_indptr,
            paged_kv_indices,
            paged_kv_last_page_len,
            o,
            maybe_lse,
            kv_layout_code,
            window_left,
            enable_pdl,
            *args,
        )

    @register_fake_op(f"flashinfer::{module_name}_run")
    def _fake_run_batch_decode(
        float_workspace_buffer: torch.Tensor,
        int_workspace_buffer: torch.Tensor,
        plan_info_vec: List[int],
        q: torch.Tensor,
        paged_k_cache: Optional[torch.Tensor],
        paged_v_cache: Optional[torch.Tensor],
        paged_kv_indptr: torch.Tensor,
        paged_kv_indices: torch.Tensor,
        paged_kv_last_page_len: torch.Tensor,
        o: torch.Tensor,
        maybe_lse: Optional[torch.Tensor],
        kv_layout_code: int,
        window_left: int,
        enable_pdl: bool,
        *args,
    ) -> None:
        pass

    return SimpleNamespace(
        plan=plan_func,
        workspace_size=workspace_size_func,
        run=run_batch_decode,
    )


@functools.cache
def get_batch_decode_module(*args):
    uri = get_batch_decode_uri(*args)
    mod = gen_batch_decode_module(*args).build_and_load()
    plan_func = mod.plan
    workspace_size_func = getattr(mod, "workspace_size", None)
    run_func = mod.run

    # torch library for batch_decode_with_paged_kv_cache_run

    @register_custom_op(
        f"flashinfer::{uri}_run",
        mutates_args=(
            "float_workspace_buffer",
            "int_workspace_buffer",
            "paged_k_cache",
            "paged_v_cache",
            "o",
            "maybe_lse",
        ),
    )
    def run_batch_decode(
        float_workspace_buffer: torch.Tensor,
        int_workspace_buffer: torch.Tensor,
        plan_info_vec: List[int],
        q: torch.Tensor,
        paged_k_cache: Optional[torch.Tensor],
        paged_v_cache: Optional[torch.Tensor],
        paged_kv_indptr: torch.Tensor,
        paged_kv_indices: torch.Tensor,
        paged_kv_last_page_len: torch.Tensor,
        o: torch.Tensor,
        maybe_lse: Optional[torch.Tensor],
        kv_layout_code: int,
        window_left: int,
        enable_pdl: bool,
        alibi_slopes: Optional[torch.Tensor],
        logits_soft_cap: float,
        sm_scale: float,
        rope_scale: float,
        rope_theta: float,
    ) -> None:
        run_func(
            float_workspace_buffer,
            int_workspace_buffer,
            plan_info_vec,
            q,
            paged_k_cache,
            paged_v_cache,
            paged_kv_indptr,
            paged_kv_indices,
            paged_kv_last_page_len,
            o,
            maybe_lse,
            kv_layout_code,
            window_left,
            enable_pdl,
            alibi_slopes,
            logits_soft_cap,
            sm_scale,
            1.0 / rope_scale,  # rope_rcp_scale
            1.0 / rope_theta,  # rope_rcp_theta
        )

    @register_fake_op(f"flashinfer::{uri}_run")
    def _fake_run_batch_decode(
        float_workspace_buffer: torch.Tensor,
        int_workspace_buffer: torch.Tensor,
        plan_info_vec: List[int],
        q: torch.Tensor,
        paged_k_cache: Optional[torch.Tensor],
        paged_v_cache: Optional[torch.Tensor],
        paged_kv_indptr: torch.Tensor,
        paged_kv_indices: torch.Tensor,
        paged_kv_last_page_len: torch.Tensor,
        o: torch.Tensor,
        maybe_lse: Optional[torch.Tensor],
        kv_layout_code: int,
        window_left: int,
        enable_pdl: bool,
        alibi_slopes: Optional[torch.Tensor],
        logits_soft_cap: float,
        sm_scale: float,
        rope_scale: float,
        rope_theta: float,
    ) -> None:
        pass

    # Register the module.
    #
    # Note that plan is not part of model logic. It should not be included in
    # Cuda Graph or torch.compile. So, we don't provide a torch library for plan.
    return SimpleNamespace(
        plan=plan_func,
        workspace_size=workspace_size_func,
        run=run_batch_decode,
    )


@functools.cache
def get_trtllm_gen_fmha_module():
    mod = gen_trtllm_gen_fmha_module()
    op = mod.build_and_load()
    for library_path in mod.get_library_paths():
        setup_cubin_loader(library_path)
    return op


# Granularity (in tokens) at which the cudnn decode backend rounds up
# max_seq_len_kv / block-table width, so one built cuDNN graph serves many steps.
# 2048 is also where cudnn-frontend 1.30's placement starts ranking its FROST decode
# tile ahead of the backend's prefill-class engine for multi-token rows (that engine
# is ~8x slower than fa2 there); declaring at least that keeps short caches fast.
_CUDNN_DECODE_MAX_KV_BUCKET = 2048

# backend="auto" on the decode wrapper: "0" never resolves to cudnn, "1" applies
# the cudnn rule on an older cudnn-frontend too (benchmarking / bisection),
# unset applies the rule below on cudnn-frontend 1.30+.
_DECODE_AUTO_CUDNN_ENV = "FLASHINFER_DECODE_AUTO_CUDNN"


# The auto rule's envelope (B200 matrix in _auto_decode_prefers_cudnn): the FROST
# decode tile packs q_len_per_req * group query rows into one 128-row CTA per
# (batch, KV head) unit, and wins once it has at least 32 of them and at least
# 64 CTAs.
_AUTO_CUDNN_MIN_ROWS = 32
_AUTO_CUDNN_MAX_ROWS = 128
_AUTO_CUDNN_MIN_UNITS = 64


def _auto_decode_prefers_cudnn(
    *,
    compute_capability: Tuple[int, int],
    frontend_serves_frost_decode: bool,
    cudnn_available: bool,
    q_data_type: torch.dtype,
    kv_data_type: torch.dtype,
    o_data_type: torch.dtype,
    head_dim: int,
    num_qo_heads: int,
    num_kv_heads: int,
    batch_size: int,
    page_size: int,
    pos_encoding_mode: str,
    window_left: int,
    logits_soft_cap: float,
    q_len_per_req: int,
    fa2_available: bool = True,
    declared_kv_len: Optional[int] = None,
    frontend_leads_short_caches: bool = False,
    frost_runtime_available: bool = True,
    fixed_split_size: Optional[int] = None,
    disable_split_kv: bool = False,
    override: Optional[str] = None,
) -> bool:
    """Whether ``backend="auto"`` should run this decode plan on cuDNN.

    cuDNN takes multi-token decode rows (speculative / MTP verification,
    ``2 <= q_len_per_req <= 4``) of fp16 / bf16 head_dim-128 GQA models on
    SM100 / SM103 when cudnn-frontend's default SM100 engine serves them with
    its FROST decode tile and that tile has enough work: one 128-row CTA per
    (batch, KV head) unit packing the group's rows, so the envelope is
    ``q_len_per_req * group`` in [32, 128] rows per CTA and ``batch_size *
    num_kv_heads >= 64`` CTAs. Measured on B200 (cudnn-frontend 1.30.0 default
    placement, cuDNN 9.26, bf16, page 16, CUDA-graph replay, kernel time
    through the wrapper, cuDNN vs fa2's tensor-core decode, 1k / 4k / 16k
    caches): 64/4 two rows at b=32, 24 vs 50, 65 vs 139 and 480 vs 533 us;
    four rows, 24 vs 65, 65 vs 184 and 220 vs 529 us; 64/8 four rows at b=8,
    26 vs 29, 47 vs 69 and 217 vs 251 us; 64/4 two rows at b=128, 82 vs 126,
    482 vs 530 and 1878 vs 2046 us. Below the envelope the tile loses: 16 rows
    per CTA (64/8 at two rows) 1.0-1.7x at every batch from 8 and every cache,
    32 CTAs (64/4 at b=8) 1.2x at a 1k cache and a win only from 4k, b=1 about
    2x. Also outside: single-token decode (the frontend ranks its backend
    decode engine ahead of the tile there, and that engine's standing against
    fa2 is mixed: 64/4 at b=32 0.7-1.1x, at b=128 0.9-1.8x), a GQA group that
    does not divide 128 (96/8 packs 4 of 12 heads per row group: 1.1-1.9x),
    d64 / d256 (32/2 is 0.65-1.1x at b=32 and 1.2-3x below), a sliding window
    (the tile's window path is unmeasured), RoPE / soft-cap (the cudnn path
    does not apply them), and more than 128 rows per CTA, where cuDNN serves
    the graph with its prefill tile.

    ``fa2_available=False`` says the plan has no fa2 kernel at all (multi-token
    rows without tensor cores: the CUDA-core decode kernel is single-token);
    cudnn then takes every plan its decode path can run (fp16 / bf16 d128 /
    d256, no RoPE / soft-cap), whatever the envelope says, where the wrapper
    used to raise.

    ``declared_kv_len`` is the cache length a caller-owned ``block_tables``
    declares to cuDNN (its width in pages times the page size); the auto-built
    table declares at least ``_CUDNN_DECODE_MAX_KV_BUCKET`` tokens. Below 2048
    tokens cudnn-frontend 1.30 ranks the backend's prefill-class engine ahead
    of the decode tile for multi-token rows (~8x fa2's time), so such a plan
    stays on fa2 unless ``frontend_leads_short_caches`` (1.31+, which ranks the
    tile first at every cache length) or fa2 cannot serve the rows at all.

    ``frost_runtime_available`` says the frontend's FROST engines can actually
    run on this install: its own CuTe-DSL check (``nvidia-cutlass-dsl``
    present and not below its floor, 4.7.0 today, where both packages'
    dependency metadata admit 4.6.2). Without it the frontend's rows decline
    and the backend engine serves the graph, so the performance-driven route
    stays on fa2; the no-fa2 route and the ``1`` override are not gated by it.

    ``fixed_split_size`` / ``disable_split_kv`` are fa2's explicit split
    controls, the batch-invariance contract documented for fixed splitting
    (the same request produces the same bits whatever else is in the batch).
    cuDNN's plans have no equivalent, so a caller passing either keeps fa2
    wherever fa2 can serve the rows.

    cudnn-frontend 1.30+ is required unless forced: an older frontend serves
    the graph with the backend engine, which is ~8x slower than fa2 on
    multi-token rows and rejects a sink at ``q_len_per_req == 1`` (1.30+ falls
    through to the FROST row for that). ``FLASHINFER_DECODE_AUTO_CUDNN``
    overrides: ``0`` never, ``1`` also on an older frontend (benchmarking /
    bisection).
    """
    if override is None:
        override = os.environ.get(_DECODE_AUTO_CUDNN_ENV, "")
    override = override.strip().lower()
    if override in ("0", "false", "no", "off"):
        return False
    forced = override in ("1", "true", "yes", "on")
    if not cudnn_available or not (frontend_serves_frost_decode or forced):
        return False
    if tuple(compute_capability) not in ((10, 0), (10, 3)):
        return False
    if q_data_type not in (torch.float16, torch.bfloat16) or not (
        q_data_type == kv_data_type == o_data_type
    ):
        return False
    if num_kv_heads <= 0 or num_qo_heads % num_kv_heads != 0:
        return False
    if pos_encoding_mode != "NONE" or (logits_soft_cap or 0.0) > 0:
        return False
    if not fa2_available:
        # Nothing else can run these rows: take cudnn wherever its decode
        # path serves the plan (window included), envelope or not.
        return q_len_per_req >= 2 and head_dim in (128, 256)
    if (fixed_split_size is not None and fixed_split_size > 0) or disable_split_kv:
        # fa2's explicit split controls are its batch-invariance contract
        # (a positive fixed_split_size pins the KV split -- the planner's
        # own "unset" is -1 -- and disable_split_kv removes it); cuDNN's
        # plans have no equivalent, so a caller who asked for them keeps fa2
        # wherever fa2 can serve the rows (the no-fa2 case above has nothing
        # to keep).
        return False
    if not (frost_runtime_available or forced):
        # The frontend is new enough but its FROST engines cannot run on this
        # install (CuTe DSL below the frontend's floor): the backend engine
        # would serve the graph, ~8x slower than fa2 on these rows.
        return False
    if (
        declared_kv_len is not None
        and declared_kv_len < _CUDNN_DECODE_MAX_KV_BUCKET
        and not frontend_leads_short_caches
    ):
        # A caller-owned block table shorter than the bucket would hand the
        # rows to the backend's prefill-class engine on cudnn-frontend 1.30.
        return False
    if head_dim != 128:
        return False
    group = num_qo_heads // num_kv_heads
    if group > 128 or 128 % group != 0:
        return False
    if page_size <= 0 or page_size % 8 != 0:
        return False
    if not (128 % page_size == 0 or page_size % 128 == 0):
        return False
    if window_left >= 0:
        return False
    # Multi-token rows only: single-token decode is served by cuDNN's backend
    # decode engine (the frontend ranks it ahead of the FROST tile), whose
    # standing against fa2 is mixed; see the docstring.
    if not 2 <= q_len_per_req <= 4:
        return False
    # The FROST decode tile has to be the kernel that serves the graph (it
    # packs at most 128 rows; past that cuDNN runs its prefill tile and loses)
    # and has to have enough rows per CTA and enough CTAs to beat fa2.
    rows = q_len_per_req * group
    if not _AUTO_CUDNN_MIN_ROWS <= rows <= _AUTO_CUDNN_MAX_ROWS:
        return False
    return batch_size * num_kv_heads >= _AUTO_CUDNN_MIN_UNITS


_TRTLLM_GEN_BF16Q_FP8KV_TRANSFORM_MODES = {
    "k_only": 1,
    "separate_kv": 2,
}


def _get_bf16q_fp8kv_transform_mode(
    mode: Literal["k_only", "separate_kv"],
) -> int:
    try:
        return _TRTLLM_GEN_BF16Q_FP8KV_TRANSFORM_MODES[mode]
    except KeyError as err:
        raise ValueError(
            "bf16q_fp8kv_transform_mode must be one of 'k_only' or 'separate_kv'"
        ) from err


@flashinfer_api
def single_decode_with_kv_cache_with_jit_module(
    jit_module: Any,
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    *args,
    kv_layout: str = "NHD",
    window_left: int = -1,
    return_lse: bool = False,
):
    r"""Single-request decode using a pre-compiled JIT module.

    This is the low-level entry point used by :func:`single_decode_with_kv_cache` after
    backend dispatch; user code should normally call ``single_decode_with_kv_cache``
    directly.  This function is exposed for advanced users who already hold a compiled
    JIT module (for example to customize the attention variant via extra kernel
    arguments).

    Parameters
    ----------
    jit_module : Any
        Compiled JIT module returned by one of the ``gen_*_module`` factories.
    q : torch.Tensor
        Query tensor, shape ``[num_qo_heads, head_dim]``.
    k : torch.Tensor
        Key tensor, shape ``[kv_len, num_kv_heads, head_dim]`` (``NHD``) or
        ``[num_kv_heads, kv_len, head_dim]`` (``HND``).
    v : torch.Tensor
        Value tensor, layout matches ``k``.
    *args
        Extra positional arguments forwarded to the JIT module's ``run`` symbol
        (e.g. soft-cap or sliding-window parameters required by the chosen variant).
    kv_layout : str
        Layout of ``k`` and ``v``, either ``"NHD"`` or ``"HND"``.  Defaults to ``"NHD"``.
    window_left : int
        Left window size for sliding-window attention; ``-1`` disables it.
    return_lse : bool
        If ``True``, allocate an LSE buffer (shape ``(num_qo_heads,)``,
        ``float32``) for the kernel to write into.  Defaults to ``False``.
        **Note: the buffer is allocated and filled by the kernel but is not
        currently returned to the caller** -- this function always returns
        just ``o``.  Callers who need the LSE should use
        :func:`single_decode_with_kv_cache` instead.

    Returns
    -------
    torch.Tensor
        Output tensor with shape matching ``q``.  The LSE buffer (when
        ``return_lse=True``) is discarded; see the parameter note.
    """
    device = q.device
    tmp = torch.empty(SINGLE_KERNEL_TMP_SIZE, dtype=torch.uint8, device=device)
    o = torch.empty_like(q)
    if return_lse:
        lse = torch.empty((q.size(0)), dtype=torch.float32, device=device)
    else:
        lse = None
    jit_module.run(
        q,
        k,
        v,
        tmp,
        o,
        lse,
        TensorLayout[kv_layout].value,
        window_left,
        *args,
    )
    return o


@overload
def single_decode_with_kv_cache(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    kv_layout: str = "NHD",
    pos_encoding_mode: str = "NONE",
    use_tensor_cores: bool = False,
    q_scale: Optional[float] = None,
    k_scale: Optional[float] = None,
    v_scale: Optional[float] = None,
    window_left: int = -1,
    logits_soft_cap: Optional[float] = None,
    sm_scale: Optional[float] = None,
    rope_scale: Optional[float] = None,
    rope_theta: Optional[float] = None,
    return_lse: Literal[False] = False,
) -> torch.Tensor: ...


@overload
def single_decode_with_kv_cache(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    kv_layout: str = "NHD",
    pos_encoding_mode: str = "NONE",
    use_tensor_cores: bool = False,
    q_scale: Optional[float] = None,
    k_scale: Optional[float] = None,
    v_scale: Optional[float] = None,
    window_left: int = -1,
    logits_soft_cap: Optional[float] = None,
    sm_scale: Optional[float] = None,
    rope_scale: Optional[float] = None,
    rope_theta: Optional[float] = None,
    return_lse: Literal[True] = True,
) -> Tuple[torch.Tensor, torch.Tensor]: ...


@flashinfer_api(trace=single_decode_with_kv_cache_trace)
def single_decode_with_kv_cache(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    kv_layout: str = "NHD",
    pos_encoding_mode: str = "NONE",
    use_tensor_cores: bool = False,
    q_scale: Optional[float] = None,
    k_scale: Optional[float] = None,
    v_scale: Optional[float] = None,
    window_left: int = -1,
    logits_soft_cap: Optional[float] = None,
    sm_scale: Optional[float] = None,
    rope_scale: Optional[float] = None,
    rope_theta: Optional[float] = None,
    return_lse: bool = False,
) -> Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
    r"""Decode attention with KV Cache for single request, return attention output.

    Parameters
    ----------
    q : torch.Tensor
        The query tensor, shape: ``[num_qo_heads, head_dim]``.
    k : torch.Tensor
        The key tensor, shape: ``[kv_len, num_kv_heads, head_dim]`` if :attr:`kv_layout`
        is ``NHD``, or ``[num_kv_heads, kv_len, head_dim]`` if :attr:`kv_layout` is
        ``HND``.
    v : torch.Tensor
        The value tensor, shape: ``[kv_len, num_kv_heads, head_dim]`` if
        :attr:`kv_layout` is ``NHD``, or ``[num_kv_heads, kv_len, head_dim]`` if
        :attr:`kv_layout` is ``HND``.
    kv_layout : str
        The layout of the input k/v tensors, could be either ``NHD`` or ``HND``.
    pos_encoding_mode : str
        The position encoding applied inside attention kernels, could be
        ``NONE``/``ROPE_LLAMA`` (LLAMA style rotary embedding) /``ALIBI``.
        Defaults to ``NONE``.
    use_tensor_cores: bool
        Whether to use tensor cores for the computation. Will be faster for large group
        size in grouped query attention. Defaults to ``False``.
    q_scale : Optional[float]
        The calibration scale of query for fp8 input, if not provided, will be set to ``1.0``.
    k_scale : Optional[float]
        The calibration scale of key for fp8 input, if not provided, will be set to ``1.0``.
    v_scale : Optional[float]
        The calibration scale of value for fp8 input, if not provided, will be set to ``1.0``.
    window_left : int
        The left (inclusive) window size for the attention window, when set to ``-1``, the window
        size will be set to the full length of the sequence. Defaults to ``-1``.
    logits_soft_cap : Optional[float]
        The attention logits soft capping value (used in Gemini, Grok and Gemma-2, etc.), if not
        provided, will be set to ``0``. If greater than 0, the logits will be capped according to
        formula:
        :math:`\texttt{logits_soft_cap} \times \mathrm{tanh}(x / \texttt{logits_soft_cap})`,
        where :math:`x` is the input logits.
    sm_scale : Optional[float]
        The scale of softmax, if not provided, will be set to ``1 / sqrt(head_dim)``.
    rope_scale : Optional[float]
        The scale used in RoPE interpolation, if not provided, will be set to ``1.0``.
    rope_theta : Optional[float]
        The theta used in RoPE, if not provided, will be set to ``1e4``.
    return_lse : bool
        Whether to return the log sum exp value of the attention logits.

    Returns
    -------
    Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]
        If :attr:`return_lse` is ``False``, the attention output, shape: ``[qo_len, num_qo_heads, head_dim_vo]``.
        If :attr:`return_lse` is ``True``, a tuple of two tensors:

        * The attention output, shape: ``[num_qo_heads, head_dim_vo]``.
        * The log sum exp value, shape: ``[num_qo_heads]``.

    Examples
    --------

    >>> import torch
    >>> import flashinfer
    >>> kv_len = 4096
    >>> num_qo_heads = 32
    >>> num_kv_heads = 32
    >>> head_dim = 128
    >>> q = torch.randn(num_qo_heads, head_dim).half().to("cuda:0")
    >>> k = torch.randn(kv_len, num_kv_heads, head_dim).half().to("cuda:0")
    >>> v = torch.randn(kv_len, num_kv_heads, head_dim).half().to("cuda:0")
    >>> o = flashinfer.single_decode_with_kv_cache(q, k, v)
    >>> o.shape
    torch.Size([32, 128])

    Note
    ----
    The ``num_qo_heads`` must be a multiple of ``num_kv_heads``. If ``num_qo_heads`` is
    not equal to ``num_kv_heads``, the function will use
    `grouped query attention <https://arxiv.org/abs/2305.13245>`_.
    """
    _check_pos_encoding_mode(pos_encoding_mode)
    _check_kv_layout(kv_layout)
    tmp = torch.empty(SINGLE_KERNEL_TMP_SIZE, dtype=torch.uint8, device=q.device)
    head_dim = q.shape[-1]
    if logits_soft_cap is None:
        logits_soft_cap = 0.0
    if sm_scale is None:
        sm_scale = 1.0 / math.sqrt(head_dim)
    if q_scale is not None:
        sm_scale *= q_scale
    if k_scale is not None:
        sm_scale *= k_scale
    if rope_scale is None:
        rope_scale = 1.0
    if rope_theta is None:
        rope_theta = 1e4
    num_qo_heads = q.shape[0]

    lse = None
    if return_lse:
        lse = torch.empty((num_qo_heads,), dtype=torch.float32, device=q.device)

    if use_tensor_cores:
        out = torch.empty_like(q.unsqueeze(0))
        get_single_prefill_module(
            "fa2",
            q.dtype,
            k.dtype,
            q.dtype,
            head_dim,  # head_dim_qk
            head_dim,  # head_dim_vo
            PosEncodingMode[pos_encoding_mode].value,
            window_left != -1,  # use_sliding_window
            logits_soft_cap > 0,  # use_logits_soft_cap
            False,  # use_fp16_qk_reduction
        ).run(
            q.unsqueeze(0),
            k,
            v,
            tmp,
            out,
            lse.unsqueeze(0) if lse is not None else None,
            MaskMode.NON_CAUSAL.value,
            TensorLayout[kv_layout].value,
            window_left,
            None,  # packed_custom_mask
            get_alibi_slopes(num_qo_heads, device=q.device)
            if pos_encoding_mode == "ALIBI"
            else None,
            logits_soft_cap,
            sm_scale,
            None,  # scale_q, not supported yet
            None,  # scale_k
            None,  # scale_v
            rope_scale,
            rope_theta,
        )
        out = out.squeeze(0)
        if return_lse:
            lse = lse.squeeze(0)
    else:
        out = torch.empty_like(q)
        get_single_decode_module(
            q.dtype,
            k.dtype,
            q.dtype,
            head_dim,  # head_dim_qk
            head_dim,  # head_dim_vo
            PosEncodingMode[pos_encoding_mode].value,
            window_left != -1,  # use_sliding_window
            logits_soft_cap > 0,  # use_logits_soft_cap
        ).run(
            q,
            k,
            v,
            tmp,
            out,
            lse,
            get_alibi_slopes(num_qo_heads, device=q.device)
            if pos_encoding_mode == "ALIBI"
            else None,
            TensorLayout[kv_layout].value,
            window_left,
            logits_soft_cap,
            sm_scale,
            rope_scale,
            rope_theta,
        )

    if v_scale is not None:
        # TODO(Zihao): fused into kernel
        if out.itemsize == 1:
            out = (out.to(float) * v_scale).to(out.dtype)
        else:
            out *= v_scale
    if return_lse:
        return out, lse
    else:
        return out


class BatchDecodeWithPagedKVCacheWrapper:
    r"""Wrapper class for decode attention with paged kv-cache (first proposed in
    `vLLM <https://arxiv.org/abs/2309.06180>`_) for batch of requests.

    Check :ref:`our tutorial<kv-layout>` for page table layout.

    Examples
    --------
    >>> import torch
    >>> import flashinfer
    >>> num_layers = 32
    >>> num_qo_heads = 64
    >>> num_kv_heads = 8
    >>> head_dim = 128
    >>> max_num_pages = 128
    >>> page_size = 16
    >>> # allocate 128MB workspace buffer
    >>> workspace_buffer = torch.zeros(128 * 1024 * 1024, dtype=torch.uint8, device="cuda:0")
    >>> decode_wrapper = flashinfer.BatchDecodeWithPagedKVCacheWrapper(
    ...     workspace_buffer, "NHD"
    ... )
    >>> batch_size = 7
    >>> kv_page_indices = torch.arange(max_num_pages).int().to("cuda:0")
    >>> kv_page_indptr = torch.tensor(
    ...     [0, 17, 29, 44, 48, 66, 100, 128], dtype=torch.int32, device="cuda:0"
    ... )
    >>> # 1 <= kv_last_page_len <= page_size
    >>> kv_last_page_len = torch.tensor(
    ...     [1, 7, 14, 4, 3, 1, 16], dtype=torch.int32, device="cuda:0"
    ... )
    >>> kv_cache_at_layer = [
    ...     torch.randn(
    ...         max_num_pages, 2, page_size, num_kv_heads, head_dim, dtype=torch.float16, device="cuda:0"
    ...     ) for _ in range(num_layers)
    ... ]
    >>> # create auxiliary data structures for batch decode attention
    >>> decode_wrapper.plan(
    ...     kv_page_indptr,
    ...     kv_page_indices,
    ...     kv_last_page_len,
    ...     num_qo_heads,
    ...     num_kv_heads,
    ...     head_dim,
    ...     page_size,
    ...     pos_encoding_mode="NONE",
    ...     data_type=torch.float16
    ... )
    >>> outputs = []
    >>> for i in range(num_layers):
    ...     q = torch.randn(batch_size, num_qo_heads, head_dim).half().to("cuda:0")
    ...     kv_cache = kv_cache_at_layer[i]
    ...     # compute batch decode attention, reuse auxiliary data structures for all layers
    ...     o = decode_wrapper.run(q, kv_cache)
    ...     outputs.append(o)
    ...
    >>> outputs[0].shape
    torch.Size([7, 64, 128])

    Note
    ----
    To accelerate computation, FlashInfer's batch decode attention creates some
    auxiliary data structures, these data structures can be reused across multiple
    batch decode attention calls (e.g. different Transformer layers). This wrapper class
    manages the lifecycle of these data structures.
    """

    @flashinfer_api
    def __init__(
        self,
        float_workspace_buffer: torch.Tensor,
        kv_layout: str = "NHD",
        use_cuda_graph: bool = False,
        use_tensor_cores: bool = False,
        paged_kv_indptr_buffer: Optional[torch.Tensor] = None,
        paged_kv_indices_buffer: Optional[torch.Tensor] = None,
        paged_kv_last_page_len_buffer: Optional[torch.Tensor] = None,
        backend: str = "auto",
        jit_args: Optional[List[Any]] = None,
    ) -> None:
        r"""Constructor of :class:`BatchDecodeWithPagedKVCacheWrapper`.

        Parameters
        ----------
        float_workspace_buffer : torch.Tensor. Must be initialized to 0 for its first use.
            The user reserved float workspace buffer used to store intermediate attention results
            in the split-k algorithm. The recommended size is 128MB, the device of the workspace
            buffer should be the same as the device of the input tensors. The buffer must be
            16-byte aligned; tensors created by ``torch.empty`` satisfy this on supported devices.

        kv_layout : str
            The layout of the input k/v tensors, could be either ``NHD`` or ``HND``.

        use_cuda_graph : bool
            Whether to enable CUDAGraph for batch decode attention, if enabled, the
            auxiliary data structures will be stored as the provided buffers. The ``batch_size``
            cannot change during the lifecycle of this wrapper when CUDAGraph is enabled.

        use_tensor_cores : bool
            Whether to use tensor cores for the computation. Will be faster for large group
            size in grouped query attention. Defaults to ``False``.

        paged_kv_indptr_buffer : Optional[torch.Tensor]
            The user reserved buffer on GPU to store the indptr of the paged kv cache, the size
            of the buffer should be ``[batch_size + 1]``.
            Only needed when ``use_cuda_graph`` is ``True``.

        paged_kv_indices_buffer : Optional[torch.Tensor]
            The user reserved buffer on GPU to store the page indices of the paged kv cache,
            should be large enough to store the maximum number of page indices
            (``max_num_pages``) during the lifecycle of this wrapper.
            Only needed when ``use_cuda_graph`` is ``True``.

        paged_kv_last_page_len_buffer : Optional[torch.Tensor]
            The user reserved buffer on GPU to store the number of entries in the last page, the
            size of the buffer should be ``[batch_size]``.
            Only needed when ``use_cuda_graph`` is ``True``.

        backend : str
            The implementation backend, could be ``auto``/``fa2``/``fa3``/``trtllm-gen``/
            ``cute-dsl``/``cudnn``. Defaults to ``auto``.
            If set to ``auto``, the wrapper will automatically choose the backend based on the
            device architecture and kernel availability. On SM100 / SM103 with
            cudnn-frontend 1.30+ installed, ``auto`` resolves to ``cudnn`` for multi-token
            decode rows (``2 <= q_len_per_req <= 4``, speculative / MTP verification) of
            fp16 / bf16 head_dim-128 GQA models whose group divides 128, without RoPE /
            soft-cap / window, when cuDNN's default SM100 engine serves them with its FROST
            decode tile and that tile has enough work: ``q_len_per_req * group`` in
            [32, 128] rows per CTA and ``batch_size * num_kv_heads >= 64`` CTAs, where it
            measures at 0.35-0.95x fa2 (see ``_auto_decode_prefers_cudnn``); single-token
            decode stays on fa2. Multi-token rows without tensor cores have no fa2 kernel,
            so there ``auto`` takes ``cudnn`` for every plan its decode path can run (such a
            plan used to raise). A caller-owned ``block_tables`` narrower than 2048 tokens
            keeps fa2 on cudnn-frontend 1.30 (its placement puts the backend's prefill-class
            engine first below that; 1.31+ lifts the limit). ``auto`` takes ``cudnn`` only
            where the frontend's FROST engines can run (its own CuTe-DSL check:
            ``nvidia-cutlass-dsl`` 4.7.0 or newer, above the 4.6.2 the packages' dependency
            metadata admit), and callers that pin fa2's KV split (``fixed_split_size`` /
            ``disable_split_kv``, the batch-invariance controls) keep fa2 wherever it can
            serve the rows. ``resolved_backend`` reports the choice after :meth:`plan`.
            ``FLASHINFER_DECODE_AUTO_CUDNN=0`` keeps fa2, ``=1`` applies the rule on an older
            frontend too. Under CUDA graphs (``use_cuda_graph=True``) ``auto`` takes ``cudnn``
            only when :meth:`plan` receives a caller-owned ``block_tables`` (the auto-built
            table is captured at its first width and cannot grow) or when fa2 cannot serve
            the rows (``q_len_per_req > 1`` without tensor cores); the resolution then becomes
            part of the frozen graph shape and a later :meth:`plan` may not change it.
            The ``cute-dsl`` backend uses the CuTe DSL GQA decode kernel for Blackwell
            (SM100+) and only supports a subset of features (equal head_dim_qk/vo,
            no RoPE/ALiBi/soft-cap).
            The ``cudnn`` backend runs cuDNN's paged SDPA decode graph
            (:func:`flashinfer.decode.cudnn_batch_decode_with_kv_cache`). It supports
            fp16/bf16 q/kv/o of one dtype, GQA, ``return_lse``, CUDA graphs,
            multi-token decode (``q_len_per_req > 1``, bottom-right causal), a left
            sliding window (``window_left``) and attention ``sinks``, but not RoPE,
            soft-cap, fp8 or NVFP4 KV. A sink at ``q_len_per_req == 1`` is served when
            the cuDNN stack's SDPA engines accept it (cudnn-frontend 1.30+ with the
            FROST engines enabled); the backend engine raises a not-supported error
            at the first run.
            Pass a fixed ``block_tables`` to :meth:`plan` when capturing CUDA graphs so
            the captured block-table buffer is stable across re-plans.

        jit_args : Optional[List[Any]]
            If provided, the wrapper will use the provided arguments to create the JIT module,
            otherwise, the wrapper will use default attention implementation.
        """
        if backend == "prims-ts":
            raise NotImplementedError(
                "BatchDecodeWithPagedKVCacheWrapper uses CSR page metadata and "
                "does not support backend='prims-ts'; use "
                "flashinfer.attention.prims_ts.BatchDecodePagedTSWrapper with "
                "dense int32 [batch_size, max_pages] block_tables and int32 "
                "[batch_size] seq_lens"
            )
        _check_workspace_buffer_alignment(
            float_workspace_buffer, "float_workspace_buffer"
        )
        _check_kv_layout(kv_layout)

        if backend in ("cute-dsl", "cudnn") and jit_args is not None:
            raise NotImplementedError(
                f"{backend} backend does not support jit_args customization"
            )
        if jit_args is not None:
            if use_tensor_cores:
                self._jit_module = get_batch_prefill_jit_module(
                    jit_args[0],
                    gen_customize_batch_prefill_module(
                        backend, *jit_args
                    ).build_and_load(),
                )
            else:
                self._jit_module = get_batch_decode_jit_module(
                    jit_args[0],
                    gen_customize_batch_decode_module(*jit_args).build_and_load(),
                )
            # jit_args[7] is additional_tensor_names from gen_customize_batch_decode/prefill_module
            self._jit_additional_tensor_names = list(jit_args[7])
        else:
            self._jit_module = None
            self._jit_additional_tensor_names = []

        self._kv_layout = kv_layout
        self._float_workspace_buffer = float_workspace_buffer
        self.device = float_workspace_buffer.device
        self._int_workspace_buffer = torch.empty(
            (8 * 1024 * 1024,), dtype=torch.uint8, device=self.device
        )
        self._pin_memory_int_workspace_buffer = torch.empty(
            (8 * 1024 * 1024,),
            dtype=torch.uint8,
            pin_memory=True,
            device="cpu",
        )
        self._kv_lens_buffer: Optional[torch.Tensor] = None
        if backend in ("trtllm-gen", "cute-dsl", "cudnn"):
            self._kv_lens_buffer = torch.empty(
                (32768,), dtype=torch.int32, device=self.device
            )
        self._trtllm_gen_multi_ctas_kv_counter_buffer: Optional[torch.Tensor] = None
        self._cudnn_block_tables: Optional[torch.Tensor] = None
        # cudnn backend: the graph prepared at the first run() after plan() (validated
        # once, per-step run() rebinds only the tensors that change) and the planned
        # per-batch KV-length view it binds.
        self._cudnn_prepared: Optional[CudnnDecodeGraph] = None
        self._cudnn_kv_lens_view: Optional[torch.Tensor] = None
        self._cudnn_q_lens_view: Optional[torch.Tensor] = None
        self._cudnn_q_lens_shape: Optional[tuple[int, int]] = None

        if use_cuda_graph:
            if not torch.is_tensor(paged_kv_indptr_buffer):
                raise ValueError(
                    "paged_kv_indptr_buffer should be a torch.Tensor in cudagraph mode"
                )
            if not torch.is_tensor(paged_kv_indices_buffer):
                raise ValueError(
                    "paged_kv_indices_buffer should be a torch.Tensor in cudagraph mode"
                )
            if not torch.is_tensor(paged_kv_last_page_len_buffer):
                raise ValueError(
                    "paged_kv_last_page_len_buffer should be a torch.Tensor in cudagraph mode"
                )
            self._fixed_batch_size = len(paged_kv_last_page_len_buffer)
            if len(paged_kv_indptr_buffer) != self._fixed_batch_size + 1:
                raise ValueError(
                    "The size of paged_kv_indptr_buffer should be batch_size + 1"
                )
        else:
            self._fixed_batch_size = 0

        self._paged_kv_indptr_buf = paged_kv_indptr_buffer
        self._paged_kv_indices_buf = paged_kv_indices_buffer
        self._paged_kv_last_page_len_buf = paged_kv_last_page_len_buffer
        self._use_tensor_cores = use_tensor_cores or backend in (
            "trtllm-gen",
            "cute-dsl",
        )
        self._use_cuda_graph = use_cuda_graph

        if use_tensor_cores:
            if use_cuda_graph:
                # Created once; plan() rewrites the values when
                # q_len_per_req > 1.
                self._qo_indptr_buf = torch.arange(
                    self._fixed_batch_size + 1,
                    dtype=torch.int32,
                    device=float_workspace_buffer.device,
                )
        self._backend = backend
        # backend="auto" is re-resolved at every plan(); the tensor-core path
        # rewrites self._backend to its pick, so remember what was asked for.
        self._requested_backend = backend
        self._cudnn_auto = False
        self._cudnn_auto_frozen: Optional[bool] = None

        self._cute_dsl_wrapper = None
        if backend == "cute-dsl":
            from .cute_dsl.attention import BatchDecodePagedCuteDSLWrapper

            self._cute_dsl_wrapper = BatchDecodePagedCuteDSLWrapper(
                float_workspace_buffer, use_cuda_graph=use_cuda_graph
            )

    @property
    def use_tensor_cores(self) -> bool:
        return self._use_tensor_cores

    @property
    def _uses_cudnn(self) -> bool:
        return self._backend == "cudnn" or self._cudnn_auto

    def _auto_prefers_cudnn(
        self,
        q_data_type,
        kv_data_type,
        o_data_type,
        head_dim,
        num_qo_heads,
        num_kv_heads,
        batch_size,
        page_size,
        pos_encoding_mode,
        window_left,
        logits_soft_cap,
        q_len_per_req,
        *,
        user_block_tables: bool,
        declared_kv_len: Optional[int] = None,
        fixed_split_size: Optional[int] = None,
        disable_split_kv: bool = False,
    ) -> bool:
        # Both plan() and workspace_size() must select the same backend.
        # A caller-provided JIT module must not be replaced by auto routing.
        if self._requested_backend != "auto" or self._jit_module is not None:
            return False
        # Under CUDA graphs the auto-built block table is captured at its first
        # width and cannot grow (_plan_cudnn raises when a later plan crosses
        # the 1024-token bucket), while fa2 replans inside its preallocated
        # buffers: keep auto on fa2 there unless the caller owns the table, or
        # fa2 cannot serve the rows at all (multi-token decode without tensor
        # cores, which plan() rejected before cudnn could take it).
        if (
            self.is_cuda_graph_enabled
            and not user_block_tables
            and not (q_len_per_req > 1 and not self.use_tensor_cores)
        ):
            return False
        cc = get_compute_capability(self.device)
        return _auto_decode_prefers_cudnn(
            compute_capability=cc,
            frontend_serves_frost_decode=cudnn_frontend_serves_frost_decode(cc),
            cudnn_available=_CUDNN_GRAPH_AVAILABLE,
            q_data_type=q_data_type,
            kv_data_type=kv_data_type,
            o_data_type=o_data_type,
            head_dim=head_dim,
            num_qo_heads=num_qo_heads,
            num_kv_heads=num_kv_heads,
            batch_size=batch_size,
            page_size=page_size,
            pos_encoding_mode=pos_encoding_mode,
            window_left=window_left,
            logits_soft_cap=logits_soft_cap,
            q_len_per_req=q_len_per_req,
            # The CUDA-core decode kernel is single-token: multi-token rows
            # without tensor cores have no fa2 kernel to compare against.
            fa2_available=self.use_tensor_cores or q_len_per_req <= 1,
            declared_kv_len=declared_kv_len,
            frontend_leads_short_caches=cudnn_frontend_leads_short_caches(),
            # The frontend's own CuTe-DSL check: new enough for the FROST rows
            # to run, not just a new enough frontend version.
            frost_runtime_available=cudnn_frontend_frost_runtime_available(),
            fixed_split_size=fixed_split_size,
            disable_split_kv=disable_split_kv,
        )

    @property
    def resolved_backend(self) -> str:
        r"""What the last :meth:`plan` resolved ``backend="auto"`` to: ``"cudnn"``
        when the auto rule picked cuDNN, the tensor-core pick (``"fa2"`` / ``"fa3"``)
        otherwise, ``"fa2"`` for the CUDA-core decode kernel. An explicit backend
        reports itself; a tensor-core ``auto`` wrapper reports ``"auto"`` before its
        first :meth:`plan`."""
        if self._cudnn_auto:
            return "cudnn"
        if self._backend == "auto" and not self._use_tensor_cores:
            return "fa2"
        return self._backend

    @property
    def is_cuda_graph_enabled(self) -> bool:
        return self._use_cuda_graph

    def reset_workspace_buffer(
        self, float_workspace_buffer: torch.Tensor, int_workspace_buffer: torch.Tensor
    ) -> None:
        r"""Reset the workspace buffer.

        Parameters
        ----------
        float_workspace_buffer : torch.Tensor
            The new float workspace buffer, the device of the new float workspace buffer should
            be the same as the device of the input tensors.

        int_workspace_buffer : torch.Tensor
            The new int workspace buffer, the device of the new int workspace buffer should
            be the same as the device of the input tensors.
        """
        _check_workspace_buffer_alignment(
            float_workspace_buffer, "float_workspace_buffer"
        )
        _check_workspace_buffer_alignment(int_workspace_buffer, "int_workspace_buffer")
        self._cudnn_prepared = None
        self._float_workspace_buffer = float_workspace_buffer
        self._int_workspace_buffer = int_workspace_buffer
        self._pin_memory_int_workspace_buffer = torch.empty(
            self._int_workspace_buffer.shape,
            dtype=self._int_workspace_buffer.dtype,
            device="cpu",
            pin_memory=True,
        )

    @flashinfer_api
    def workspace_size(
        self,
        indptr: torch.Tensor,
        indices: torch.Tensor,
        last_page_len: torch.Tensor,
        num_qo_heads: int,
        num_kv_heads: int,
        head_dim: int,
        page_size: int,
        pos_encoding_mode: str = "NONE",
        window_left: int = -1,
        logits_soft_cap: Optional[float] = None,
        q_data_type: Optional[Union[str, torch.dtype]] = "float16",
        kv_data_type: Optional[Union[str, torch.dtype]] = None,
        o_data_type: Optional[Union[str, torch.dtype]] = None,
        data_type: Optional[Union[str, torch.dtype]] = None,
        sm_scale: Optional[float] = None,
        rope_scale: Optional[float] = None,
        rope_theta: Optional[float] = None,
        block_tables: Optional[torch.Tensor] = None,
        seq_lens: Optional[torch.Tensor] = None,
        fixed_split_size: Optional[int] = None,
        disable_split_kv: bool = False,
        q_len_per_req: int = 1,
    ) -> Tuple[int, int]:
        r"""Return the caller-owned workspace size required by :meth:`plan`.

        The returned tuple is ``(float_workspace_size, int_workspace_size)`` in
        bytes.  The inputs follow :meth:`plan`; host-side planning tensors such
        as ``indptr`` and ``last_page_len`` are copied to CPU in the same way as
        :meth:`plan`.  The wrapper's float workspace buffer is only used as the
        device/stream selector for the underlying module query.  This method
        does not allocate buffers and does not mutate cached plan state.

        Parameters
        ----------
        indptr : torch.Tensor
            The indptr of the paged kv cache, shape: ``[batch_size + 1]``, dtype: ``torch.int32``
        indices : torch.Tensor
            The page indices of the paged kv cache, shape: ``[indptr[-1]]``, dtype: ``torch.int32``
        last_page_len : torch.Tensor
            The number of entries in the last page of each request in the paged kv
            cache, shape: ``[batch_size]``, dtype: ``torch.int32``
        num_qo_heads : int
            The number of query/output heads.
        num_kv_heads : int
            The number of key/value heads.
        head_dim : int
            The dimension of the heads.
        page_size : int
            The page size of the paged kv cache.
        pos_encoding_mode : str
            The position encoding applied inside attention kernels, could be
            ``NONE``/``ROPE_LLAMA`` (LLAMA style rotary embedding) /``ALIBI``.
            Defaults to ``NONE``.
        window_left : int
            The left (inclusive) window size for the attention window, when set to ``-1``, the window
            size will be set to the full length of the sequence. Defaults to ``-1``.
        logits_soft_cap : Optional[float]
            The attention logits soft capping value (used in Gemini, Grok and Gemma-2, etc.), if not
            provided, will be set to ``0``.
        q_data_type : Optional[Union[str, torch.dtype]]
            The data type of the query tensor, defaults to ``torch.float16``.
        kv_data_type : Optional[Union[str, torch.dtype]]
            The data type of the key/value tensor. If ``None``, will be set to ``q_data_type``.
        o_data_type : Optional[Union[str, torch.dtype]]
            The data type of the output tensor. If ``None``, will be set to ``q_data_type``.
        data_type : Optional[Union[str, torch.dtype]]
            Deprecated alias — sets both ``q_data_type`` and ``kv_data_type`` when
            they are not provided explicitly.
        sm_scale : Optional[float]
            Softmax scale. If ``None``, defaults to ``1 / sqrt(head_dim)``.
        rope_scale : Optional[float]
            Scale factor applied during RoPE interpolation. Defaults to ``1.0`` when ``None``.
        rope_theta : Optional[float]
            Base value for the RoPE frequencies. Defaults to ``1e4`` when ``None``.
        block_tables : Optional[torch.Tensor]
            Unused by this method; accepted for signature compatibility with :meth:`plan`.
        seq_lens : Optional[torch.Tensor]
            A uint32 1D tensor indicating the kv sequence length of each prompt,
            shape: ``[batch_size]``.
        fixed_split_size : Optional[int]
            The fixed split size for FA2 split-kv decode, in pages.
        disable_split_kv : bool
            Whether to disable the split-kv for determinism in CUDA Graph. Defaults to ``False``.
        q_len_per_req : int
            The number of query tokens per request. Defaults to ``1``.

        Returns
        -------
        Tuple[int, int]
            ``(float_workspace_size, int_workspace_size)`` in bytes.

        Example
        -------
        >>> float_bytes, int_bytes = wrapper.workspace_size(...)
        >>> wrapper.reset_workspace_buffer(
        ...     torch.empty(float_bytes, dtype=torch.uint8, device="cuda"),
        ...     torch.empty(int_bytes, dtype=torch.uint8, device="cuda"),
        ... )
        >>> wrapper.plan(...)
        """
        _check_workspace_buffer_alignment(
            self._float_workspace_buffer, "float_workspace_buffer"
        )
        user_block_tables = block_tables is not None
        declared_kv_len = (
            None if block_tables is None else block_tables.shape[1] * page_size
        )
        del block_tables, rope_scale, rope_theta, sm_scale
        backend = self._backend
        batch_size = len(last_page_len)
        if logits_soft_cap is None:
            logits_soft_cap = 0.0
        if data_type is not None:
            if q_data_type is None:
                q_data_type = data_type
            if kv_data_type is None:
                kv_data_type = data_type
        q_data_type = canonicalize_torch_dtype(q_data_type)
        if kv_data_type is None:
            kv_data_type = q_data_type
        kv_data_type = canonicalize_torch_dtype(kv_data_type)
        if o_data_type is None:
            o_data_type = q_data_type
        o_data_type = canonicalize_torch_dtype(o_data_type)

        if self._auto_prefers_cudnn(
            q_data_type,
            kv_data_type,
            o_data_type,
            head_dim,
            num_qo_heads,
            num_kv_heads,
            batch_size,
            page_size,
            pos_encoding_mode,
            window_left,
            logits_soft_cap,
            q_len_per_req,
            user_block_tables=user_block_tables,
            declared_kv_len=declared_kv_len,
            fixed_split_size=fixed_split_size,
            disable_split_kv=disable_split_kv,
        ):
            backend = "cudnn"
        if backend in ("cute-dsl", "trtllm-gen", "cudnn"):
            raise NotImplementedError(
                f"workspace_size is not available for decode backend {backend!r}"
            )

        if fixed_split_size is not None and not self.use_tensor_cores:
            raise ValueError(
                "fixed_split_size is only supported by tensor core decode for now."
            )
        if fixed_split_size is None:
            fixed_split_size = -1
        if self.is_cuda_graph_enabled:
            if batch_size != self._fixed_batch_size:
                raise ValueError(
                    "The batch size should be fixed in cudagraph mode, the runtime batch size {} "
                    " mismatches the batch size set during initialization {}".format(
                        batch_size, self._fixed_batch_size
                    )
                )
            if len(indices) > len(self._paged_kv_indices_buf):
                raise ValueError(
                    "The size of indices should be less than or equal to the allocated buffer"
                )

        indptr_host = indptr.to("cpu")
        last_page_len_host = last_page_len.to("cpu")
        if seq_lens is None:
            kv_lens_arr_host = get_seq_lens(indptr_host, last_page_len_host, page_size)
        else:
            kv_lens_arr_host = seq_lens.cpu().to(torch.int32)
        if q_len_per_req > 1:
            min_kv_len = int(kv_lens_arr_host.min())
            if min_kv_len < q_len_per_req:
                raise ValueError(
                    f"q_len_per_req={q_len_per_req} requires kv_len >= "
                    "q_len_per_req for every request (the verified tokens "
                    "must already be appended to the KV cache), but got a "
                    f"request with kv_len={min_kv_len}: its earlier rows "
                    "would attend to an empty KV range."
                )

        if self.use_tensor_cores:
            if self._jit_module is not None:
                module = self._jit_module
            else:
                if backend == "auto":
                    if {
                        torch.float8_e4m3fn,
                        torch.float8_e5m2,
                    } & {q_data_type, kv_data_type}:
                        backend = determine_attention_backend(
                            self.device,
                            PosEncodingMode[pos_encoding_mode].value,
                            False,  # use_fp16_qk_reductions
                            False,  # use_custom_mask
                            q_data_type,
                            kv_data_type,
                        )
                    else:
                        backend = "fa2"
                if q_len_per_req > 1 and backend == "fa3":
                    raise NotImplementedError(
                        "q_len_per_req > 1 is currently only supported on the "
                        "fa2 tensor-core backend."
                    )
                module = get_batch_prefill_module(
                    backend,
                    q_data_type,
                    kv_data_type,
                    o_data_type,
                    indptr.dtype,
                    head_dim,
                    head_dim,
                    PosEncodingMode[pos_encoding_mode].value,
                    window_left != -1,
                    logits_soft_cap > 0,
                    False,
                )
            qo_indptr_host = _get_range_buf(batch_size + 1, "cpu")
            # Multi-token requests are causal within each request's block;
            # DFlash-style non-causal multi-token is not wired up yet.
            is_causal = q_len_per_req > 1
            if q_len_per_req > 1:
                qo_indptr_host = qo_indptr_host * q_len_per_req
            args = [
                self._float_workspace_buffer,
                qo_indptr_host,
                indptr_host,
                kv_lens_arr_host,
                batch_size * q_len_per_req,  # total_num_rows
                batch_size,
                num_qo_heads,
                num_kv_heads,
                page_size,
                self.is_cuda_graph_enabled,
                head_dim,
                head_dim,
                is_causal,  # causal
                window_left,
            ]
            if backend == "fa2":
                args.append(fixed_split_size)
                args.append(disable_split_kv)
                args.append(0)  # num_colocated_ctas
                args.append(q_len_per_req if q_len_per_req > 1 else 0)  # uniform_q_len
        else:
            if self._jit_module is not None:
                module = self._jit_module
            else:
                module = get_batch_decode_module(
                    q_data_type,
                    kv_data_type,
                    o_data_type,
                    indptr.dtype,
                    head_dim,
                    head_dim,
                    PosEncodingMode[pos_encoding_mode].value,
                    window_left != -1,
                    logits_soft_cap > 0,
                )
            args = [
                self._float_workspace_buffer,
                indptr_host,
                batch_size,
                num_qo_heads,
                num_kv_heads,
                page_size,
                self.is_cuda_graph_enabled,
                window_left,
                logits_soft_cap,
                head_dim,
                head_dim,
                torch.empty(0, dtype=q_data_type),
                torch.empty(0, dtype=kv_data_type),
            ]
        if module.workspace_size is None:
            raise NotImplementedError(
                f"workspace_size is not available for decode backend {backend!r}"
            )
        float_workspace_size, int_workspace_size = module.workspace_size(*args)
        return int(float_workspace_size), int(int_workspace_size)

    @flashinfer_api(trace=gqa_paged_decode_plan_trace)
    def plan(
        self,
        indptr: torch.Tensor,
        indices: torch.Tensor,
        last_page_len: torch.Tensor,
        num_qo_heads: int,
        num_kv_heads: int,
        head_dim: int,
        page_size: int,
        *deprecated_positional_args: Any,
        **kwargs: Any,
    ) -> None:
        r"""Plan batch decode for given problem specification.

        Parameters
        ----------
        indptr : torch.Tensor
            The indptr of the paged kv cache, shape: ``[batch_size + 1]``, dtype: ``torch.int32``
        indices : torch.Tensor
            The page indices of the paged kv cache, shape: ``[indptr[-1]]``, dtype: ``torch.int32``
        last_page_len : torch.Tensor
            The number of entries in the last page of each request in the paged kv
            cache, shape: ``[batch_size]``, dtype: ``torch.int32``
        num_qo_heads : int
            The number of query/output heads
        num_kv_heads : int
            The number of key/value heads
        head_dim : int
            The dimension of the heads
        page_size : int
            The page size of the paged kv cache
        pos_encoding_mode : str
            The position encoding applied inside attention kernels, could be
            ``NONE``/``ROPE_LLAMA`` (LLAMA style rotary embedding) /``ALIBI``.
            Defaults to ``NONE``.
        window_left : int
            The left (inclusive) window size for the attention window, when set to ``-1``, the window
            size will be set to the full length of the sequence. Defaults to ``-1``.
        window_right : int
            The right (inclusive) window size for the attention window.
            ``-1`` disables the right bound. Defaults to ``0``. Currently ``window_right != 0``
            only supported by the ``cute-dsl`` backend.
        logits_soft_cap : Optional[float]
            The attention logits soft capping value (used in Gemini, Grok and Gemma-2, etc.), if not
            provided, will be set to ``0``. If greater than 0, the logits will be capped according to
            formula:
            :math:`\texttt{logits_soft_cap} \times \mathrm{tanh}(x / \texttt{logits_soft_cap})`,
            where :math:`x` is the input logits.
        q_data_type : Optional[Union[str, torch.dtype]]
            The data type of the query tensor, defaults torch.float16.
        kv_data_type : Optional[Union[str, torch.dtype]]
            The data type of the key/value tensor. If None, will be set to
            ``q_data_type``. Defaults to ``None``.
        o_data_type : Optional[Union[str, torch.dtype]]
            The data type of the output tensor. If None, will be set to :attr:`q_data_type`.
            For FP8 inputs, this should typically be set to torch.float16 or torch.bfloat16.
        data_type: Optional[Union[str, torch.dtype]]
            The data type of both the query and key/value tensors. Defaults to torch.float16.
            data_type is deprecated, please use q_data_type and kv_data_type instead.
        sm_scale : Optional[float]
            Softmax scale.  If ``None``, defaults to ``1 / sqrt(head_dim)``.  Cached on
            the wrapper and reused at :meth:`run` time.
        rope_scale : Optional[float]
            Scale factor applied during RoPE interpolation.  Only consulted when
            ``pos_encoding_mode != "NONE"``.  Defaults to ``1.0`` when ``None``.
        rope_theta : Optional[float]
            Base value for the RoPE frequencies.  Only consulted when
            ``pos_encoding_mode != "NONE"``.  Defaults to ``1e4`` when ``None``.
        non_blocking : bool
            Whether to copy the input tensors to the device asynchronously, defaults to ``True``.
        seq_lens: Optional[torch.Tensor]
            A uint32 1D tensor indicating the kv sequence length of each prompt. shape: ``[batch_size]``.
        block_tables: Optional[torch.Tensor]
            A uint32 2D tensor indicating the block table of each prompt. shape: ``[batch_size, max_num_blocks_per_seq]``.
        fixed_split_size : Optional[int],
            The fixed split size for FA2 split-kv decode, in pages. Only supported by tensor core decode for now.
            Recommend setting to the average sequence length of your workload.
            When enabled for FA2, will lead to deterministic softmax score reduction in the merge_states kernel, and therefore
            batch-size invariant outputs. See https://thinkingmachines.ai/blog/defeating-nondeterminism-in-llm-inference/
            Note that compatibility with CUDA graph is NOT guaranteed, as even when bs is fixed, kv seq len can change
            and lead to a varied number of launched CTAs.
        disable_split_kv : bool,
            Whether to disable the split-kv for determinism in CUDA Graph, defaults to ``False``.
        q_len_per_req : int
            The number of query tokens per request. Defaults to ``1``.
            ``q_len_per_req > 1`` is currently supported on the fa2
            tensor-core backend (and natively by trtllm-gen/cute-dsl).
            Under ``use_cuda_graph``, this value is part of the frozen
            shape (like the batch size): once the wrapper has been
            planned, re-planning with a different value raises.
        is_causal : Optional[bool]
            Whether the mask is causal within each request block. Defaults to ``None``,
            which derives it from ``q_len_per_req > 1``. Values that differ from
            that default are not supported by this wrapper.
        Note
        ----
        The :meth:`plan` method should be called before any :meth:`run` or
        :meth:`run_return_lse` calls, auxiliary data structures will be created
        during this call and cached for multiple run calls.

        The ``num_qo_heads`` must be a multiple of ``num_kv_heads``. If ``num_qo_heads``
        is not equal to ``num_kv_heads``, the function will use
        `grouped query attention <https://arxiv.org/abs/2305.13245>`_.

        The :meth:`plan` method cannot be used in Cuda Graph or in ``torch.compile``.

        Optional arguments after ``page_size`` are accepted positionally for
        backward compatibility, but that calling convention is deprecated and
        scheduled for removal in a future release. Pass them by keyword instead.
        ``window_right`` is keyword-only.
        """
        if not deprecated_positional_args:
            return self._plan_impl(
                indptr,
                indices,
                last_page_len,
                num_qo_heads,
                num_kv_heads,
                head_dim,
                page_size,
                **kwargs,
            )

        plan_kwargs = _merge_deprecated_plan_kwargs(
            "BatchDecodeWithPagedKVCacheWrapper",
            deprecated_positional_args,
            _BATCH_DECODE_PLAN_LEGACY_POS_ARGS,
            kwargs,
        )
        _warn_deprecated_plan_positional_args("BatchDecodeWithPagedKVCacheWrapper")
        return self._plan_impl(
            indptr,
            indices,
            last_page_len,
            num_qo_heads,
            num_kv_heads,
            head_dim,
            page_size,
            **plan_kwargs,
        )

    def _plan_impl(
        self,
        indptr: torch.Tensor,
        indices: torch.Tensor,
        last_page_len: torch.Tensor,
        num_qo_heads: int,
        num_kv_heads: int,
        head_dim: int,
        page_size: int,
        *,
        pos_encoding_mode: str = "NONE",
        window_left: int = -1,
        window_right: int = 0,
        logits_soft_cap: Optional[float] = None,
        q_data_type: Optional[Union[str, torch.dtype]] = "float16",
        kv_data_type: Optional[Union[str, torch.dtype]] = None,
        o_data_type: Optional[Union[str, torch.dtype]] = None,
        data_type: Optional[Union[str, torch.dtype]] = None,
        sm_scale: Optional[float] = None,
        rope_scale: Optional[float] = None,
        rope_theta: Optional[float] = None,
        non_blocking: bool = True,
        block_tables: Optional[torch.Tensor] = None,
        seq_lens: Optional[torch.Tensor] = None,
        fixed_split_size: Optional[int] = None,
        disable_split_kv: bool = False,
        q_len_per_req: int = 1,
        is_causal: Optional[bool] = None,
    ) -> None:
        """Shared plan() implementation for the paged-decode wrapper across backends."""
        _check_workspace_buffer_alignment(
            self._float_workspace_buffer, "float_workspace_buffer"
        )
        _check_workspace_buffer_alignment(
            self._int_workspace_buffer, "int_workspace_buffer"
        )
        self._workspace_size = (
            self._float_workspace_buffer.numel()
            * self._float_workspace_buffer.element_size()
        )

        batch_size = len(last_page_len)
        if logits_soft_cap is None:
            logits_soft_cap = 0.0

        if data_type is not None:
            if q_data_type is None:
                q_data_type = data_type
            if kv_data_type is None:
                kv_data_type = data_type

        q_data_type = canonicalize_torch_dtype(q_data_type)
        if kv_data_type is None:
            kv_data_type = q_data_type
        kv_data_type = canonicalize_torch_dtype(kv_data_type)
        if o_data_type is None:
            o_data_type = q_data_type
        o_data_type = canonicalize_torch_dtype(o_data_type)

        # backend="auto" may resolve to cudnn; decided per plan() so that the
        # q_len_per_req / buffer checks below already know the path.
        self._cudnn_auto = self._auto_prefers_cudnn(
            q_data_type,
            kv_data_type,
            o_data_type,
            head_dim,
            num_qo_heads,
            num_kv_heads,
            batch_size,
            page_size,
            pos_encoding_mode,
            window_left,
            logits_soft_cap,
            q_len_per_req,
            user_block_tables=block_tables is not None,
            declared_kv_len=None
            if block_tables is None
            else block_tables.shape[1] * page_size,
            fixed_split_size=fixed_split_size,
            disable_split_kv=disable_split_kv,
        )
        if self.is_cuda_graph_enabled:
            # The resolved backend is part of the frozen CUDA-graph shape: a
            # captured graph replays the kernels it was captured with, and
            # those read the metadata buffers of one path only.
            if (
                self._cudnn_auto_frozen is not None
                and self._cudnn_auto_frozen != self._cudnn_auto
            ):
                raise ValueError(
                    "backend='auto' is part of the frozen cudagraph shape: this "
                    "wrapper was first planned on "
                    f"{'cudnn' if self._cudnn_auto_frozen else 'the fa2 path'} and "
                    f"this plan resolves to {'cudnn' if self._cudnn_auto else 'the fa2 path'}; "
                    "keep block_tables, dtypes, window and q_len_per_req the same "
                    "across plans, or use a separate wrapper."
                )
            self._cudnn_auto_frozen = self._cudnn_auto
        if window_right != 0 and self._backend != "cute-dsl":
            raise NotImplementedError(
                "BatchDecodeWithPagedKVCacheWrapper only supports window_right != 0 "
                "with backend='cute-dsl'"
            )

        if q_len_per_req < 1:
            raise ValueError(f"q_len_per_req must be >= 1, got {q_len_per_req}")
        if is_causal is None:
            is_causal = q_len_per_req > 1
        elif is_causal != (q_len_per_req > 1):
            raise NotImplementedError(
                f"backend={self._backend!r} derives the decode mask from "
                "q_len_per_req; an explicit is_causal override is not supported"
            )
        qo_indptr_host = _get_range_buf(batch_size + 1, "cpu")
        if q_len_per_req > 1:
            if not self.use_tensor_cores and not self._uses_cudnn:
                raise ValueError(
                    "q_len_per_req > 1 requires tensor-core decode "
                    "(use_tensor_cores=True or the trtllm-gen/cute-dsl/cudnn backend)."
                )
            qo_indptr_host = qo_indptr_host * q_len_per_req
        if self.is_cuda_graph_enabled:
            frozen_q_len = getattr(self, "_q_len_per_req", None)
            if frozen_q_len is not None and frozen_q_len != q_len_per_req:
                raise ValueError(
                    "q_len_per_req is part of the frozen cudagraph shape: "
                    f"this wrapper was planned with {frozen_q_len}, got "
                    f"{q_len_per_req}. Use a separate wrapper per q_len_per_req."
                )
            if batch_size != self._fixed_batch_size:
                raise ValueError(
                    "The batch size should be fixed in cudagraph mode, the runtime batch size {} "
                    " mismatches the batch size set during initialization {}".format(
                        batch_size, self._fixed_batch_size
                    )
                )
            if len(indices) > len(self._paged_kv_indices_buf):
                raise ValueError(
                    "The size of indices should be less than or equal to the allocated buffer"
                )
            self._paged_kv_indptr_buf.copy_(indptr, non_blocking=non_blocking)
            self._paged_kv_last_page_len_buf.copy_(
                last_page_len, non_blocking=non_blocking
            )
            self._paged_kv_indices_buf[: len(indices)].copy_(
                indices, non_blocking=(indices.device == self.device) and non_blocking
            )
            if (
                self.use_tensor_cores
                and q_len_per_req > 1
                and self._backend in ("auto", "fa2")
            ):
                # "auto" is unresolved here; its fa3 resolution is rejected
                # later in plan()
                self._qo_indptr_buf.copy_(qo_indptr_host, non_blocking=non_blocking)
        else:
            self._paged_kv_indptr_buf = indptr.to(
                self.device, non_blocking=non_blocking
            )
            self._paged_kv_indices_buf = indices.to(
                self.device, non_blocking=non_blocking
            )
            self._paged_kv_last_page_len_buf = last_page_len.to(
                self.device, non_blocking=non_blocking
            )
            self._qo_indptr_buf = qo_indptr_host.to(
                self.device, non_blocking=non_blocking
            )

        indptr_host = indptr.to("cpu")
        last_page_len_host = last_page_len.to("cpu")

        if fixed_split_size is not None and not self.use_tensor_cores:
            raise ValueError(
                "fixed_split_size is only supported by tensor core decode for now."
            )
        if fixed_split_size is None:
            fixed_split_size = -1

        self._cached_q_data_type = q_data_type
        self._cached_kv_data_type = kv_data_type
        self._cached_o_data_type = o_data_type
        self._batch_size = batch_size
        self._num_qo_heads = num_qo_heads
        self._num_kv_heads = num_kv_heads
        self._block_tables: Optional[torch.Tensor] = block_tables
        self._user_block_tables = block_tables is not None
        self._max_kv_len: Optional[int] = None

        if seq_lens is None:
            kv_lens_arr_host = get_seq_lens(indptr_host, last_page_len_host, page_size)
        else:
            kv_lens_arr_host = seq_lens.cpu().to(torch.int32)
        if q_len_per_req > 1 and is_causal:
            min_kv_len = int(kv_lens_arr_host.min())
            if min_kv_len < q_len_per_req:
                raise ValueError(
                    f"q_len_per_req={q_len_per_req} requires kv_len >= "
                    "q_len_per_req for every request (the verified tokens "
                    "must already be appended to the KV cache), but got a "
                    f"request with kv_len={min_kv_len}: its earlier rows "
                    "would attend to an empty KV range."
                )
        if self._backend == "cutile":
            # Pure cuda.tile Python kernel: no C++ module to JIT. Stash the
            # per-sequence KV lengths and page size, and materialize the dense
            # block table now (at plan time) so run() is CUDA-graph-capturable --
            # reconstructing it in run() would require host .item() syncs.
            if logits_soft_cap is not None and logits_soft_cap > 0:
                raise NotImplementedError(
                    "cuTile decode backend does not support logits_soft_cap."
                )
            if window_left >= 0:
                # The kernel receives no window_left; a sliding window would be
                # silently ignored and run as full attention.
                raise NotImplementedError(
                    "cuTile decode backend does not support sliding window "
                    f"(window_left={window_left})."
                )
            if pos_encoding_mode != "NONE":
                # The kernel applies no positional encoding; anything other than
                # "NONE" would be silently dropped.
                raise NotImplementedError(
                    "cuTile decode backend does not apply position encoding "
                    f"(pos_encoding_mode must be 'NONE'); got {pos_encoding_mode!r}."
                )
            self._page_size = page_size
            self._kv_lens_arr_host = kv_lens_arr_host
            # Device copy of the per-seq KV lengths, staged once at plan time.
            # run() must not copy it H2D itself: a CPU->CUDA copy from unpinned
            # host memory is illegal during CUDA graph capture.
            self._kv_lens_device = kv_lens_arr_host.to(
                device=self.device, dtype=torch.int32
            )
            if self._block_tables is None:
                # Build a dense [batch, max_pages] block table from the CSR
                # (indptr/indices) plan state. Done here, once, outside any CUDA
                # graph capture, so run() pays no per-call host sync (mirrors the
                # trtllm-gen plan-time reconstruction below).
                blocks_per_seq = [
                    (int(seq_len) + page_size - 1) // page_size
                    for seq_len in kv_lens_arr_host
                ]
                max_num_blocks_per_seq = max(blocks_per_seq)
                self._block_tables = torch.zeros(
                    (batch_size, max_num_blocks_per_seq),
                    dtype=torch.int32,
                    device=self.device,
                )
                block_id = int(indptr_host[0].item())
                for i in range(batch_size):
                    num_blocks_needed = blocks_per_seq[i]
                    self._block_tables[i, :num_blocks_needed] = (
                        self._paged_kv_indices_buf[
                            block_id : block_id + num_blocks_needed
                        ]
                    )
                    block_id += num_blocks_needed
            self._plan_info = None
            # run() reads these; normally set after the module-build branches below.
            self._pos_encoding_mode = pos_encoding_mode
            self._window_left = window_left
            self._logits_soft_cap = logits_soft_cap
            self._sm_scale = sm_scale
            self._rope_scale = rope_scale
            self._rope_theta = rope_theta
            return
        if self._uses_cudnn:
            self._plan_cudnn(
                indptr_host,
                indices,
                batch_size,
                page_size,
                kv_lens_arr_host,
                q_data_type,
                kv_data_type,
                o_data_type,
                pos_encoding_mode,
                window_left,
                logits_soft_cap,
                q_len_per_req,
                non_blocking,
            )
            self._plan_info = None
            self._pos_encoding_mode = pos_encoding_mode
            self._window_left = window_left
            self._window_right = window_right
            self._logits_soft_cap = logits_soft_cap
            self._sm_scale = sm_scale
            self._rope_scale = rope_scale
            self._rope_theta = rope_theta
            self._q_len_per_req = q_len_per_req
            self._is_causal = is_causal
            return
        if self._backend == "cute-dsl":
            if logits_soft_cap is not None and logits_soft_cap > 0:
                raise NotImplementedError(
                    "cute-dsl decode backend does not support logits_soft_cap"
                )
            if pos_encoding_mode != "NONE":
                raise NotImplementedError(
                    f"cute-dsl decode backend does not support "
                    f"pos_encoding_mode={pos_encoding_mode!r}"
                )
            self._max_kv_len = int(kv_lens_arr_host.max().item())
            kv_splits = None
            if fixed_split_size > 0:
                fixed_split_len = fixed_split_size * page_size
                kv_splits = (self._max_kv_len + fixed_split_len - 1) // fixed_split_len
            # Stage the per-request KV lengths in the reusable device buffer
            # (same pattern as trtllm-gen) so the wrapper consumes them
            # directly without re-deriving from last_page_len.
            required_size = len(kv_lens_arr_host)
            if required_size > self._kv_lens_buffer.shape[0]:
                self._kv_lens_buffer = torch.empty(
                    (required_size,), dtype=torch.int32, device=self.device
                )
            self._kv_lens_buffer[:required_size].copy_(
                kv_lens_arr_host, non_blocking=non_blocking
            )
            self._cute_dsl_wrapper.plan(
                self._paged_kv_indptr_buf,
                self._paged_kv_indices_buf,
                self._kv_lens_buffer[:required_size],
                num_qo_heads=num_qo_heads,
                num_kv_heads=num_kv_heads,
                head_dim=head_dim,
                page_size=page_size,
                q_data_type=q_data_type,
                kv_data_type=kv_data_type,
                o_data_type=o_data_type,
                sm_scale=sm_scale,
                kv_splits=kv_splits,
                reduction="none" if disable_split_kv else "auto",
                q_len_per_req=q_len_per_req,
                window_left=(None if window_left < 0 else window_left),
                window_right=(None if window_right < 0 else window_right),
                max_kv_len=self._max_kv_len,
                non_blocking=non_blocking,
            )
        elif self._backend == "trtllm-gen":
            assert logits_soft_cap == 0.0
            self._max_kv_len = kv_lens_arr_host.max().item()
            # Allocated once per plan and reused across run() launches. The
            # trtllm-gen kernel self-resets the counters at the end of each
            # launch, so no per-launch re-zeroing is needed.
            self._trtllm_gen_multi_ctas_kv_counter_buffer = (
                _get_trtllm_gen_multi_ctas_kv_counter_buffer(
                    batch_size,
                    num_qo_heads,
                    get_device_sm_count(self.device),
                    self.device,
                )
            )
            required_size = len(kv_lens_arr_host)
            if required_size > self._kv_lens_buffer.shape[0]:
                self._kv_lens_buffer = torch.empty(
                    (required_size,), dtype=torch.int32, device=self.device
                )
            self._kv_lens_buffer[:required_size].copy_(
                kv_lens_arr_host, non_blocking=non_blocking
            )
            if self._block_tables is None:
                blocks_per_seq = [
                    (seq_len + page_size - 1) // page_size
                    for seq_len in kv_lens_arr_host
                ]
                max_num_blocks_per_seq = max(blocks_per_seq)
                self._block_tables = torch.zeros(
                    (batch_size, max_num_blocks_per_seq),
                    dtype=torch.int,
                    device=self.device,
                )
                block_id = int(indptr_host[0].item())
                for i in range(batch_size):
                    num_blocks_needed = blocks_per_seq[i]
                    self._block_tables[i, :num_blocks_needed] = (
                        self._paged_kv_indices_buf[
                            block_id : block_id + num_blocks_needed
                        ]
                    )
                    block_id += num_blocks_needed
            self._cached_module = get_trtllm_gen_decode_module(
                q_data_type,
                kv_data_type,
                o_data_type,
                indptr.dtype,
                head_dim,
                head_dim,
                PosEncodingMode[pos_encoding_mode].value,
                window_left >= 0,  # use_sliding_window
                logits_soft_cap > 0,  # use_logits_soft_cap
                False,  # use_fp16_qk_reduction
            )
            self._plan_info = self._cached_module.plan()  # None
        elif self.use_tensor_cores:
            self._max_kv_len = kv_lens_arr_host.max().item()
            if self._jit_module is not None:
                self._cached_module = self._jit_module
            else:
                if self._backend == "auto":
                    if {
                        torch.float8_e4m3fn,
                        torch.float8_e5m2,
                    } & {q_data_type, kv_data_type}:
                        self._backend = determine_attention_backend(
                            self.device,
                            PosEncodingMode[pos_encoding_mode].value,
                            False,  # use_fp16_qk_reductions
                            False,  # use_custom_mask
                            q_data_type,
                            kv_data_type,
                            head_dim_qk=head_dim,
                            head_dim_vo=head_dim,
                        )
                    else:
                        self._backend = "fa2"
                if q_len_per_req > 1 and self._backend == "fa3":
                    raise NotImplementedError(
                        "q_len_per_req > 1 is currently only supported on the "
                        "fa2 tensor-core backend."
                    )
                self._cached_module = get_batch_prefill_module(
                    self._backend,
                    q_data_type,
                    kv_data_type,
                    o_data_type,
                    indptr.dtype,
                    head_dim,  # head_dim_qk
                    head_dim,  # head_dim_vo
                    PosEncodingMode[pos_encoding_mode].value,
                    window_left != -1,  # use_sliding_window
                    logits_soft_cap > 0,  # use_logits_soft_cap
                    False,  # use_fp16_qk_reduction
                )

            args = [
                self._float_workspace_buffer,
                self._int_workspace_buffer,
                self._pin_memory_int_workspace_buffer,
                qo_indptr_host,
                indptr_host,
                kv_lens_arr_host,
                batch_size * q_len_per_req,  # total_num_rows
                batch_size,
                num_qo_heads,
                num_kv_heads,
                page_size,
                self.is_cuda_graph_enabled,
                head_dim,
                head_dim,
                is_causal,  # causal
                window_left,
            ]
            if self._backend == "fa2":
                args.append(fixed_split_size)
                args.append(disable_split_kv)
                args.append(0)  # num_colocated_ctas
                args.append(q_len_per_req if q_len_per_req > 1 else 0)  # uniform_q_len
            self._plan_info = self._cached_module.plan(
                *args,
            )
        else:
            if self._jit_module is not None:
                self._cached_module = self._jit_module
            else:
                self._cached_module = get_batch_decode_module(
                    q_data_type,
                    kv_data_type,
                    o_data_type,
                    indptr.dtype,
                    head_dim,  # head_dim_qk
                    head_dim,  # head_dim_vo
                    PosEncodingMode[pos_encoding_mode].value,
                    window_left != -1,  # use_sliding_window
                    logits_soft_cap > 0,  # use_logits_soft_cap
                )
            self._plan_info = self._cached_module.plan(
                self._float_workspace_buffer,
                self._int_workspace_buffer,
                self._pin_memory_int_workspace_buffer,
                indptr_host,
                batch_size,
                num_qo_heads,
                num_kv_heads,
                page_size,
                self.is_cuda_graph_enabled,
                window_left,
                logits_soft_cap,
                head_dim,
                head_dim,
                torch.empty(0, dtype=q_data_type),
                torch.empty(0, dtype=kv_data_type),
            )

        self._pos_encoding_mode = pos_encoding_mode
        self._window_left = window_left
        self._window_right = window_right
        self._logits_soft_cap = logits_soft_cap
        self._sm_scale = sm_scale
        self._rope_scale = rope_scale
        self._rope_theta = rope_theta
        self._q_len_per_req = q_len_per_req
        self._is_causal = is_causal

    def _plan_cudnn(
        self,
        indptr_host: torch.Tensor,
        indices: torch.Tensor,
        batch_size: int,
        page_size: int,
        kv_lens_arr_host: torch.Tensor,
        q_data_type: torch.dtype,
        kv_data_type: torch.dtype,
        o_data_type: torch.dtype,
        pos_encoding_mode: str,
        window_left: int,
        logits_soft_cap: float,
        q_len_per_req: int,
        non_blocking: bool,
    ) -> None:
        """Plan for backend='cudnn': validate, stage KV lengths and a dense block table."""
        if logits_soft_cap > 0:
            raise NotImplementedError(
                "cudnn decode backend does not support logits_soft_cap."
            )
        if pos_encoding_mode != "NONE":
            raise NotImplementedError(
                "cudnn decode backend does not apply position encoding "
                f"(pos_encoding_mode must be 'NONE'); got {pos_encoding_mode!r}."
            )
        if q_data_type not in (torch.float16, torch.bfloat16) or not (
            q_data_type == kv_data_type == o_data_type
        ):
            raise NotImplementedError(
                "cudnn decode backend requires q, kv and o to share one fp16 or bf16 "
                f"dtype; got q={q_data_type}, kv={kv_data_type}, o={o_data_type}."
            )

        self._page_size = page_size
        if self._cudnn_q_lens_shape != (batch_size, q_len_per_req):
            # CUDA-graph mode freezes both dimensions before reaching here.
            # Keep this allocation on the wrapper even if a prepared graph is
            # replaced (e.g. a later run requests LSE).
            self._cudnn_q_lens_view = torch.full(
                (batch_size, 1, 1, 1),
                q_len_per_req,
                dtype=torch.int32,
                device=self.device,
            )
            self._cudnn_q_lens_shape = (batch_size, q_len_per_req)
        if self._kv_lens_buffer is None or batch_size > self._kv_lens_buffer.shape[0]:
            self._kv_lens_buffer = torch.empty(
                (batch_size,), dtype=torch.int32, device=self.device
            )
            self._cudnn_kv_lens_view = None
        # Reuse the descriptor view while updating its backing storage. A
        # compatible replan does not need another slice/view allocation.
        if (
            self._cudnn_kv_lens_view is None
            or self._cudnn_kv_lens_view.shape[0] != batch_size
        ):
            self._cudnn_kv_lens_view = self._kv_lens_buffer[:batch_size].view(
                batch_size, 1, 1, 1
            )
        kv_lens_buffer = self._kv_lens_buffer
        if kv_lens_buffer.shape[0] != batch_size:
            kv_lens_buffer = kv_lens_buffer[:batch_size]
        kv_lens_buffer.copy_(
            kv_lens_arr_host.to(torch.int32), non_blocking=non_blocking
        )

        max_kv_len = int(kv_lens_arr_host.max())
        if self._user_block_tables:
            # Caller-owned table: its width bounds the walk, so key the graph on it.
            if self._block_tables.device != self.device:
                raise ValueError(
                    "cudnn decode backend requires block_tables on the wrapper "
                    f"device ({self.device}), got {self._block_tables.device}"
                )
            required_pages = -(-max_kv_len // page_size)
            if (
                self._block_tables.shape[0] != batch_size
                or self._block_tables.shape[1] < required_pages
            ):
                raise ValueError(
                    "cudnn decode backend: block_tables "
                    f"{tuple(self._block_tables.shape)} cannot hold every planned "
                    f"sequence (need {(batch_size, required_pages)} for "
                    f"max kv_len={max_kv_len}, page_size={page_size})."
                )
            self._max_kv_len = self._block_tables.shape[1] * page_size
            return

        # cuDNN bakes max_seq_len_kv and the block-table width into the built graph,
        # so bucket both: consecutive decode steps then replay one cached graph
        # instead of rebuilding it every time the longest sequence grows by a page.
        max_kv_len = -(-max_kv_len // _CUDNN_DECODE_MAX_KV_BUCKET) * (
            _CUDNN_DECODE_MAX_KV_BUCKET
        )
        max_pages = -(-max_kv_len // page_size)
        table = self._cudnn_block_tables
        if table is None or table.shape[0] != batch_size or table.shape[1] < max_pages:
            if self.is_cuda_graph_enabled and table is not None:
                raise ValueError(
                    "cudnn decode backend: the auto-built block table "
                    f"{tuple(table.shape)} is captured by the CUDA graph and cannot "
                    f"grow to {(batch_size, max_pages)}; pass a fixed block_tables to "
                    "plan() sized for the longest sequence the graph will see."
                )
            table = torch.zeros(
                (batch_size, max_pages), dtype=torch.int32, device=self.device
            )
            self._cudnn_block_tables = table
        else:
            table.zero_()
            max_pages = table.shape[1]
            max_kv_len = max_pages * page_size

        indices_host = indices.to("cpu")
        host_table = torch.zeros((batch_size, max_pages), dtype=torch.int32)
        for i in range(batch_size):
            begin = int(indptr_host[i])
            end = int(indptr_host[i + 1])
            host_table[i, : end - begin] = indices_host[begin:end]
        table.copy_(host_table, non_blocking=non_blocking)
        self._block_tables = table
        self._max_kv_len = max_kv_len

    @flashinfer_api
    def prewarm_paged_kv_stride_variant(self, variant: str = "independent") -> None:
        r"""Load a lazy tensor-core paged-KV-stride variant after :meth:`plan`.

        Call this method before CUDA graph capture when a planned standard FA2
        tensor-core decode wrapper will receive K and V tensors with different
        data strides.

        Parameters
        ----------
        variant : str
            The paged-KV-stride variant to prewarm. The only supported value is
            ``"independent"`` (the default), for K and V with different data strides.
        """
        if (
            getattr(self, "_plan_info", None) is None
            or getattr(self, "_cached_module", None) is None
        ):
            raise RuntimeError(
                "plan() must complete before prewarming a paged-KV-stride variant."
            )
        if not self.use_tensor_cores:
            raise RuntimeError("Paged-KV-stride prewarm requires tensor-core decode.")
        if self._jit_module is not None:
            raise RuntimeError(
                "Paged-KV-stride prewarm is not supported for a custom JIT module."
            )
        if self._backend != "fa2":
            raise RuntimeError(
                "Paged-KV-stride prewarm requires a standard FA2 plan, "
                f"got backend={self._backend!r}."
            )
        with torch.cuda.device(self.device):
            self._cached_module.prewarm_paged_kv_stride_variant(variant)

    begin_forward = plan

    def forward(
        self,
        q: torch.Tensor,
        paged_kv_cache: Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]],
        pos_encoding_mode: str = "NONE",
        q_scale: Optional[float] = None,
        k_scale: Optional[float] = None,
        v_scale: Optional[float] = None,
        window_left: int = -1,
        logits_soft_cap: Optional[float] = None,
        sm_scale: Optional[float] = None,
        rope_scale: Optional[float] = None,
        rope_theta: Optional[float] = None,
    ) -> torch.Tensor:
        r"""Warning: this function is deprecated, please use :meth:`run` instead."""
        self._pos_encoding_mode = pos_encoding_mode
        self._window_left = window_left
        self._logits_soft_cap = logits_soft_cap
        self._sm_scale = sm_scale
        self._rope_scale = rope_scale
        self._rope_theta = rope_theta
        return self.run(
            q, paged_kv_cache, q_scale=q_scale, k_scale=k_scale, v_scale=v_scale
        )

    @overload
    def run(
        self,
        q: torch.Tensor,
        paged_kv_cache: Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]],
        *args,
        q_scale: Optional[float] = None,
        k_scale: Optional[float] = None,
        v_scale: Optional[float] = None,
        out: Optional[torch.Tensor] = None,
        lse: Optional[torch.Tensor] = None,
        return_lse: Literal[False] = False,
        enable_pdl: Optional[bool] = None,
        window_left: Optional[int] = None,
        sinks: Optional[torch.Tensor] = None,
        q_len_per_req: Optional[int] = None,
        skip_softmax_threshold_scale_factor: Optional[float] = None,
        kv_cache_sf: Optional[
            Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]
        ] = None,
    ) -> torch.Tensor: ...

    @overload
    def run(
        self,
        q: torch.Tensor,
        paged_kv_cache: Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]],
        *args,
        q_scale: Optional[float] = None,
        k_scale: Optional[float] = None,
        v_scale: Optional[float] = None,
        out: Optional[torch.Tensor] = None,
        lse: Optional[torch.Tensor] = None,
        return_lse: Literal[True] = True,
        enable_pdl: Optional[bool] = None,
        window_left: Optional[int] = None,
        sinks: Optional[torch.Tensor] = None,
        q_len_per_req: Optional[int] = None,
        skip_softmax_threshold_scale_factor: Optional[float] = None,
        kv_cache_sf: Optional[
            Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]
        ] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]: ...

    @flashinfer_api(trace=gqa_paged_decode_trace)
    def run(
        self,
        q: torch.Tensor,
        paged_kv_cache: Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]],
        *args,
        q_scale: Optional[float] = None,
        k_scale: Optional[float] = None,
        v_scale: Optional[float] = None,
        out: Optional[torch.Tensor] = None,
        lse: Optional[torch.Tensor] = None,
        return_lse: bool = False,
        enable_pdl: Optional[bool] = None,
        window_left: Optional[int] = None,
        sinks: Optional[torch.Tensor] = None,
        q_len_per_req: Optional[int] = None,
        skip_softmax_threshold_scale_factor: Optional[float] = None,
        kv_cache_sf: Optional[
            Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]
        ] = None,
    ) -> Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
        r"""Compute batch decode attention between query and paged kv cache.

        Parameters
        ----------
        q : torch.Tensor
            The query tensor, shape: ``[batch_size * q_len_per_req, num_qo_heads, head_dim]``
            On the trtllm-gen and cute-dsl backends the q_len_per_req implied
            by ``q.shape[0]`` may differ from the planned value; the fa2/fa3
            tensor-core path requires it to match :meth:`plan`.
        paged_kv_cache : Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]
            The paged KV-Cache stored as a tuple of tensors or a single tensor:

            * a tuple ``(k_cache, v_cache)`` of 4-D tensors, each with shape:
              ``[max_num_pages, page_size, num_kv_heads, head_dim]`` if :attr:`kv_layout` is ``NHD``,
              and ``[max_num_pages, num_kv_heads, page_size, head_dim]`` if :attr:`kv_layout` is ``HND``.

            * a single 5-D tensor with shape:
              ``[max_num_pages, 2, page_size, num_kv_heads, head_dim]`` if
              :attr:`kv_layout` is ``NHD``, and
              ``[max_num_pages, 2, num_kv_heads, page_size, head_dim]`` if
              :attr:`kv_layout` is ``HND``. Where ``paged_kv_cache[:, 0]`` is the key-cache and
              ``paged_kv_cache[:, 1]`` is the value-cache.
        *args
            Additional arguments for the custom kernel.
        q_scale : Optional[float]
            The calibration scale of query for fp8 input, if not provided, will be set to ``1.0``.
        k_scale : Optional[float]
            The calibration scale of key for fp8 or nvfp4 input, if not provided, will be set to ``1.0``.
        v_scale : Optional[float]
            The calibration scale of value for fp8 or nvfp4 input, if not provided, will be set to ``1.0``.
        out : Optional[torch.Tensor]
            The output tensor, if not provided, will be allocated internally. Must be zero-init for cute-dsl backend.
        lse : Optional[torch.Tensor]
            The log-sum-exp of attention logits, if not provided, will be allocated internally.
        return_lse : bool
            Whether to return the logsumexp of attention scores, defaults to ``False``.
        enable_pdl : bool
            Whether to enable Programmatic Dependent Launch (PDL). See https://docs.nvidia.com/cuda/cuda-c-programming-guide/#programmatic-dependent-launch-and-synchronization
            Only supported for >= sm90, and currently only for FA2 and CUDA core decode.
        window_left : Optional[int]
            Per-call sliding-window bound. Must either be ``None`` (default,
            inherit the value from :meth:`plan`) or equal the value passed to
            :meth:`plan` (the kernel asserts this). Passing ``-1`` to
            :meth:`plan` disables the sliding window for the entire batch.
        sinks : Optional[torch.Tensor]
            Per-head attention sink logits, shape ``[num_qo_heads]``. When
            provided, ``sinks[head_idx]`` is appended to each row of the
            softmax denominator (Streaming-LLM / Attention-Sinks). The dtype
            requirement is backend-specific and validated by the underlying
            kernel; pass ``None`` to disable.
        q_len_per_req : Optional[int]
            DEPRECATED — pass to :meth:`plan` instead. When provided here, emits
            a :class:`DeprecationWarning` and is used to validate the run-time value
            inferred from q.size(0). Scheduled for removal in a future release.
        skip_softmax_threshold_scale_factor: Optional[float] = None
            threshold scale factor for skipping softmax operations.
            Providing a value for this parameter enables skip-softmax sparsity as described in: https://arxiv.org/abs/2512.12087
            If no value is provided, then standard attention is used.
            Setting the threshold to a higher value generally increases kernel performance at the cost of accuracy degradation.
            The actual threshold value equals the provided threshold_scale_factor divided by the context length.
        kv_cache_sf : Optional[Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]]
            Per-block scale factors for NVFP4 KV cache. Accepts the same formats as
            ``paged_kv_cache``:

            * a tuple ``(k_scales, v_scales)`` of 4-D tensors, each with shape:
              ``[num_pages, page_size, num_kv_heads, head_dim // 16]`` if :attr:`kv_layout` is ``NHD``,
              and ``[num_pages, num_kv_heads, page_size, head_dim // 16]`` if :attr:`kv_layout` is ``HND``.
            * a single 5-D tensor with shape:
              ``[num_pages, 2, page_size, num_kv_heads, head_dim // 16]`` if :attr:`kv_layout` is ``NHD``,
              and ``[num_pages, 2, num_kv_heads, page_size, head_dim // 16]`` if :attr:`kv_layout` is ``HND``,
              where dim 1 holds k (index 0) and v (index 1) scales.

            Both tensors have dtype ``torch.float8_e4m3fn``.

            Currently, NVFP4 KV supports `fa2` and `trtllm-gen` backend.
        Returns
        -------
        Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]
            If :attr:`return_lse` is ``False``, the attention output, shape: ``[batch_size, num_qo_heads, head_dim]``.
            If :attr:`return_lse` is ``True``, a tuple of two tensors:

            * attention output, shape: ``[batch_size, num_qo_heads, head_dim]``
            * logsumexp of attention scores, shape: ``[batch_size, num_qo_heads]``.
        """
        if enable_pdl is None:
            enable_pdl = device_support_pdl(q.device)
        k_cache, v_cache = _unpack_paged_kv_cache(paged_kv_cache, self._kv_layout)

        if k_cache.dtype == torch.uint8 or v_cache.dtype == torch.uint8:
            if kv_cache_sf is None:
                raise ValueError("kv_cache_sf must be provided for NVFP4 KV cache.")
        key_block_scales, value_block_scales = (
            _unpack_paged_kv_cache(kv_cache_sf, self._kv_layout)
            if kv_cache_sf is not None
            else (None, None)
        )

        if self._kv_layout == "NHD":
            page_size = k_cache.shape[1]
        else:
            page_size = k_cache.shape[2]
        _check_cached_qkv_data_type(
            q, k_cache, self._cached_q_data_type, self._cached_kv_data_type
        )
        actual_batch_size = self._paged_kv_last_page_len_buf.size(0)
        # Soft-deprecation: q_len_per_req moved to plan(). Accept it at run()
        # with a warning and use to validate q.size(0)
        if q_len_per_req is not None:
            warnings.warn(
                "Passing `q_len_per_req` to BatchDecodeWithPagedKVCacheWrapper.run() "
                "is deprecated; pass it to plan() instead. Scheduled for removal "
                "in a future release.",
                DeprecationWarning,
                stacklevel=2,
            )
            expected_q_len = actual_batch_size * q_len_per_req
            if q.size(0) != expected_q_len:
                raise ValueError(
                    f"q.shape[0] ({q.size(0)}) does not match batch_size * q_len_per_req "
                    f"({actual_batch_size} * {q_len_per_req} = {expected_q_len}). "
                    f"For batch decode, q must have shape [batch_size * q_len_per_req, num_heads, head_dim]."
                )
        else:
            # Infer runtime q_len from q.size(0). Doesn't need to match planned q_len
            q_len_per_req = q.size(0) // actual_batch_size

        if not self.use_tensor_cores and not self._uses_cudnn and q_len_per_req > 1:
            raise ValueError(
                f"q implies q_len_per_req={q_len_per_req}, but the "
                "non-tensor-core decode kernel only supports q_len_per_req=1."
            )
        planned_q_len = getattr(self, "_q_len_per_req", 1) or 1
        if (
            (self.use_tensor_cores or self._uses_cudnn)
            and self._backend not in ("trtllm-gen", "cute-dsl")
            and q_len_per_req != planned_q_len
        ):
            # The fa2/fa3 tensor-core path bakes q_len into the planned
            # qo_indptr and mask mode, so a mismatched q cannot be remapped
            # at run time.
            raise ValueError(
                f"q implies q_len_per_req={q_len_per_req} but plan() used "
                f"{planned_q_len}; re-plan with the matching q_len_per_req."
            )

        # Convert NHD layout to HND for trtllm-gen backend
        if self._backend == "trtllm-gen" and self._kv_layout == "NHD":
            k_cache = k_cache.transpose(-3, -2)
            v_cache = v_cache.transpose(-3, -2)
            if key_block_scales is not None:
                print(
                    "[WARNING] NVFP4 KV cache with NHD layout will be converted to HND, "
                    "incurring extra transpose and contiguous copy overhead. "
                    "Use kv_layout='HND' for better performance."
                )
                k_cache = k_cache.contiguous()
                v_cache = v_cache.contiguous()
                key_block_scales = key_block_scales.transpose(-3, -2).contiguous()
                value_block_scales = value_block_scales.transpose(-3, -2).contiguous()

        pos_encoding_mode = self._pos_encoding_mode
        window_left = self._window_left if window_left is None else window_left
        if self._backend not in ("trtllm-gen",):
            # NOTE(Siyuan): since window_left is appeared in the plan function, we need to make sure it is the same as the one in the plan function.
            # Remove this check if the backend supports dynamic window_left.
            assert window_left == self._window_left
        logits_soft_cap = self._logits_soft_cap
        sm_scale = self._sm_scale
        rope_scale = self._rope_scale
        rope_theta = self._rope_theta
        _check_pos_encoding_mode(pos_encoding_mode)
        if logits_soft_cap is None:
            logits_soft_cap = 0.0
        if sm_scale is None:
            head_dim = q.shape[-1]
            sm_scale = 1.0 / math.sqrt(head_dim)
        if q_scale is not None:
            sm_scale *= q_scale
        if k_scale is not None:
            sm_scale *= k_scale
        if rope_scale is None:
            rope_scale = 1.0
        if rope_theta is None:
            rope_theta = 1e4

        if return_lse:
            if lse is None:
                lse = torch.empty(
                    (q.size(0), q.size(1)), dtype=torch.float32, device=q.device
                )
            else:
                check_shape_dtype_device(
                    lse, (q.size(0), q.size(1)), torch.float32, q.device, "lse"
                )

        if self._backend == "cutile":
            if return_lse:
                raise NotImplementedError(
                    "cuTile decode backend does not support return_lse."
                )
            if sinks is not None:
                raise NotImplementedError(
                    "cuTile decode backend does not support attention sinks."
                )
            if kv_cache_sf is not None:
                raise NotImplementedError(
                    "cuTile decode backend does not support NVFP4 KV cache."
                )
            if self._kv_layout != "NHD":
                raise NotImplementedError(
                    "cuTile decode backend requires kv_layout='NHD'."
                )
            if q.shape[0] != actual_batch_size:
                raise NotImplementedError(
                    "cuTile decode backend requires q_len_per_req == 1 "
                    f"(got q.shape[0]={q.shape[0]}, batch_size={actual_batch_size})."
                )
            from .attention.kernels.cutile.fmha_decode_bsr_cutile import (
                fmha_decode_bsr_cutile,
            )

            # This branch returns before the shared out / out_dtype handling
            # below, so honor the planned o_data_type here as well: allocate with
            # it when the caller passed no out, and otherwise validate the buffer
            # we were handed rather than letting the kernel write a tensor whose
            # dtype disagrees with plan().
            cutile_out_dtype = getattr(self, "_cached_o_data_type", None) or q.dtype
            cutile_out_shape = q.shape[:-1] + (v_cache.shape[-1],)
            if out is None:
                out = torch.empty(
                    cutile_out_shape, dtype=cutile_out_dtype, device=q.device
                )
            else:
                check_shape_dtype_device(
                    out, cutile_out_shape, cutile_out_dtype, q.device, "out"
                )

            # Both the block table and the device KV-lengths are materialized at
            # plan() time (see the cuTile plan branch), so run() does only
            # device->device ops (no host .item() sync, no CPU->CUDA copy) and is
            # safe to capture in a CUDA graph.
            actual_seq_lens = self._kv_lens_device.to(device=q.device)
            block_tables = self._block_tables.to(device=q.device, dtype=torch.int32)

            return fmha_decode_bsr_cutile(
                q=q,
                k_cache=k_cache,
                v_cache=v_cache,
                actual_seq_lens=actual_seq_lens,
                block_tables=block_tables,
                k_scale=sm_scale,
                v_scale=1.0 if v_scale is None else v_scale,
                outputs=out,
            )

        if self._backend == "cute-dsl" and out is None:
            out = None  # Let cute-dsl wrapper handle the alloc
        elif out is None:
            out_dtype = getattr(self, "_cached_o_data_type", None) or q.dtype
            # For NVFP4 KV (uint8 packed), v_cache last dim is head_dim//2;
            # use q's head_dim for output instead
            # NVFP4 packed: unpacked VO width is packed bytes * 2 (supports
            # asymmetric QK/VO plans; q.shape[-1] assumed QK == VO).
            # Only the NVFP4 packed path (uint8 KV) stores VO at half width;
            # derive the doubled output width from the KV dtype, not merely from
            # kv_cache_sf being present, so a stray scale-factor tensor on a
            # non-uint8 cache can't silently miscompute the output shape.
            out_head_dim = (
                v_cache.shape[-1] * 2
                if kv_cache_sf is not None and v_cache.dtype == torch.uint8
                else v_cache.shape[-1]
            )
            out = torch.empty(
                q.shape[:-1] + (out_head_dim,), dtype=out_dtype, device=q.device
            )
        else:
            out_dtype = getattr(self, "_cached_o_data_type", None) or q.dtype
            check_shape_dtype_device(out, q.shape, out_dtype, q.device, "out")

        if self._backend == "cute-dsl":
            if kv_cache_sf is not None:
                raise NotImplementedError(
                    "cute-dsl decode backend does not support NVFP4 KV cache"
                )
            # Kernel expects logical NHD; HND data is presented via transpose.
            if self._kv_layout == "HND":
                k_cache_view = k_cache.transpose(-3, -2)
                v_cache_view = v_cache.transpose(-3, -2)
            else:
                k_cache_view = k_cache
                v_cache_view = v_cache
            # Fold v_scale into the kernel's o_scale — the cute-dsl kernel
            # applies it in the reduction epilogue for free, replacing the
            # post-kernel `out *= v_scale` that other backends still need.
            o_scale = None if v_scale is None else float(v_scale)
            out = self._cute_dsl_wrapper.run(
                q,
                k_cache_view,
                v_cache_view,
                out=out,
                sm_scale=sm_scale,
                o_scale=o_scale,
                sinks=sinks,
                skip_softmax_threshold_scale_factor=skip_softmax_threshold_scale_factor,
                lse=lse if return_lse else None,
                enable_pdl=enable_pdl,
            )
            return (out, lse) if return_lse else out

        if self._backend == "trtllm-gen":
            q = q.view(q.size(0) // q_len_per_req, q_len_per_req, q.size(1), q.size(2))

        trtllm_gen_bmm2_scale: Optional[Union[float, torch.Tensor]] = None

        if self._uses_cudnn:
            if kv_cache_sf is not None:
                raise NotImplementedError(
                    "cudnn decode backend does not support NVFP4 KV cache."
                )
            if skip_softmax_threshold_scale_factor is not None:
                raise NotImplementedError(
                    "cudnn decode backend does not support skip-softmax."
                )
            if v_cache.dtype != self._cached_kv_data_type:
                raise ValueError(
                    f"The dtype of v {v_cache.dtype} does not match the kv_data_type "
                    f"{self._cached_kv_data_type} specified in plan function."
                )
            # The cuDNN graph is built from strides, so an NHD cache is presented
            # as a transposed [pages, heads, page_size, head_dim] view (no copy).
            if self._kv_layout == "NHD":
                k_cache = k_cache.transpose(-3, -2)
                v_cache = v_cache.transpose(-3, -2)
            if q.stride(-1) != 1:
                q = q.contiguous()
            # Staged at plan() time (device buffers, no host sync): safe to capture.
            # The graph is prepared once per signature (validation, graph-cache
            # lookup, variant pack); a step rebinds q / caches / out / lse and runs.
            # q has batch * q_len_per_req consecutive rows per request; the graph
            # applies the bottom-right causal diagonal for q_len > 1, the left
            # window bound and the per-head sink logits.
            kv_lens = self._cudnn_kv_lens_view
            if kv_lens is None or kv_lens.shape[0] != actual_batch_size:
                kv_lens = self._kv_lens_buffer[:actual_batch_size].view(
                    actual_batch_size, 1, 1, 1
                )
            signature = dict(
                max_sequence_kv=self._max_kv_len,
                actual_seq_lens_kv=kv_lens,
                block_tables=self._block_tables,
                return_lse=return_lse,
                q_len_per_req=q_len_per_req,
                window_left=window_left,
            )
            if not _CUDNN_GRAPH_AVAILABLE:
                # No cuDNN graph API installed: the public entry point's cubin fallback.
                cudnn_batch_decode_with_kv_cache(
                    q,
                    k_cache,
                    v_cache,
                    sm_scale,
                    self._float_workspace_buffer,
                    is_cuda_graph_compatible=self.is_cuda_graph_enabled,
                    out=out,
                    lse=lse,
                    sinks=sinks,
                    **signature,
                )
            else:
                prepared = self._cudnn_prepared
                if prepared is None or not prepared.matches(
                    q,
                    k_cache,
                    v_cache,
                    sm_scale,
                    out=out,
                    lse=lse,
                    sinks=sinks,
                    **signature,
                ):
                    prepared = self._cudnn_prepared = prepare_cudnn_batch_decode(
                        q,
                        k_cache,
                        v_cache,
                        sm_scale,
                        out=out,
                        lse=lse,
                        sinks=sinks,
                        actual_seq_lens_q=self._cudnn_q_lens_view,
                        **signature,
                    )
                prepared.run(
                    q,
                    k_cache,
                    v_cache,
                    out,
                    lse,
                    self._float_workspace_buffer,
                    actual_seq_lens_kv=kv_lens,
                    block_tables=self._block_tables,
                    sinks=sinks,
                )
        elif self.use_tensor_cores:
            # trtllm-gen applies v_scale in-kernel as its bmm2 scale.
            if (
                self._backend == "trtllm-gen"
                and self._jit_module is None
                and v_scale is not None
            ):
                if isinstance(v_scale, (int, float)):
                    trtllm_gen_bmm2_scale = float(v_scale)
                elif (
                    isinstance(v_scale, torch.Tensor)
                    and v_scale.dtype == torch.float32
                    and v_scale.numel() == 1
                    and v_scale.device == q.device
                ):
                    trtllm_gen_bmm2_scale = v_scale
            run_args = [self._float_workspace_buffer]
            if self._backend == "trtllm-gen":
                assert self._trtllm_gen_multi_ctas_kv_counter_buffer is not None
                run_args.append(self._trtllm_gen_multi_ctas_kv_counter_buffer)
            run_args += [
                self._int_workspace_buffer,
                self._plan_info,
                q,
                k_cache,
                v_cache,
                self._qo_indptr_buf,
                self._paged_kv_indptr_buf,
                self._paged_kv_indices_buf,
                self._paged_kv_last_page_len_buf,
                out,
                lse,
                (
                    MaskMode.CAUSAL.value
                    if planned_q_len > 1
                    else MaskMode.NON_CAUSAL.value
                ),
                TensorLayout[self._kv_layout].value,
                window_left,
                enable_pdl,
            ]

            if self._jit_module is not None:
                run_args.extend(
                    prepare_jit_additional_args(
                        self._jit_additional_tensor_names,
                        {
                            "maybe_custom_mask": None,
                            "maybe_mask_indptr": None,
                            "maybe_alibi_slopes": lambda: _get_cache_alibi_slopes_buf(
                                q.shape[1], q.device
                            ),
                        },
                        args,
                    )
                )
            else:
                # Extract FP8 scale tensors from *args if q is FP8
                fp8_scale_q = None
                fp8_scale_k = None
                fp8_scale_v = None
                if is_float8(q) and len(args) >= 3:
                    fp8_scale_q = args[0]
                    fp8_scale_k = args[1]
                    fp8_scale_v = args[2]
                if self._backend == "trtllm-gen":
                    fp8_scale_v = trtllm_gen_bmm2_scale
                run_args += [
                    None,  # packed_custom_mask
                    None,  # mask_indptr_buf
                    _get_cache_alibi_slopes_buf(q.shape[1], q.device),
                    None,  # maybe_prefix_len_ptr
                    None,  # maybe_token_pos_in_items_ptr
                    None,  # maybe_max_item_len_ptr
                    logits_soft_cap,
                    sm_scale,
                    fp8_scale_q,
                    fp8_scale_k,
                    fp8_scale_v,
                    rope_scale,
                    rope_theta,
                    0,  # token_pos_in_items_len
                    self._workspace_size,
                ]

                if self._backend == "trtllm-gen":
                    bf16q_fp8kv_transform_mode = (
                        _TRTLLM_GEN_BF16Q_FP8KV_TRANSFORM_MODES["separate_kv"]
                        if q.dtype == torch.bfloat16
                        and k_cache.dtype == torch.float8_e4m3fn
                        and v_cache.dtype == torch.float8_e4m3fn
                        and out.dtype == torch.bfloat16
                        else 0
                    )
                    # decode.py's trtllm-gen paged_run (get_trtllm_gen_decode_module)
                    # has a different optional-param layout than prefill.py's paged_run
                    run_args += [
                        paged_kv_cache,
                        self._num_qo_heads,
                        self._num_kv_heads,
                        self._block_tables,
                        self._kv_lens_buffer,
                        page_size,
                        self._max_kv_len,
                        sinks,
                        key_block_scales,
                        value_block_scales,
                        skip_softmax_threshold_scale_factor,
                        True,  # uses_shared_paged_kv_idx
                        bf16q_fp8kv_transform_mode,
                    ]
                else:
                    run_args += [
                        self._num_qo_heads,
                        self._num_kv_heads,
                        self._block_tables,
                        self._kv_lens_buffer,
                        page_size,
                        None,  # max_q_len (not applicable for decode)
                        self._max_kv_len,
                        None,  # batch_size (not applicable for decode)
                        None,  # cum_seq_lens_q (not applicable for decode)
                        None,  # cum_seq_lens_kv (not applicable for decode)
                        sinks,
                        key_block_scales,
                        value_block_scales,
                        skip_softmax_threshold_scale_factor,
                        True,  # uses_shared_paged_kv_idx
                    ]

            self._cached_module.paged_run(*run_args)
        else:
            # trtllm-gen does not need plan info
            if self._backend == "trtllm-gen" and self._plan_info is None:
                plan_info: List[int] = []
            else:
                plan_info = self._plan_info
            assert plan_info is not None, "plan info is not initialized"

            run_args = [
                self._float_workspace_buffer,
                self._int_workspace_buffer,
                self._plan_info,
                q,
                k_cache,
                v_cache,
                self._paged_kv_indptr_buf,
                self._paged_kv_indices_buf,
                self._paged_kv_last_page_len_buf,
                out,
                lse,
                TensorLayout[self._kv_layout].value,
                window_left,
                enable_pdl,
            ]

            if self._jit_module is not None:
                run_args.extend(
                    prepare_jit_additional_args(
                        self._jit_additional_tensor_names,
                        {
                            "maybe_alibi_slopes": lambda: _get_cache_alibi_slopes_buf(
                                q.shape[1], q.device
                            ),
                        },
                        args,
                    )
                )
            else:
                run_args += [
                    _get_cache_alibi_slopes_buf(q.shape[1], q.device),
                    logits_soft_cap,
                    sm_scale,
                    rope_scale,
                    rope_theta,
                ]

            self._cached_module.run(*run_args)

        is_float_one = isinstance(v_scale, float) and v_scale == 1.0
        if v_scale is not None and not is_float_one and trtllm_gen_bmm2_scale is None:
            # TODO(Zihao): fused into kernel
            if is_float8(out):
                out = (out.to(torch.float32) * v_scale).to(out.dtype)
            else:
                out *= v_scale

        return (out, lse) if return_lse else out

    def forward_return_lse(
        self,
        q: torch.Tensor,
        paged_kv_cache: torch.Tensor,
        pos_encoding_mode: str = "NONE",
        q_scale: Optional[float] = None,
        k_scale: Optional[float] = None,
        v_scale: Optional[float] = None,
        window_left: int = -1,
        logits_soft_cap: Optional[float] = None,
        sm_scale: Optional[float] = None,
        rope_scale: Optional[float] = None,
        rope_theta: Optional[float] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        r"""Warning: this function is deprecated, please use :meth:`run_return_lse` instead."""
        self._pos_encoding_mode = pos_encoding_mode
        self._window_left = window_left
        self._logits_soft_cap = logits_soft_cap
        self._sm_scale = sm_scale
        self._rope_scale = rope_scale
        self._rope_theta = rope_theta
        return self.run(
            q,
            paged_kv_cache,
            q_scale=q_scale,
            k_scale=k_scale,
            v_scale=v_scale,
            return_lse=True,
        )

    run_return_lse = functools.partialmethod(run, return_lse=True)


class CUDAGraphBatchDecodeWithPagedKVCacheWrapper(BatchDecodeWithPagedKVCacheWrapper):
    r"""CUDAGraph-compatible Wrapper class for decode attention with paged kv-cache (first
    proposed in `vLLM <https://arxiv.org/abs/2309.06180>`_) for batch of requests.

    Note that this wrapper may not be as efficient as :class:`BatchDecodeWithPagedKVCacheWrapper`
    because we won't dispatch to different kernels for different batch sizes/sequence lengths/etc
    to accommodate the CUDAGraph requirement.

    Check :ref:`our tutorial<kv-layout>` for page table layout.

    Note
    ----
    The :meth:`plan` method could not be captured by CUDAGraph.

    See Also
    --------
    :class:`BatchDecodeWithPagedKVCacheWrapper`
    """

    # No @flashinfer_api here: parent class BatchDecodeWithPagedKVCacheWrapper
    # already decorates __init__, so decorating again produces double log entries.
    def __init__(
        self,
        workspace_buffer: torch.Tensor,
        indptr_buffer: torch.Tensor,
        indices_buffer: torch.Tensor,
        last_page_len_buffer: torch.Tensor,
        kv_layout: str = "NHD",
        use_tensor_cores: bool = False,
    ) -> None:
        r"""Constructor of :class:`BatchDecodeWithPagedKVCacheWrapper`.

        Parameters
        ----------
        workspace_buffer : torch.Tensor
            The user reserved workspace buffer on GPU used to store auxiliary data structures,
            recommended size is 128MB, the device of the workspace buffer should be the
            same as the device of the input tensors.

        indptr_buffer : torch.Tensor
            The user reserved buffer on GPU to store the indptr of the paged kv cache, should
            be large enough to store the indptr of maximum batch size (``[max_batch_size + 1]``)
            during the lifecycle of this wrapper.

        indices_buffer : torch.Tensor
            The user reserved buffer on GPU to store the page indices of the paged kv cache,
            should be large enough to store the maximum number of page indices
            (``max_num_pages``) during the lifecycle of this wrapper.

        last_page_len_buffer : torch.Tensor
            The user reserved buffer on GPU to store the number of entries in the last page,
            should be large enough to store the maximum batch size (``[max_batch_size]``)
            during the lifecycle of this wrapper.

        use_tensor_cores : bool
            Whether to use tensor cores for the computation. Will be faster for large group
            size in grouped query attention. Defaults to ``False``.

        kv_layout : str
            The layout of the input k/v tensors, could be either ``NHD`` or ``HND``.
        """
        super().__init__(
            workspace_buffer,
            kv_layout,
            use_cuda_graph=True,
            use_tensor_cores=use_tensor_cores,
            paged_kv_indptr_buffer=indptr_buffer,
            paged_kv_indices_buffer=indices_buffer,
            paged_kv_last_page_len_buffer=last_page_len_buffer,
        )


def _get_trtllm_gen_bmm1_scale_arg(
    bmm1_scale: Union[float, torch.Tensor],
    bmm1_scale_log2: Optional[torch.Tensor],
    device: torch.device,
) -> Union[float, torch.Tensor]:
    if bmm1_scale_log2 is not None:
        if not isinstance(bmm1_scale_log2, torch.Tensor):
            raise TypeError("bmm1_scale_log2 must be a torch.Tensor")
        if bmm1_scale_log2.dtype != torch.float32:
            raise TypeError("bmm1_scale_log2 tensor must have dtype torch.float32")
        if bmm1_scale_log2.device != device:
            raise ValueError("bmm1_scale_log2 must be on the same device as query")
        if bmm1_scale_log2.numel() != 1:
            raise ValueError(
                "bmm1_scale_log2 must be a single-element tensor "
                "(e.g. a narrow(0, i, 1) view of the precomputed scale workspace)"
            )
        return bmm1_scale_log2
    if isinstance(bmm1_scale, torch.Tensor):
        if bmm1_scale.dtype != torch.float32:
            raise TypeError("bmm1_scale tensor must have dtype torch.float32")
        return bmm1_scale * log2e
    return bmm1_scale


class TrtllmGenDecodeModule:
    def __init__(self) -> None:
        self._sm_count: Optional[int] = None
        self._mod = gen_trtllm_gen_fmha_module()
        self._op = self._mod.build_and_load()
        from flashinfer.jit.cubin_loader import setup_cubin_loader

        for library_path in self._mod.get_library_paths():
            setup_cubin_loader(library_path)

    def _paged_run(
        self,
        query: torch.Tensor,
        k_cache: torch.Tensor,
        v_cache: torch.Tensor,
        workspace_buffer: torch.Tensor,
        multi_ctas_kv_counter_buffer: torch.Tensor,
        block_tables: torch.Tensor,
        seq_lens: torch.Tensor,
        max_seq_len: int,
        bmm1_scale: Union[float, torch.Tensor],
        bmm2_scale: Union[float, torch.Tensor],
        workspace_size: int,
        window_left: int = -1,
        enable_pdl: bool = None,
        out: Optional[torch.Tensor] = None,
        sinks: Optional[torch.Tensor] = None,
        key_block_scales: Optional[torch.Tensor] = None,
        value_block_scales: Optional[torch.Tensor] = None,
        skip_softmax_threshold_scale_factor: Optional[float] = None,
        uses_shared_paged_kv_idx: bool = True,
        lse: Optional[torch.Tensor] = None,
        bf16q_fp8kv_transform_mode: int = 0,
    ) -> torch.Tensor:
        if out is None:
            out = torch.empty_like(query)
        if self._sm_count is None:
            self._sm_count = get_device_sm_count(query.device)

        bmm1_scale = _get_trtllm_gen_bmm1_scale_arg(bmm1_scale, None, query.device)
        if isinstance(bmm2_scale, torch.Tensor):
            assert bmm2_scale.dtype == torch.float32

        assert len(query.size()) == 4
        batch_size = query.size(0)
        max_q_len = query.size(1)
        query = query.flatten(0, 1)  # [B*S, H, D]

        if lse is not None:
            check_shape_dtype_device(
                lse, (query.size(0), query.size(1)), torch.float32, query.device, "lse"
            )
            lse_stride_tokens = lse.stride(0)
            lse_stride_heads = lse.stride(1)
        else:
            lse_stride_tokens = 0
            lse_stride_heads = 0

        self._op.trtllm_paged_attention_decode(
            out,
            None,  # fp4 output not supported in wrapper api yet.
            query,  # [B * S, H, D], w/ MTP here so S dim is > 1
            k_cache,
            v_cache,
            workspace_buffer,
            multi_ctas_kv_counter_buffer,
            block_tables,
            seq_lens,
            max_q_len,
            max_seq_len,
            bmm1_scale,
            bmm2_scale,
            -1,  # o_sf_scale
            -1,  # o_sf_vec_size
            0,  # o_sf_start_index
            batch_size,
            window_left,
            0,  # sparse_mla_top_k
            self._sm_count,
            enable_pdl,
            workspace_size,
            sinks,
            None,  # cum_seq_lens_q
            key_block_scales,
            value_block_scales,
            skip_softmax_threshold_scale_factor,
            uses_shared_paged_kv_idx,
            lse,
            1.0,  # lse_scale
            lse_stride_tokens,
            lse_stride_heads,
            False,  # enable_block_sparse_attention
            None,  # sparse_mla_top_k_lens
            bf16q_fp8kv_transform_mode,
            None,  # use_fp16_softmax
        )
        return out

    def _plan(self, *args, **kwargs):
        pass


@functools.cache
def get_trtllm_gen_decode_module(*args):
    uri = get_batch_prefill_uri("trtllm-gen", *args)
    module = TrtllmGenDecodeModule()

    @register_custom_op(
        f"flashinfer::{uri}_ragged_run",
        mutates_args=(
            "float_workspace_buffer",
            "multi_ctas_kv_counter_buffer",
            "int_workspace_buffer",
            "o",
            "maybe_lse",
        ),
    )
    def paged_run(
        float_workspace_buffer: torch.Tensor,
        multi_ctas_kv_counter_buffer: torch.Tensor,
        int_workspace_buffer: torch.Tensor,
        plan_info_vec: List[int],
        q: torch.Tensor,
        paged_k_cache: torch.Tensor,
        paged_v_cache: torch.Tensor,
        qo_indptr: torch.Tensor,
        paged_kv_indptr: torch.Tensor,
        paged_kv_indices: torch.Tensor,
        paged_kv_last_page_len: torch.Tensor,
        o: torch.Tensor,
        maybe_lse: Optional[torch.Tensor],
        mask_mode: int,
        layout: int,
        window_left: int,
        enable_pdl: bool,
        maybe_custom_mask: Optional[torch.Tensor],
        maybe_mask_indptr: Optional[torch.Tensor],
        maybe_alibi_slopes: Optional[torch.Tensor],
        maybe_prefix_len_ptr: Optional[torch.Tensor],
        maybe_token_pos_in_items_ptr: Optional[torch.Tensor],
        maybe_max_item_len_ptr: Optional[torch.Tensor],
        logits_soft_cap: float,
        sm_scale: float,
        scale_q: Optional[torch.Tensor],
        scale_k: Optional[torch.Tensor],
        scale_v: Optional[torch.Tensor],
        rope_scale: float,
        rope_theta: float,
        token_pos_in_items_len: int,
        workspace_size: int,
        paged_kv_cache: Optional[torch.Tensor] = None,
        num_qo_heads: Optional[int] = None,
        num_kv_heads: Optional[int] = None,
        block_tables: Optional[torch.Tensor] = None,
        kv_lens_buffer: Optional[torch.Tensor] = None,
        page_size: Optional[int] = None,
        max_kv_len: Optional[int] = None,
        sinks: Optional[torch.Tensor] = None,
        key_block_scales: Optional[torch.Tensor] = None,
        value_block_scales: Optional[torch.Tensor] = None,
        skip_softmax_threshold_scale_factor: Optional[float] = None,
        uses_shared_paged_kv_idx: bool = True,
        bf16q_fp8kv_transform_mode: int = 0,
    ) -> None:
        assert paged_kv_cache is not None
        assert num_qo_heads is not None
        assert num_kv_heads is not None
        assert block_tables is not None
        assert kv_lens_buffer is not None
        assert page_size is not None
        assert max_kv_len is not None
        assert enable_pdl is not None
        assert workspace_size > 0, "workspace_size must be greater than 0"
        o = module._paged_run(
            q.contiguous(),  # NOTE(Siyuan): without contiguous, the result is incorrect
            paged_k_cache,
            paged_v_cache,
            float_workspace_buffer,
            multi_ctas_kv_counter_buffer,
            block_tables,
            kv_lens_buffer,
            max_kv_len,
            sm_scale,
            scale_v if scale_v is not None else 1.0,  # bmm2 scale
            workspace_size,
            window_left,
            enable_pdl,
            out=o,
            sinks=sinks,
            key_block_scales=key_block_scales,
            value_block_scales=value_block_scales,
            skip_softmax_threshold_scale_factor=skip_softmax_threshold_scale_factor,
            uses_shared_paged_kv_idx=uses_shared_paged_kv_idx,
            lse=maybe_lse,
            bf16q_fp8kv_transform_mode=bf16q_fp8kv_transform_mode,
        )

    @register_fake_op(f"flashinfer::{uri}_paged_run")
    def _fake_paged_run(
        float_workspace_buffer: torch.Tensor,
        multi_ctas_kv_counter_buffer: torch.Tensor,
        int_workspace_buffer: torch.Tensor,
        plan_info_vec: List[int],
        q: torch.Tensor,
        paged_k_cache: torch.Tensor,
        paged_v_cache: torch.Tensor,
        qo_indptr: torch.Tensor,
        paged_kv_indptr: torch.Tensor,
        paged_kv_indices: torch.Tensor,
        paged_kv_last_page_len: torch.Tensor,
        o: torch.Tensor,
        maybe_lse: Optional[torch.Tensor],
        mask_mode: int,
        layout: int,
        window_left: int,
        enable_pdl: bool,
        maybe_custom_mask: Optional[torch.Tensor],
        maybe_mask_indptr: Optional[torch.Tensor],
        maybe_alibi_slopes: Optional[torch.Tensor],
        maybe_prefix_len_ptr: Optional[torch.Tensor],
        maybe_token_pos_in_items_ptr: Optional[torch.Tensor],
        maybe_max_item_len_ptr: Optional[torch.Tensor],
        logits_soft_cap: float,
        sm_scale: float,
        scale_q: Optional[torch.Tensor],
        scale_k: Optional[torch.Tensor],
        scale_v: Optional[torch.Tensor],
        rope_scale: float,
        rope_theta: float,
        token_pos_in_items_len: int,
        workspace_size: int,
        paged_kv_cache: Optional[torch.Tensor] = None,
        num_qo_heads: Optional[int] = None,
        num_kv_heads: Optional[int] = None,
        block_tables: Optional[torch.Tensor] = None,
        kv_lens_buffer: Optional[torch.Tensor] = None,
        page_size: Optional[int] = None,
        max_kv_len: Optional[int] = None,
        sinks: Optional[torch.Tensor] = None,
        key_block_scales: Optional[torch.Tensor] = None,
        value_block_scales: Optional[torch.Tensor] = None,
        skip_softmax_threshold_scale_factor: Optional[float] = None,
        uses_shared_paged_kv_idx: bool = True,
        bf16q_fp8kv_transform_mode: int = 0,
    ) -> None:
        pass

    # Register the module.
    #
    # Note that plan is not part of model logic. It should not be included in
    # Cuda Graph or torch.compile. So, we don't provide a torch library for plan.
    return SimpleNamespace(
        plan=module._plan,
        paged_run=paged_run,
    )


@flashinfer_api(trace=trtllm_batch_decode_trace_dispatch)
def trtllm_batch_decode_with_kv_cache(
    query: torch.Tensor,
    kv_cache: Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]],
    workspace_buffer: torch.Tensor,
    block_tables: torch.Tensor,
    seq_lens: torch.Tensor,
    max_seq_len: int,
    bmm1_scale: Union[float, torch.Tensor] = 1.0,
    bmm2_scale: Union[float, torch.Tensor] = 1.0,
    window_left: int = -1,
    out: Optional[Union[torch.Tensor, FP4Tensor]] = None,
    out_dtype: Optional[Union[torch.dtype, str]] = None,
    o_sf_scale: Optional[float] = None,
    o_sf_vec_size: Optional[int] = None,
    sinks: Optional[List[torch.Tensor]] = None,
    kv_layout: str = "HND",
    enable_pdl: Optional[bool] = None,
    backend: str = "auto",
    q_len_per_req: Optional[int] = 1,
    o_scale: Optional[float] = 1.0,
    mask: Optional[torch.Tensor] = None,
    max_q_len: Optional[int] = None,
    cum_seq_lens_q: Optional[torch.Tensor] = None,
    skip_softmax_threshold_scale_factor: Optional[float] = None,
    kv_cache_sf: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
    uses_shared_paged_kv_idx: bool = True,
    lse: Optional[torch.Tensor] = None,
    return_lse: bool = False,
    bmm1_scale_log2: Optional[torch.Tensor] = None,
    multi_ctas_kv_counter_buffer: Optional[torch.Tensor] = None,
    enable_block_sparse_attention: bool = False,
    cp_world: int = 1,
    cp_rank: int = 0,
    causal_seqlens_kv_global: Optional[torch.Tensor] = None,
    bf16q_fp8kv_transform_mode: Optional[Literal["k_only", "separate_kv"]] = None,
    request_order: Optional[torch.Tensor] = None,
    request_order_plan: Optional[Any] = None,
) -> Union[
    torch.Tensor, FP4Tensor, Tuple[Union[torch.Tensor, FP4Tensor], torch.Tensor]
]:
    """
    Parameters
    ----------
    query : torch.Tensor
        query tensor with shape [num_tokens, num_heads, head_dim], num_tokens = total query tokens in the batch.

    kv_cache : Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]
        If kv_cache is a single tensor, it should be a tensor with shape [num_pages, 1 or 2, num_kv_heads, page_size, head_dim] if :attr:`kv_layout` is ``HND``,
        or [num_pages, 1 or 2, page_size, num_kv_heads, head_dim] if :attr:`kv_layout` is ``NHD``.
        If kv_cache is a tuple of two tensors, it should be a tuple of two tensors with shape [num_pages, num_kv_heads, page_size, head_dim] if :attr:`kv_layout` is ``HND``,
        or [num_pages, page_size, num_kv_heads, head_dim] if :attr:`kv_layout` is ``NHD``.
        The first tensor is the key cache, and the second tensor is the value cache.

        **Contiguity requirements (trtllm-gen backend):**

        - The ``head_dim`` (last dim) **must** have stride 1. This is a TMA hardware constraint
        - The head and batch/page dims can have arbitrary strides.

    workspace_buffer : torch.Tensor
        Workspace used for trtllm-gen softmax stats/scratch or xqa scratch.

    block_tables : torch.Tensor
        Page table of kv cache.
        When ``uses_shared_paged_kv_idx`` is True (default): shape ``[batch_size, max_num_pages_per_seq]``.
        When ``uses_shared_paged_kv_idx`` is False: shape ``[batch_size, 2, max_num_pages_per_seq]``
        where dim 1 distinguishes K (0) and V (1) page indices.
        When ``enable_block_sparse_attention`` is True: shape
        ``[num_kv_heads, batch_size, max_num_pages_per_seq]`` (contiguous), where each row holds
        the page indices *selected* for that (kv head, sequence) pair, packed densely at the
        front of the row in ascending original order; the remaining entries are ignored.

    seq_lens : torch.Tensor
        A uint32 1D tensor indicating the kv sequence length of each prompt. shape: ``[batch_size]``.
        When ``enable_block_sparse_attention`` is True: shape ``[num_kv_heads, batch_size]``
        (contiguous), holding the number of *surviving* kv tokens per (kv head, sequence) pair
        after dropping the non-selected pages. Since selected pages are packed in ascending
        order, only the final selected page of a row may be partially filled.

    max_seq_len : int
        max sequence length for kv_cache

    bmm1_scale : Union[float, torch.Tensor]
        fused scale for bmm1 input.
        when using trtllm-gen backend, it can be a torch.Tensor with dtype torch.float32.

    bmm1_scale_log2 : Optional[torch.Tensor] = None
        Optional precomputed log2-form bmm1 scale for ``trtllm-gen``. When provided,
        this single-element FP32 device tensor is passed directly to the FFI and takes precedence over
        tensor ``bmm1_scale``, avoiding the internal ``bmm1_scale * log2e`` CUDA kernel.

    bmm2_scale : Union[float, torch.Tensor]
        fused scale for bmm2 input.
        when using trtllm-gen backend, it can be a torch.Tensor with dtype torch.float32.

    window_left : int = -1
        The left (inclusive) window size for the attention window, when set to ``-1``, the window
        size will be set to the full length of the sequence. Defaults to ``-1``.

    out :  Optional[Union[torch.Tensor, FP4Tensor]] = None
        output tensor, if not provided, will be allocated with ``out_dtype``, if ``out_dtype`` is not provided, will use the type of ``query``.

    out_dtype : Optional[Union[torch.dtype, str]] = None
        output dtype, if not provided, will use the type of ``out``. For nvfp4, use string ``nvfp4``.

    o_sf_scale : Optional[float] = None
        scale for nvfp4 output tensor scale factor.

    o_sf_vec_size : Optional[int] = None
        vector size for nvfp4 output tensor scale factor.

    sinks : Optional[List[torch.Tensor]] = None
        additional value per head in the denominator of the softmax.

    kv_layout : str = "HND"
        The layout of the input k/v tensors, could be either ``NHD`` or ``HND``.
        Defaults to ``HND``.
        For the trtllm-gen backend with NVFP4 KV cache, using ``NHD`` will trigger an
        automatic transpose and ``.contiguous()`` copy of both the KV data and block scale
        tensors to convert them to HND layout. This incurs extra memory allocation and
        data copy overhead. Use ``HND`` for better performance.

    enable_pdl : Optional[bool] = None
        Whether to enable Programmatic Dependent Launch (PDL). See https://docs.nvidia.com/cuda/cuda-c-programming-guide/#programmatic-dependent-launch-and-synchronization
        When set to ``None``, the backend will be chosen based on the device architecture and kernel availability.

    backend : str = "auto"
        The implementation backend, could be ``auto``/``xqa``/``trtllm-gen`` or
        ``cake``. Defaults to ``auto``. ``cake`` selects the separately versioned
        Cake FMHA product and never participates in automatic backend selection.
        When set to ``auto``, the backend will be chosen based on the device architecture and kernel availability.
        For sm_100 and sm_103 (blackwell architecture), ``auto`` will choose ``trtllm-gen`` backend.
        For sm_90 (hopper architecture) and sm_120/sm_121 (blackwell architecture), ``auto`` will choose ``xqa`` backend.

    q_len_per_req : Optional[int] = 1
        Number of query tokens per request (i.e. speculative-decoding / MTP depth).
        ``query`` is expected to have ``batch_size * q_len_per_req`` rows along its
        leading dimension when ``cum_seq_lens_q`` / ``max_q_len`` are ``None``.
        Defaults to ``1``.

    o_scale : Optional[float] = 1.0
        output scale factor for xqa fp8 output.

    mask : Optional[torch.Tensor] = None
        causal attention mask for xqa speculative decoding.

    max_q_len: Optional[int] = None
        The maximum query sequence length across all requests when using variable-length queries.
        Only supported by trtllm-gen backend. Must be provided together with ``cum_seq_lens_q``.
        When None, all requests use uniform query length specified by ``q_len_per_req``.

    cum_seq_lens_q : Optional[torch.Tensor] = None
        Cumulative query sequence lengths for variable-length query support, shape: ``[batch_size + 1]``, dtype: ``torch.int32``.
        Only supported by trtllm-gen backend. Must be provided together with ``max_q_len``.
        When None, all requests use uniform query length specified by ``q_len_per_req``.

    skip_softmax_threshold_scale_factor: Optional[float] = None
        threshold scale factor for skipping softmax operations.
        Providing a value for this parameter enables skip-softmax sparsity as described in: https://arxiv.org/abs/2512.12087
        If no value is provided, then standard attention is used.
        Setting the threshold to a higher value generally increases kernel performance at the cost of accuracy degradation.
        The actual threshold value equals the provided threshold_scale_factor divided by the context length.

    kv_cache_sf : Optional[Tuple[torch.Tensor, torch.Tensor]] = None
        Per-block scale factors for NVFP4 KV cache, as a tuple of ``(k_scales, v_scales)``.
        Each scale tensor has shape ``[num_pages, num_kv_heads, page_size, head_dim // 16]``
        in HND layout, with dtype ``torch.float8_e4m3fn``.

        **Contiguity requirements (trtllm-gen backend):**

        - The last two dims (``page_size``, ``head_dim // 16``) **must** be contiguous
          (i.e., ``stride[-1] == 1`` and ``stride[-2] == head_dim // 16``). This is because
          the kernel reshapes them into ``(16, page_size * head_dim / 16 / 16)`` to satisfy
          TMA's 16-byte box width minimum.
        - The head and batch/page dims can have arbitrary strides.

    uses_shared_paged_kv_idx : bool = True
        Whether the K and V page indices are shared as a unified index.
        True (default) uses vLLM/FlashInfer layout with a 2D page table.
        False uses TRT-LLM layout with a 3D page table ``[batch_size, 2, max_num_pages_per_seq]``.

    lse : Optional[torch.Tensor] = None
        Optional pre-allocated buffer for the Log-Sum-Exp (LSE) output, only supported
        by the ``trtllm-gen`` backend. Must have shape ``[num_tokens, num_qo_heads]``
        and dtype ``torch.float32``. If provided, the tensor is filled regardless of
        :attr:`return_lse`. If ``return_lse`` is True and this is None, a buffer will
        be allocated internally.

    return_lse : bool = False
        Whether to return the Log-Sum-Exp (LSE) values. Only supported by the
        ``trtllm-gen`` backend. When True, the function returns a tuple
        ``(out, lse)`` where ``lse`` has shape ``[num_tokens, num_qo_heads]`` and
        dtype ``torch.float32``.

    multi_ctas_kv_counter_buffer : Optional[torch.Tensor] = None
        Optional separate counter buffer for ``trtllm-gen`` multi-CTA KV mode.
        When omitted, FlashInfer creates a fresh zeroed internal buffer. When
        provided, it must be zero-initialized at allocation (e.g. via
        ``torch.zeros``); the kernel self-resets the counters at the end of each
        launch, so it does not need to be re-zeroed between calls.

    enable_block_sparse_attention : bool = False
        Whether to use block-sparse attention with different sparse KV pages per KV head.
        Only supported by the ``trtllm-gen`` backend. When True, ``block_tables`` and
        ``seq_lens`` are extended with a leading ``num_kv_heads`` dimension (see their
        docs above); each KV head only attends to the pages listed in its own row.
        ``max_seq_len`` should be the maximum surviving kv length across all
        (kv head, sequence) pairs (the dense maximum is a safe upper bound).
        Not compatible with sliding window (``window_left != -1``),
        ``skip_softmax_threshold_scale_factor``, or ``uses_shared_paged_kv_idx=False``.

    cp_world : int = 1
        Decode-context-parallel world size. The DCP speculative path is enabled
        only when :attr:`causal_seqlens_kv_global` is provided. Supported values
        are 1, 2, 4, and 8 on SM100/SM103.

    cp_rank : int = 0
        Rank in the DCP group. Rank ``r`` owns global KV positions
        ``r, r + cp_world, ...`` in its compact local paged cache.

    causal_seqlens_kv_global : Optional[torch.Tensor] = None
        Optional contiguous int32 tensor of shape ``[batch_size]`` containing
        each request's global KV prefix length before speculative query row 0.
        When provided, query row ``j`` sees exactly
        ``max(0, floor((S + j - cp_rank) / cp_world) + 1)`` local keys. This
        enables DCP + speculative decoding without a per-row length tensor.

        The native Cake FMHA path requires BF16 Q/O, head dimension 128,
        causal HND paging, ``return_lse=True`` (or a caller-owned ``lse``), and
        head group ratio in ``[1,8]``. BF16 KV uses page size 16 and
        ``q_len_per_req`` in ``{1,2,3,4,5,6,8}``; FP8 e4m3 KV uses page size
        64 and supports the same set.  The route can be selected explicitly
        with ``backend="cake"``. ``bmm1_scale`` is the fused QK
        scale and ``bmm2_scale`` is the FP8 V/output scale (BF16 KV requires
        ``bmm2_scale=1``). LSE is FP32 base-2, matching the existing TRT-LLM
        backend contract. Here ``max_seq_len`` is the maximum compact
        rank-local stored length; it may be zero for an entirely empty rank,
        while ``block_tables`` still supplies one masked physical page slot.
        Long-context BF16 and underfilled FP8 Split-KV routes use
        ``workspace_buffer`` for partials and require a zero-initialized,
        reusable :attr:`multi_ctas_kv_counter_buffer`; the kernel resets those
        completion tickets after every launch. The FP8 route specializes
        split1--4 and short-shard K/V retention in its JIT cache key. Prewarm a
        fixed tensor/layout binding before CUDA Graph capture.

    bf16q_fp8kv_transform_mode : Optional[Literal["k_only", "separate_kv"]] = None
        Transform mode for BF16 query + FP8 E4M3 KV decode. ``None`` selects the
        default separate transformed-K/V cubins and is ignored by other paths.
        ``"k_only"`` selects the optimized K-only transform cubins, and
        ``"separate_kv"`` selects the separate transformed-K/V cubins.

    request_order : Optional[torch.Tensor] = None
        Optional contiguous int32 CUDA tensor of shape ``[batch_size]`` with
        ``request_order[launch_slot] = logical_request_index``. This is
        supported by the SM103 Cake backend for BF16 Q/O, FP8 E4M3 HND K/V,
        head dimension 256, page size 64, 8 query heads, 1 KV head, and
        ``q_len_per_req`` 1 or 6. Its contents may change in place between
        CUDA Graph replays; a null pointer preserves the existing path.

    request_order_plan : Optional[CakeFmhaRequestOrderedDecodePlan] = None
        Optional immutable plan returned by
        :func:`flashinfer.plan_cake_fmha_request_ordered_paged_decode` before
        graph capture. When omitted, request ordering uses a safe single-split
        generated route. Page-table rows must be padded to
        ``4 * ceil(max_seq_len / 256)`` entries. Run one eager invocation with
        the exact tensors and workspace before graph capture so its TMA
        descriptors are initialized; subsequent replays may update only the
        contents of ``request_order`` in place.

    Returns
    -------
    out : Union[torch.Tensor, FP4Tensor]
        output torch.Tensor or FP4Tensor.
    lse : torch.Tensor, optional
        Only returned when ``return_lse`` is True. Shape ``[num_tokens, num_qo_heads]``
        with dtype ``torch.float32``.
    """
    if request_order is not None and backend != "cake":
        raise ValueError("request_order requires the explicit backend='cake'")
    if request_order_plan is not None and request_order is None:
        raise ValueError("request_order_plan requires a device request_order tensor")
    if request_order is not None and causal_seqlens_kv_global is not None:
        raise ValueError("request_order is not supported by DCP speculative decode")
    if causal_seqlens_kv_global is not None and enable_pdl is True:
        raise ValueError("DCP speculative decode does not support enable_pdl=True")
    enable_pdl = device_support_pdl(query.device) if enable_pdl is None else enable_pdl

    if isinstance(kv_cache, tuple):
        k_cache, v_cache = kv_cache
    else:
        if kv_cache.shape[1] == 1:
            k_cache, v_cache = kv_cache, kv_cache
        else:
            assert kv_cache.shape[1] == 2, (
                "When kv_cache is a single tensor, the second dimension must be 1 or 2"
            )
            # NOTE(Zihao): unbind transforms [num_pages, 2, ...] to ([num_pages, ...], [num_pages, ...])
            # it doesn't change underlying storage
            k_cache, v_cache = kv_cache.unbind(dim=1)

    if k_cache.dtype == torch.uint8 or v_cache.dtype == torch.uint8:
        if kv_cache_sf is None:
            raise ValueError("kv_cache_sf must be provided for NVFP4 KV cache.")
    is_nvfp4_kvcache = (
        k_cache.dtype == torch.uint8
        and v_cache.dtype == torch.uint8
        and kv_cache_sf is not None
    )

    k_block_scales = None
    v_block_scales = None
    if is_nvfp4_kvcache:
        if (
            not isinstance(kv_cache_sf, (tuple, list))
            or len(kv_cache_sf) != 2
            or not all(torch.is_tensor(x) for x in kv_cache_sf)
        ):
            raise TypeError(
                "kv_cache_sf must be a tuple/list of two tensors: (k_scales, v_scales)."
            )
        k_block_scales, v_block_scales = kv_cache_sf
        assert (
            k_block_scales.dtype == torch.float8_e4m3fn
            and v_block_scales.dtype == torch.float8_e4m3fn
        ), "kv_cache_sf tensors should be float8 dtype."

    dcp_spec_enabled = causal_seqlens_kv_global is not None
    if not dcp_spec_enabled and (cp_world != 1 or cp_rank != 0):
        raise ValueError(
            "cp_world/cp_rank require causal_seqlens_kv_global to enable the "
            "DCP speculative decode path"
        )
    if dcp_spec_enabled:
        if backend not in ("auto", "trtllm-gen", "cake"):
            raise ValueError(
                "DCP speculative decode is only available through backend='auto', "
                "backend='trtllm-gen', or the explicit Cake FMHA product backend"
            )
        if kv_layout != "HND":
            raise ValueError(
                "DCP speculative decode currently requires kv_layout='HND'"
            )
        if is_nvfp4_kvcache or kv_cache_sf is not None:
            raise ValueError(
                "DCP speculative decode supports BF16 or FP8 e4m3 KV cache, "
                "but not NVFP4 or block scale tensors"
            )
        if q_len_per_req is None:
            raise ValueError("DCP speculative decode requires uniform q_len_per_req")
        if max_q_len is not None or cum_seq_lens_q is not None:
            raise ValueError(
                "DCP speculative decode does not yet support ragged query lengths"
            )
        if window_left != -1 or mask is not None:
            raise ValueError(
                "DCP speculative decode currently supports causal full attention only"
            )
        if sinks is not None:
            raise ValueError(
                "DCP speculative decode does not yet support attention sinks"
            )
        if skip_softmax_threshold_scale_factor is not None:
            raise ValueError("DCP speculative decode does not support skip-softmax")
        if not uses_shared_paged_kv_idx:
            raise ValueError("DCP speculative decode requires a shared K/V page table")
        if enable_block_sparse_attention:
            raise ValueError(
                "DCP speculative decode does not support block-sparse attention"
            )
        if bmm1_scale_log2 is not None:
            raise ValueError(
                "DCP speculative decode takes a host bmm1_scale; bmm1_scale_log2 "
                "device tensors are not yet supported"
            )
        if isinstance(bmm1_scale, torch.Tensor) or isinstance(bmm2_scale, torch.Tensor):
            raise TypeError(
                "DCP speculative decode requires host scalar bmm1/bmm2 scales"
            )
        if o_scale is not None and float(o_scale) != 1.0:
            raise ValueError("DCP speculative decode currently requires o_scale=1.0")
        if o_sf_scale is not None or o_sf_vec_size is not None:
            raise ValueError(
                "DCP speculative decode does not support scaled FP4 output"
            )
        if isinstance(out, FP4Tensor) or out_dtype == "nvfp4":
            raise ValueError("DCP speculative decode requires BF16 output")
        if out_dtype is not None and out_dtype != torch.bfloat16:
            raise ValueError("DCP speculative decode requires out_dtype=torch.bfloat16")
        if not return_lse and lse is None:
            raise ValueError(
                "DCP speculative decode requires return_lse=True or a caller-owned lse buffer"
            )

        num_qo_heads = query.shape[1]
        lse_shape = (query.shape[0], num_qo_heads)
        out = out if out is not None else torch.empty_like(query, dtype=torch.bfloat16)
        lse = (
            lse
            if lse is not None
            else torch.empty(lse_shape, dtype=torch.float32, device=query.device)
        )
        from .cake_dcp import run_dcp_spec_decode

        run_dcp_spec_decode(
            query=query,
            k_cache=k_cache,
            v_cache=v_cache,
            workspace_buffer=workspace_buffer,
            block_tables=block_tables,
            seq_lens=seq_lens,
            causal_seqlens_kv_global=causal_seqlens_kv_global,
            max_local_seq_len=max_seq_len,
            bmm1_scale=float(bmm1_scale),
            bmm2_scale=float(bmm2_scale),
            cp_world=cp_world,
            cp_rank=cp_rank,
            q_len_per_req=q_len_per_req,
            out=out,
            lse=lse,
            completion_buffer=multi_ctas_kv_counter_buffer,
        )
        return (out, lse) if return_lse else out

    if backend == "auto":
        backend = (
            "trtllm-gen" if get_compute_capability(query.device)[0] == 10 else "xqa"
        )

    if backend not in ("trtllm-gen", "cake") and bmm1_scale_log2 is not None:
        raise ValueError(
            "bmm1_scale_log2 is only supported when backend is 'trtllm-gen' or 'cake'"
        )
    if enable_block_sparse_attention:
        if backend != "trtllm-gen":
            raise ValueError(
                "enable_block_sparse_attention is only supported by the trtllm-gen "
                f"backend, got backend={backend!r}"
            )
        if window_left != -1:
            raise ValueError(
                "block-sparse attention does not support sliding window "
                "(window_left must be -1)"
            )
        if skip_softmax_threshold_scale_factor is not None:
            raise ValueError(
                "block-sparse attention does not support "
                "skip_softmax_threshold_scale_factor"
            )
    if backend != "trtllm-gen" and bf16q_fp8kv_transform_mode is not None:
        raise ValueError(
            "bf16q_fp8kv_transform_mode is only supported by backend='trtllm-gen'"
        )

    if backend == "xqa":
        # xqa backend doesn't support nvfp4 output
        if out_dtype == "nvfp4" or (out_dtype is None and isinstance(out, FP4Tensor)):
            raise ValueError("xqa backend does not support nvfp4 output")
        if o_sf_scale is not None or o_sf_vec_size is not None:
            raise ValueError("xqa backend does not support o_sf_scale or o_sf_vec_size")
        if max_q_len is not None or cum_seq_lens_q is not None:
            raise ValueError("xqa backend does not support cum_seq_lens_q")
        if not uses_shared_paged_kv_idx:
            raise ValueError(
                "xqa backend does not support uses_shared_paged_kv_idx=False"
            )
        if return_lse or lse is not None:
            raise NotImplementedError(
                "xqa backend does not support return_lse/lse output"
            )

        # Handle out and out_dtype
        if out_dtype is None:
            out_dtype = out.dtype if out is not None else query.dtype
        if out is None:
            out = torch.empty_like(query, dtype=out_dtype)

        # Call xqa_batch_decode_with_kv_cache
        return xqa_batch_decode_with_kv_cache(
            query=query,
            kv_cache=(k_cache, v_cache),
            kv_cache_sf=kv_cache_sf,
            workspace_buffer=workspace_buffer,
            block_tables=block_tables,
            seq_lens=seq_lens,
            max_seq_len=max_seq_len,
            bmm1_scale=bmm1_scale,
            bmm2_scale=bmm2_scale,
            window_left=window_left,
            out=out,
            sinks=sinks,
            kv_layout=kv_layout,
            enable_pdl=enable_pdl,
            q_len_per_req=q_len_per_req,
            o_scale=o_scale,
            mask=mask,
        )
    elif backend in ("trtllm-gen", "cake"):
        # Convert NHD layout to HND if necessary
        if kv_layout == "NHD":
            k_cache = k_cache.transpose(-3, -2)
            v_cache = v_cache.transpose(-3, -2)
            if is_nvfp4_kvcache:
                print(
                    "[WARNING] NVFP4 KV cache with NHD layout will be converted to HND, "
                    "incurring extra transpose and contiguous copy overhead. "
                    "Use kv_layout='HND' for better performance."
                )
                k_cache = k_cache.contiguous()
                v_cache = v_cache.contiguous()
                k_block_scales = k_block_scales.transpose(-3, -2).contiguous()
                v_block_scales = v_block_scales.transpose(-3, -2).contiguous()

        if backend == "cake":
            # Route selection needs the finalized output/scales and exact
            # uniform-query shape, so defer module loading until those values
            # have been resolved below.
            run_func = None
        else:
            run_func = get_trtllm_gen_fmha_module().trtllm_paged_attention_decode
        sm_count = get_device_sm_count(query.device)

        if out_dtype == "nvfp4" or (out_dtype is None and isinstance(out, FP4Tensor)):
            assert query.dtype == torch.float8_e4m3fn, (
                "query must be fp8 when out_dtype is nvfp4."
            )
            assert o_sf_scale is not None
            assert o_sf_vec_size in [None, 16], "only o_sf_vec_size = 16 is supported"
            o_sf_vec_size = o_sf_vec_size or 16

            fp4_out_shape = query.shape[:-1] + (ceil_div(query.shape[-1], 2),)

            if isinstance(out, FP4Tensor):
                fp4_out_scale_shape = (
                    out.scale.shape[0],
                    round_up(query.shape[1] * query.shape[2] // o_sf_vec_size, 4),
                )
                out_scale_factor = out.scale
                o_sf_start_index = out.scale_start_index
                out = out.data
                # out_dtype may be None
                out_dtype = out_dtype or "nvfp4"
            elif out is None:
                fp4_out_scale_shape = (
                    round_up(query.shape[0], 128),
                    round_up(query.shape[1] * query.shape[2] // o_sf_vec_size, 4),
                )
                out_scale_factor = torch.empty(
                    fp4_out_scale_shape, dtype=torch.float8_e4m3fn, device=query.device
                )
                o_sf_start_index = 0
                out = torch.empty(fp4_out_shape, dtype=torch.uint8, device=query.device)
            else:
                raise ValueError(f"Invalid out: {out}")

            assert out_dtype == "nvfp4"
            assert isinstance(out, torch.Tensor)

            # Use uint8 as the container dtype to compliant with next fp4 gemm.
            check_shape_dtype_device(
                out, fp4_out_shape, torch.uint8, query.device, "out"
            )

            check_shape_dtype_device(
                out_scale_factor,
                fp4_out_scale_shape,
                torch.float8_e4m3fn,
                query.device,
                "out_scale_factor",
            )

            # Check o_sf_start_index is valid
            if (
                o_sf_start_index < 0
                or o_sf_start_index + out.shape[0] > out_scale_factor.shape[0]
            ):
                raise ValueError(
                    f"o_sf_start_index is out of the valid range of out_scale_factor. "
                    f"o_sf_start_index={o_sf_start_index}, out.shape[0]={out.shape[0]}, "
                    f"out_scale_factor.shape[0]={out_scale_factor.shape[0]}"
                )

        elif isinstance(out_dtype, torch.dtype) or out_dtype is None:
            assert o_sf_scale is None
            assert o_sf_vec_size is None
            out_scale_factor = None
            o_sf_start_index = 0
            if out_dtype is None:
                out_dtype = out.dtype if out is not None else query.dtype
            out = out if out is not None else torch.empty_like(query, dtype=out_dtype)
            if out_dtype not in (query.dtype, torch.float16, torch.bfloat16):
                raise ValueError(f"Unsupported out_dtype: {out_dtype}")
            check_shape_dtype_device(out, query.shape, out_dtype, query.device, "out")
        else:
            raise ValueError(f"Invalid out_dtype: {out_dtype}")

        uses_bf16q_fp8kv = (
            query.dtype == torch.bfloat16
            and k_cache.dtype == torch.float8_e4m3fn
            and v_cache.dtype == torch.float8_e4m3fn
            and out_dtype == torch.bfloat16
        )
        if bf16q_fp8kv_transform_mode is None:
            bf16q_fp8kv_transform_mode_value = (
                _TRTLLM_GEN_BF16Q_FP8KV_TRANSFORM_MODES["separate_kv"]
                if uses_bf16q_fp8kv
                else 0
            )
        else:
            bf16q_fp8kv_transform_mode_value = _get_bf16q_fp8kv_transform_mode(
                bf16q_fp8kv_transform_mode
            )

        bmm1_scale = _get_trtllm_gen_bmm1_scale_arg(
            bmm1_scale, bmm1_scale_log2, query.device
        )
        if isinstance(bmm2_scale, torch.Tensor):
            assert bmm2_scale.dtype == torch.float32

        if q_len_per_req is not None:
            max_q_len = q_len_per_req
            batch_size = query.size(0) // q_len_per_req
        else:
            assert max_q_len is not None
            batch_size = cum_seq_lens_q.size(0) - 1

        num_kv_heads = k_cache.size(-3)
        _check_block_tables_shape(
            block_tables,
            uses_shared_paged_kv_idx,
            block_sparse=enable_block_sparse_attention,
            num_kv_heads=num_kv_heads,
            batch_size=batch_size,
        )
        if enable_block_sparse_attention:
            if seq_lens.shape != (num_kv_heads, batch_size):
                raise ValueError(
                    "block-sparse attention expects seq_lens of shape "
                    f"[num_kv_heads, batch_size] = [{num_kv_heads}, {batch_size}], "
                    f"got {tuple(seq_lens.shape)}"
                )
            if not seq_lens.is_contiguous() or not block_tables.is_contiguous():
                raise ValueError(
                    "block-sparse attention requires contiguous seq_lens and "
                    "block_tables tensors"
                )

        num_qo_heads = query.size(1)
        lse_shape = (query.size(0), num_qo_heads)
        if lse is not None:
            check_shape_dtype_device(lse, lse_shape, torch.float32, query.device, "lse")
            lse_stride_tokens = lse.stride(0)
            lse_stride_heads = lse.stride(1)
        elif return_lse:
            lse = torch.empty(lse_shape, dtype=torch.float32, device=query.device)
            lse_stride_tokens = lse.stride(0)
            lse_stride_heads = lse.stride(1)
        else:
            lse_stride_tokens = 0
            lse_stride_heads = 0

        if request_order is not None:
            from .cake_fmha import (
                CakeFmhaRequestOrderedDecodePlan,
                _fallback_cake_fmha_request_ordered_plan,
                _run_cake_fmha_request_ordered_paged_decode,
            )

            if q_len_per_req not in (1, 6) or cum_seq_lens_q is not None:
                raise ValueError(
                    "request-ordered Cake FMHA requires uniform q_len_per_req 1 or 6"
                )
            if (
                kv_layout != "HND"
                or window_left != -1
                or mask is not None
                or sinks is not None
                or k_block_scales is not None
                or v_block_scales is not None
                or enable_block_sparse_attention
                or skip_softmax_threshold_scale_factor not in (None, 1e-30)
            ):
                raise ValueError(
                    "request-ordered Cake FMHA requires causal dense HND paging "
                    "without masks, sinks, block scales, block sparsity, or skip-softmax"
                )
            if enable_pdl is not True:
                raise ValueError("request-ordered Cake FMHA requires enable_pdl=True")
            if o_scale is not None and float(o_scale) != 1.0:
                raise ValueError("request-ordered Cake FMHA requires o_scale=1.0")
            if o_sf_scale is not None or o_sf_vec_size is not None:
                raise ValueError("request-ordered Cake FMHA requires BF16 output")
            if bmm1_scale_log2 is None or not isinstance(bmm2_scale, torch.Tensor):
                raise ValueError(
                    "request-ordered Cake FMHA requires device bmm1_scale_log2 and "
                    "bmm2_scale tensors so replay adds no scale-conversion kernel"
                )
            if request_order_plan is None:
                request_order_plan = _fallback_cake_fmha_request_ordered_plan(
                    batch_size=batch_size,
                    q_len=q_len_per_req,
                    write_lse=lse is not None,
                )
            if not isinstance(request_order_plan, CakeFmhaRequestOrderedDecodePlan):
                raise TypeError(
                    "request_order_plan must be returned by "
                    "plan_cake_fmha_request_ordered_paged_decode"
                )
            if (
                request_order_plan.batch_size != batch_size
                or request_order_plan.q_len != q_len_per_req
                or request_order_plan.write_lse is not (lse is not None)
            ):
                raise ValueError(
                    "request_order_plan does not match batch, q_len, or LSE mode"
                )
            _run_cake_fmha_request_ordered_paged_decode(
                backend="cake",
                query=query,
                key_cache=k_cache,
                value_cache=v_cache,
                out=out,
                lse=lse,
                workspace_buffer=workspace_buffer,
                completion_buffer=multi_ctas_kv_counter_buffer,
                block_tables=block_tables,
                seq_lens=seq_lens,
                request_order=request_order,
                max_seq_len=max_seq_len,
                bmm1_scale_log2=bmm1_scale,
                bmm2_scale=bmm2_scale,
                uses_shared_paged_kv_idx=uses_shared_paged_kv_idx,
                plan=request_order_plan,
            )
            return (out, lse) if return_lse else out

        if backend != "cake" or multi_ctas_kv_counter_buffer is not None:
            multi_ctas_kv_counter_buffer = (
                _resolve_trtllm_gen_multi_ctas_kv_counter_buffer(
                    multi_ctas_kv_counter_buffer,
                    batch_size,
                    num_qo_heads,
                    sm_count,
                    query.device,
                )
            )

        if backend == "cake":
            from .cake_fmha import (
                _resolve_cake_fmha_decode_module,
                select_cake_fmha_decode_route,
            )

            if skip_softmax_threshold_scale_factor == 1e-30:
                # The pinned public matrix uses 1e-30 as a numerically inert
                # skip-softmax probe. Both route selection and launch consume
                # the disabled form.
                skip_softmax_threshold_scale_factor = None
            cake_route = select_cake_fmha_decode_route(
                query.device,
                query=query,
                key_cache=k_cache,
                value_cache=v_cache,
                out=out,
                workspace_buffer=workspace_buffer,
                block_tables=block_tables,
                seq_lens=seq_lens,
                batch_size=batch_size,
                q_len=q_len_per_req,
                max_seq_len=max_seq_len,
                window_left=window_left,
                bmm1_scale=bmm1_scale,
                bmm2_scale=bmm2_scale,
                o_scale=o_scale,
                sinks=sinks,
                kv_layout=kv_layout,
                uses_shared_paged_kv_idx=uses_shared_paged_kv_idx,
                cum_seq_lens_q=cum_seq_lens_q,
                key_block_scales=k_block_scales,
                value_block_scales=v_block_scales,
                skip_softmax_threshold_scale_factor=(
                    skip_softmax_threshold_scale_factor
                ),
                enable_block_sparse_attention=enable_block_sparse_attention,
                lse=lse,
                multi_ctas_kv_counter_buffer=multi_ctas_kv_counter_buffer,
            )
            cake_module, optimized_loaded = _resolve_cake_fmha_decode_module(
                query.device, cake_route
            )
            if not optimized_loaded:
                # compat_v1 takes host scalar scales; only the optimized
                # scale-pointer specialization preserves the device binding.
                if isinstance(bmm1_scale, torch.Tensor):
                    bmm1_scale = float(bmm1_scale.item()) / log2e
                if isinstance(bmm2_scale, torch.Tensor):
                    bmm2_scale = float(bmm2_scale.item())
            if multi_ctas_kv_counter_buffer is None:
                # Same per-call contract as backend="trtllm-gen": a fresh
                # zero-initialized buffer when the caller passes none. The
                # Cake on-device load-balanced route keeps its self-resetting
                # split-KV counters here too, so size it for the larger of the
                # two contracts, and allocate it last: the zero-fill is the
                # first GPU activity of the call, and every host step between
                # it and the launch would otherwise sit on the stream. Callers
                # in steady state pass their own buffer or capture a graph.
                from .cake_fmha import cake_fmha_balanced_counter_bytes

                multi_ctas_kv_counter_buffer = torch.zeros(
                    max(
                        get_trtllm_gen_multi_ctas_kv_counter_bytes(
                            batch_size, num_qo_heads, sm_count
                        ),
                        cake_fmha_balanced_counter_bytes(sm_count),
                    ),
                    dtype=torch.uint8,
                    device=query.device,
                )
            run_func = cake_module.cake_paged_attention_decode

        run_args = [
            out,
            out_scale_factor,
            query,
            k_cache,
            v_cache,
            workspace_buffer,
            multi_ctas_kv_counter_buffer,
            block_tables,
            seq_lens,
            max_q_len,
            max_seq_len,
            bmm1_scale,
            bmm2_scale,
            o_sf_scale or -1.0,
            o_sf_vec_size or -1,
            o_sf_start_index,
            batch_size,
            window_left,
            0,  # sparse_mla_top_k
            sm_count,
            enable_pdl,
            workspace_buffer.numel() * workspace_buffer.element_size(),
            sinks,
            cum_seq_lens_q,
            k_block_scales,
            v_block_scales,
            skip_softmax_threshold_scale_factor,
            uses_shared_paged_kv_idx,
            lse,
        ]
        if backend != "cake":
            run_args.append(1.0)  # lse_scale
        run_args.extend(
            [
                lse_stride_tokens,
                lse_stride_heads,
                enable_block_sparse_attention,
                None,  # sparse_mla_top_k_lens
            ]
        )
        if backend != "cake":
            run_args.extend(
                (
                    bf16q_fp8kv_transform_mode_value,
                    None,  # use_fp16_softmax
                )
            )
        run_func(*run_args)

        result_out = (
            out
            if out_dtype != "nvfp4"
            else FP4Tensor(out, out_scale_factor, o_sf_start_index, query.shape)
        )
        if return_lse:
            return result_out, lse
        return result_out
    else:
        raise KeyError(f"Backend {backend} not supported")


# xqa uses NHD layout
@flashinfer_api(trace=xqa_batch_decode_trace)
def xqa_batch_decode_with_kv_cache(
    query: torch.Tensor,
    kv_cache: Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]],
    workspace_buffer: torch.Tensor,
    block_tables: torch.Tensor,
    seq_lens: torch.Tensor,
    max_seq_len: int,
    bmm1_scale: Union[float, torch.Tensor] = 1.0,
    bmm2_scale: Union[float, torch.Tensor] = 1.0,
    window_left: int = -1,
    out: Optional[torch.Tensor] = None,
    sinks: Optional[torch.Tensor] = None,
    kv_layout: str = "NHD",
    enable_pdl: bool = None,
    q_len_per_req: Optional[int] = 1,
    o_scale: Optional[float] = 1.0,
    mask: Optional[torch.Tensor] = None,
    kv_cache_sf: Union[
        torch.Tensor, Optional[Tuple[torch.Tensor, torch.Tensor]]
    ] = None,
    q_cu_seq_lens: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    """
    Parameters
    ----------
    query : torch.Tensor
        query tensor with shape [num_tokens, num_heads, head_dim], num_tokens = batch_size * q_len_per_request,
        or sum of per-request draft lengths when :attr:`q_cu_seq_lens` is given (ragged Q)

    kv_cache : Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]
        If kv_cache is a single tensor, it should be a tensor with shape [num_pages, 1 or 2, page_size, num_kv_heads, head_dim] if :attr:`kv_layout` is ``NHD``,
        or [num_pages, 1 or 2, num_kv_heads, page_size, head_dim] if :attr:`kv_layout` is ``HND``.
        If kv_cache is a tuple of two tensors, it should be a tuple of two tensors with shape [num_pages, page_size, num_kv_heads, head_dim] if :attr:`kv_layout` is ``NHD``,
        or [num_pages, num_kv_heads, page_size, head_dim] if :attr:`kv_layout` is ``HND``.

    workspace_buffer : torch.Tensor. Must be initialized to 0 for its first use.
        workspace

    block_tables : torch.Tensor
        page_table of kv cache, [batch_size, num_pages]

    seq_lens : torch.Tensor
        A uint32 1D tensor indicating the kv sequence length of each prompt. shape: ``[batch_size]``

    max_seq_len : int
        max sequence length for kv_cache

    bmm1_scale : Union[float, torch.Tensor]
        fused scale for bmm1 input.

    bmm2_scale : Union[float, torch.Tensor]
        fused scale for bmm2 input.

    window_left : int = -1
        The left (inclusive) window size for the attention window, when set to ``-1``, the window
        size will be set to the full length of the sequence. Defaults to ``-1``.
        On SM90 with fp8 KV cache, speculative decode with a non-negative window
        runs on the generic kernel instead of the Hopper fp8 kernel (see
        :func:`flashinfer.xqa.xqa`).

    out :  Optional[torch.Tensor] = None
        output tensor, if not provided, will be allocated with ``query.dtype``.

    sinks : Optional[torch.Tensor] = None
        additional value per head in the denominator of the softmax.

    kv_layout : str
        The layout of the kv cache. Can be either ``NHD`` or ``HND``. Defaults to ``NHD``.

    enable_pdl : bool
        Whether to enable Programmatic Dependent Launch (PDL). See https://docs.nvidia.com/cuda/cuda-c-programming-guide/#programmatic-dependent-launch-and-synchronization
        Only supported for >= sm90, and currently only for FA2, CUDA core, and trtllm-gen decode.

    q_len_per_req : Optional[int] = 1
        Number of query tokens per request (i.e. speculative-decoding / MTP depth).
        ``query`` is expected to have ``batch_size * q_len_per_req`` rows along its
        leading dimension.  Defaults to ``1``.

    o_scale : Optional[float] = 1.0
        output scale factor for fp8 output.

    mask : Optional[torch.Tensor] = None
        draft-block attention mask for xqa speculative decoding.

    kv_cache_sf : Optional[torch.Tensor] = None
        KV cache scaling factors. Must provide when NVFP4 KV cache is used.

    q_cu_seq_lens : Optional[torch.Tensor] = None
        cumulative draft lengths [batch_size + 1] (int32, on device) enabling
        ragged Q: requests may have different draft lengths. When given,
        query/out stay packed as [total_q_tokens, num_heads, head_dim],
        q_len_per_req must be the maximum draft length, and mask rows are
        packed by the same cumulative offsets. On SM90 with fp8 KV cache,
        speculative decode runs on the generic kernel instead of the Hopper
        fp8 kernel (see :func:`flashinfer.xqa.xqa`).

    Returns
    -------
    out : torch.Tensor
        output torch.Tensor.
    """
    enable_pdl = device_support_pdl(query.device) if enable_pdl is None else enable_pdl

    if isinstance(kv_cache, tuple):
        k_cache, v_cache = kv_cache
    else:
        if kv_cache.shape[1] == 1:
            k_cache, v_cache = kv_cache, kv_cache
        else:
            assert kv_cache.shape[1] == 2, (
                "When kv_cache is a single tensor, the second dimension must be 1 or 2"
            )
            # NOTE(Zihao): unbind transforms [num_pages, 2, ...] to ([num_pages, ...], [num_pages, ...])
            # it doesn't change underlying storage
            k_cache, v_cache = kv_cache.unbind(dim=1)

    k_cache_sf = None
    v_cache_sf = None
    if kv_cache_sf is not None:
        if isinstance(kv_cache_sf, tuple):
            k_cache_sf, v_cache_sf = kv_cache_sf
        else:
            assert kv_cache_sf.shape[1] == 2, (
                "When kv_cache is a single tensor, the second dimension must be 1 or 2"
            )
            # NOTE(Zihao): unbind transforms [num_pages, 2, ...] to ([num_pages, ...], [num_pages, ...])
            # it doesn't change underlying storage
            k_cache_sf, v_cache_sf = kv_cache_sf.unbind(dim=1)

    sm_count = get_device_sm_count(query.device)

    # Extract shape parameters based on layout
    if kv_layout == "NHD":
        # NHD: [num_pages, page_size, num_kv_heads, head_dim] for ordinary KV cache
        # or [num_pages, page_size, num_kv_heads, head_dim// 2] for NVFP4 KV cache with packed head dim
        page_size = k_cache.shape[1]
        num_kv_heads = k_cache.shape[2]
    else:  # HND
        # HND: [num_pages, num_kv_heads, page_size, head_dim] for ordinary KV cache
        # or [num_pages, num_kv_heads, page_size, head_dim// 2] for NVFP4 KV cache with packed head dim
        num_kv_heads = k_cache.shape[1]
        page_size = k_cache.shape[2]

    # query shape: [num_tokens, num_heads, head_dim]
    head_dim = query.shape[-1]

    workspace_u8 = workspace_buffer.view(torch.uint8)
    semaphore = workspace_u8[: 8 * 1024 * 1024]  # reserve 8MB for semaphore
    scratch = workspace_u8[8 * 1024 * 1024 :]
    kv_scale_value = bmm2_scale * o_scale
    q_scale_value = bmm1_scale / kv_scale_value * (head_dim**0.5)

    if q_cu_seq_lens is not None:
        # Ragged Q: query stays packed as [total_q_tokens, num_heads, head_dim]
        # and q_len_per_req is the max draft length across the batch.
        assert q_len_per_req > 1, (
            "q_cu_seq_lens requires q_len_per_req to be the max draft length (> 1)"
        )
        query_new = query
        out_shape_ref = query
    else:
        if q_len_per_req > 1:
            batch_size = query.shape[0] // q_len_per_req
            query = query.view(
                batch_size, q_len_per_req, query.shape[1], query.shape[2]
            )
        query_new = query.unsqueeze(1)
        out_shape_ref = query
    seq_lens_new = seq_lens.unsqueeze(1)
    sinks_new = sinks.reshape(num_kv_heads, -1) if sinks is not None else None

    # Ensure 4D output for xqa (packed 3D stays as-is for ragged Q)
    if out is None:
        out = torch.empty_like(out_shape_ref)
    out_new = out if q_cu_seq_lens is not None else out.unsqueeze(1)

    xqa(
        query_new,
        k_cache,
        v_cache,
        block_tables,
        seq_lens_new,
        out_new,
        scratch,
        semaphore,
        num_kv_heads,
        page_size,
        k_sf_cache=k_cache_sf,
        v_sf_cache=v_cache_sf,
        sinks=sinks_new,
        q_scale=q_scale_value,
        kv_scale=kv_scale_value,
        sliding_win_size=window_left + 1 if window_left >= 0 else 0,
        kv_layout=kv_layout,
        sm_count=sm_count,
        enable_pdl=enable_pdl,
        rcp_out_scale=1.0 / o_scale,
        q_seq_len=q_len_per_req,
        q_cu_seq_lens=q_cu_seq_lens,
        mask=mask,
    )

    return out


def fast_decode_plan(
    self,
    indptr: torch.Tensor,
    indices: torch.Tensor,
    last_page_len: torch.Tensor,
    num_qo_heads: int,
    num_kv_heads: int,
    head_dim: int,
    page_size: int,
    pos_encoding_mode: str = "NONE",
    window_left: int = -1,
    logits_soft_cap: Optional[float] = None,
    q_data_type: Optional[Union[str, torch.dtype]] = None,
    kv_data_type: Optional[Union[str, torch.dtype]] = None,
    data_type: Optional[Union[str, torch.dtype]] = None,
    sm_scale: Optional[float] = None,
    rope_scale: Optional[float] = None,
    rope_theta: Optional[float] = None,
    non_blocking: bool = True,
    fixed_split_size: Optional[int] = None,
    disable_split_kv: bool = False,
    q_len_per_req: int = 1,
    global_override_indptr_cpu: Optional[torch.Tensor] = None,
) -> None:
    """
    A faster version of BatchDecodeWithPagedKVCacheWrapper::plan used for FlashInferMultiStepDraftBackend.
    Modifications:
    - Remove unnecessary device-to-device copy for the cuda graph buffers.
    - Remove unnecessary host-to-device copy for the metadata buffers.

    cuDNN uses the regular planner to refresh its KV lengths and block table;
    compatible prepared graphs are still reused. The copy-elision below is
    specific to the FA2/FA3 module, not cuDNN's metadata contract.
    """
    batch_size = len(last_page_len)
    wants_cudnn = self._backend == "cudnn"
    if self._requested_backend == "auto":
        # backend="auto" is resolved per plan (see _plan_impl): decide on this
        # plan's geometry before trusting the module a previous plan() cached.
        q_dtype = canonicalize_torch_dtype(
            q_data_type if q_data_type is not None else data_type or "float16"
        )
        kv_dtype = (
            canonicalize_torch_dtype(kv_data_type)
            if kv_data_type is not None
            else q_dtype
        )
        o_dtype = getattr(self, "_cached_o_data_type", None) or q_dtype
        wants_cudnn = self._auto_prefers_cudnn(
            q_dtype,
            kv_dtype,
            o_dtype,
            head_dim,
            num_qo_heads,
            num_kv_heads,
            batch_size,
            page_size,
            pos_encoding_mode,
            window_left,
            logits_soft_cap,
            q_len_per_req,
            user_block_tables=getattr(self, "_user_block_tables", False),
            declared_kv_len=self._block_tables.shape[1] * page_size
            if getattr(self, "_user_block_tables", False)
            else None,
            fixed_split_size=fixed_split_size,
            disable_split_kv=disable_split_kv,
        )
    if wants_cudnn or self._cudnn_auto:
        # cuDNN (explicit or auto), and an auto wrapper leaving cuDNN, go
        # through the regular planner: it refreshes cuDNN's KV lengths and
        # block table (compatible prepared graphs are reused) or builds the
        # FA2/FA3 module the fast path below replans. Call the implementation
        # directly: serving callers replace self.plan with
        # partial(fast_decode_plan, self).
        return self._plan_impl(
            indptr
            if global_override_indptr_cpu is None
            else global_override_indptr_cpu,
            indices,
            last_page_len,
            num_qo_heads,
            num_kv_heads,
            head_dim,
            page_size,
            pos_encoding_mode=pos_encoding_mode,
            window_left=window_left,
            logits_soft_cap=logits_soft_cap,
            q_data_type=q_data_type
            if q_data_type is not None
            else data_type or "float16",
            kv_data_type=kv_data_type,
            data_type=data_type,
            o_data_type=getattr(self, "_cached_o_data_type", None),
            sm_scale=sm_scale,
            rope_scale=rope_scale,
            rope_theta=rope_theta,
            non_blocking=non_blocking,
            block_tables=self._block_tables
            if getattr(self, "_user_block_tables", False)
            else None,
            fixed_split_size=fixed_split_size,
            disable_split_kv=disable_split_kv,
            q_len_per_req=q_len_per_req,
        )
    if q_len_per_req < 1:
        raise ValueError(f"q_len_per_req must be >= 1, got {q_len_per_req}")
    if q_len_per_req > 1 and not self.use_tensor_cores:
        raise ValueError(
            "q_len_per_req > 1 requires tensor-core decode "
            "(use_tensor_cores=True or the trtllm-gen/cute-dsl backend)."
        )
    if q_len_per_req > 1:
        backend = getattr(self, "_backend", "auto")
        if backend == "auto":
            # fast_decode_plan reuses the module cached by plan(); without
            # that resolution the backend gate below cannot be trusted.
            raise ValueError(
                "fast_decode_plan with q_len_per_req > 1 requires a prior "
                "plan() call that resolves the backend."
            )
        if backend == "fa3":
            raise NotImplementedError(
                "q_len_per_req > 1 is currently only supported on the fa2 "
                "tensor-core backend."
            )
    if self.is_cuda_graph_enabled:
        frozen_q_len = getattr(self, "_q_len_per_req", None)
        if frozen_q_len is not None and frozen_q_len != q_len_per_req:
            raise ValueError(
                "q_len_per_req is part of the frozen cudagraph shape: "
                f"this wrapper was planned with {frozen_q_len}, got "
                f"{q_len_per_req}. Use a separate wrapper per q_len_per_req."
            )
    is_causal = q_len_per_req > 1
    self._q_len_per_req = q_len_per_req
    if logits_soft_cap is None:
        logits_soft_cap = 0.0

    # Handle data types consistently
    if data_type is not None:
        if q_data_type is None:
            q_data_type = data_type
        if kv_data_type is None:
            kv_data_type = data_type
    elif q_data_type is None:
        q_data_type = "float16"

    if kv_data_type is None:
        kv_data_type = q_data_type

    if self.use_tensor_cores:
        qo_indptr_host = _get_range_buf(batch_size + 1, "cpu")
        if q_len_per_req > 1:
            qo_indptr_host = qo_indptr_host * q_len_per_req
        # Here we set fixed_split_size to -1 to avoid the assertion error in flashinfer's plan function
        if fixed_split_size is None:
            fixed_split_size = -1

    if self.is_cuda_graph_enabled:
        if batch_size != self._fixed_batch_size:
            raise ValueError(
                "The batch size should be fixed in cudagraph mode, the runtime batch size {} "
                " mismatches the batch size set during initialization {}".format(
                    batch_size, self._fixed_batch_size
                )
            )
        if len(indices) > len(self._paged_kv_indices_buf):
            raise ValueError(
                "The size of indices should be less than or equal to the allocated buffer"
            )
        if self.use_tensor_cores and q_len_per_req > 1:
            self._qo_indptr_buf.copy_(qo_indptr_host, non_blocking=non_blocking)
    else:
        self._paged_kv_indptr_buf = indptr
        self._paged_kv_indices_buf = indices
        self._paged_kv_last_page_len_buf = last_page_len
        if self.use_tensor_cores:
            self._qo_indptr_buf = qo_indptr_host.to(
                self.device, non_blocking=non_blocking
            )

    # Create empty tensors for dtype info if needed
    empty_q_data = torch.empty(
        0,
        dtype=(
            getattr(torch, q_data_type) if isinstance(q_data_type, str) else q_data_type
        ),
        device=self.device,
    )

    empty_kv_cache = torch.empty(
        0,
        dtype=(
            getattr(torch, kv_data_type)
            if isinstance(kv_data_type, str)
            else kv_data_type
        ),
        device=self.device,
    )

    indptr_host = (
        global_override_indptr_cpu
        if global_override_indptr_cpu is not None
        else indptr.cpu()
    )

    with torch.cuda.device(self.device):
        if self.use_tensor_cores:
            # ALSO convert last_page_len to CPU
            if page_size == 1:
                # When page size is 1, last_page_len is always 1.
                # Directly construct the host tensor rather than executing a device-to-host copy.
                last_page_len_host = torch.ones(
                    (batch_size,), dtype=torch.int32, device="cpu"
                )
            else:
                last_page_len_host = last_page_len.cpu()

            kv_lens_arr_host = get_seq_lens(indptr_host, last_page_len_host, page_size)

            try:
                # Make sure we pass exactly 19 arguments for fa2 backend and 16 arguments for fa3 backend
                args = [
                    self._float_workspace_buffer,
                    self._int_workspace_buffer,
                    self._pin_memory_int_workspace_buffer,
                    qo_indptr_host,
                    indptr_host,
                    kv_lens_arr_host,
                    batch_size * q_len_per_req,  # total_num_rows
                    batch_size,
                    num_qo_heads,
                    num_kv_heads,
                    page_size,
                    self.is_cuda_graph_enabled,
                    head_dim,
                    head_dim,
                    is_causal,  # causal
                    window_left,
                ]
                if self._backend == "fa2":
                    args.append(fixed_split_size)
                    args.append(disable_split_kv)
                    args.append(0)  # num_colocated_ctas
                    args.append(
                        q_len_per_req if q_len_per_req > 1 else 0
                    )  # uniform_q_len
                self._plan_info = self._cached_module.plan(
                    *args,
                )
            except Exception as e:
                raise RuntimeError(f"Error in standard plan: {e}") from e
        else:
            try:
                # Make sure we pass exactly 15 arguments for standard version
                self._plan_info = self._cached_module.plan(
                    self._float_workspace_buffer,
                    self._int_workspace_buffer,
                    self._pin_memory_int_workspace_buffer,
                    indptr_host,
                    batch_size,
                    num_qo_heads,
                    num_kv_heads,
                    page_size,
                    self.is_cuda_graph_enabled,
                    window_left,
                    logits_soft_cap,
                    head_dim,
                    head_dim,
                    empty_q_data,
                    empty_kv_cache,
                )
            except Exception as e:
                raise RuntimeError(f"Error in standard plan: {e}") from e

    self._pos_encoding_mode = pos_encoding_mode
    self._window_left = window_left
    self._logits_soft_cap = logits_soft_cap
    self._sm_scale = sm_scale
    self._rope_scale = rope_scale
    self._rope_theta = rope_theta
